#!/bin/sh
#
#	Call postinstall shell for ipfailover
#
#

if	[ -z "$ROOTACT" ]
then
	if	[ -d /mnt/fsuser-1/actility ]
	then
		export ROOTACT=/mnt/fsuser-1/actility
	else
		case $(uname -n) in
			klk-lpbs*)
				export ROOTACT=/user/actility
				;;
			klk-wifc*)
				export ROOTACT=/user/actility
				;;
			*)
				export ROOTACT=/home/actility
				;;
		esac
	fi
fi

[ -f "$ROOTACT/lrr/failovermgr/postinstall.sh" ] && $ROOTACT/lrr/failovermgr/postinstall.sh
