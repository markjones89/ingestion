#!/bin/sh
#
#	THIS FILE IS ONLY USED IF NFR920 IS ACTIVATED
#

  # IPV4
  type iptables > /dev/null 2>&1
  ret=$?
  if [ $ret != 0 ]; then
    exit 0
  fi
  #DROP everything in INPUT (Let everything going out)
  iptables -P INPUT DROP > /dev/null 2>&1

  #Allow everything on localhost interface
  iptables -A INPUT -i lo -j ACCEPT

  #Allow DHCP protocol on all interfaces
  #iptables -A INPUT -p udp --dport 67:68 --sport 67:68 -j ACCEPT

  #Allow ICMP output (ping requests) on all interfaces
  iptables -A INPUT -p icmp --source 192.0.0.0/8 -j ACCEPT
  iptables -A INPUT -p icmp --source 10.0.0.0/8 -j ACCEPT

  #allow DNS requests
  #iptables -A INPUT -p udp --sport 53 -j ACCEPT
  #iptables -A INPUT -p tcp --sport 53 -j ACCEPT

  #allow NTP
  #iptables -A INPUT -p udp --dport 123 --sport 123 -j ACCEPT

  iptables -A INPUT -p tcp --dport 22 --source 192.0.0.0/8 -j ACCEPT
  iptables -A INPUT -p tcp --dport 22 --source 10.0.0.0/8 -j ACCEPT

  iptables -A INPUT -m state --state ESTABLISHED,RELATED -j ACCEPT

  # IPV6
  type ip6tables > /dev/null 2>&1
  ret=$?
  if [ $ret != 0 ]; then
    exit 0
  fi
  # ip6tables can be present but not the ipv6 kernel module
  ip6tables -L > /dev/null 2>&1
  ret=$?
  if [ $ret != 0 ]; then
    exit 0
  fi

  #DROP everything in INPUT (Let everything going out)
  ip6tables -P INPUT DROP

  #Allow everything on localhost interface
  ip6tables -A INPUT -i lo -j ACCEPT

  #Allow DHCP protocol on all interfaces
  #ip6tables -A INPUT -p udp --dport 67:68 --sport 67:68 -j ACCEPT

  #Allow ICMP output (ping requests) on all interfaces
  ip6tables -A INPUT -p icmp --source fc00::/7 -j ACCEPT

  #allow DNS requests
  #ip6tables -A INPUT -p udp --sport 53 -j ACCEPT
  #ip6tables -A INPUT -p tcp --sport 53 -j ACCEPT

  #allow NTP
  #ip6tables -A INPUT -p udp --dport 123 --sport 123 -j ACCEPT

  ip6tables -A INPUT -p tcp --dport 22 --source fc00::/7 -j ACCEPT

  ip6tables -A INPUT -m state --state ESTABLISHED,RELATED -j ACCEPT

  exit 0
