#!/bin/sh

DIR=$ROOTACT/lrr/failovermgr/$SYSTEM

# security to avoid overwritting files on other systems
[ -z "$SYSTEM" -o "$SYSTEM" != "ug6x" ] && exit 1

savpwd=$(pwd)
cd $DIR

# create ini file if it doesn't exist
inifile="$ROOTACT/usr/etc/lrr/ipfailover2.ini"
definifile="$DIR/ipfailover2.ini"
[ -f "$definifile" ] && rm -rf $inifile && cp $definifile $inifile

cd $savpwd