#!/bin/bash

# Copyright (C) Actility, SA. All Rights Reserved.
# DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License version
# 2 only, as published by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License version 2 for more details (a copy is
# included at /legal/license.txt).
#
# You should have received a copy of the GNU General Public License
# version 2 along with this work; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
# 02110-1301 USA
#
# Please contact Actility, SA.,  4, rue Ampere 22300 LANNION FRANCE
# or visit www.actility.com if you need additional
# information or have any questions.

INCONSISTENT_CONFIG=2

. $ROOTACT/lrr/com/system_setting.sh
. $ROOTACT/lrr/com/system_api.sh

source ${ROOTACT}/usr/etc/lrr/_parameters.sh
source $ROOTACT/lrr/com/_functions.sh

SERVROOTDIR="${ROOTACT}/lrr/failovermgr"

# Load default configuration
source $SERVROOTDIR/default_config

# Load the log function
source $SERVROOTDIR/log_function

# Load the config function
source $SERVROOTDIR/load_config

# Load check interface status function
source $SERVROOTDIR/check_interface_status

# Load restart interface function
SystemGetFilePath "$SERVROOTDIR" restart_interface
source $sysfilepath

# Load the ping_routes function
source $SERVROOTDIR/ping_routes

# Load the handle iptable functions
source $SERVROOTDIR/handle_iptables

# Load the ip rule set funtions
source $SERVROOTDIR/ip_rule_set

# Default custom function
ipfailover2_prestart_hook()
{
    return
}

ipfailover2_periodic_control()
{
    return
}

LOGFILE=$ROOTACT/var/log/lrr/ipfailover2.log
CURRENT="ERROR"
FAILED_PRINCIPAL=0

SystemGetFilePath "$ROOTACT/usr/etc/lrr" "iptables.sh"
if [ -f "$sysfilepath" ]
then
	IPTABLES="$sysfilepath"
else
    SystemGetFilePath "$SERVROOTDIR" "iptables.sh"
    if [ -f "$sysfilepath" ]
    then
        IPTABLES="$sysfilepath"
    fi
fi

STATICCONF=$ROOTACT/usr/data/lrr/gwmgr/static_config

is_cellular()
{
	INTERFACE=$1

	case $INTERFACE in
		wwan*) return 0 ;;
		ppp*) return 0 ;;
		cellular*) return 0 ;;
	esac
	return 1
}

check_dns()
{
	INTERFACE=$1
	Log "Check DNS for $INTERFACE"

	RESOLV_INT=/run/resolv.conf.${INTERFACE}

	if [ -f ${RESOLV_INT} ]
	then
		for dns in $(grep -E 'nameserver' ${RESOLV_INT} | cut -f2 -d' ')
		do
			grep -E $dns $RESOLVCONF
			if [ $? != 0 ]; then
				return 1
			fi
		done
	fi
	return 0
}

update_dns()
{
	INTERFACE=$1

	RESOLV_INT=/run/resolv.conf.${INTERFACE}

	Log "Update DNS for $INTERFACE"
	if [ -f ${RESOLV_INT} ]
	then
		cp -f ${RESOLV_INT} $RESOLVCONF
		grep -E "options.*timeout" $RESOLVCONF
		result1=$?
		grep options $RESOLVCONF
		result2=$?
		if [ $result1 != 0 ] && [ $result2 != 0 ]
		then
			echo "options timeout:2" >> $RESOLVCONF
		elif [ $result1 != 0 ] && [ $result2 = 0 ]
		then
			sed -i 's#options#options timeout:2#g' $RESOLVCONF
		else
			sed -i 's#timeout:[0-9]*#timeout:2#g' $RESOLVCONF
		fi
	fi
}

set_route()
{
	INTERFACE=$1

	Log "Use interface $INTERFACE"
	# Create default route before deleting other routes
	if is_cellular $INTERFACE
	then
		ROUTE="default dev $INTERFACE scope link"
		route add default dev $INTERFACE
	else
		ROUTE="default via $(cat ${GATEWAY_INT}) dev $INTERFACE"
		ip route add $ROUTE
	fi


	ip route | sed 's/\s\s*/ /g' | sed 's/\s*$//g' | grep default |
	while IFS= read -r route; do
		if [ "$ROUTE" != "$route" ]; then
			ip route del $route
		fi
	done

	# Ensure default route was not deleted by mistake
	if is_cellular $INTERFACE
	then
		ROUTE="default dev $INTERFACE scope link"
		route add default dev $INTERFACE
	else
		ROUTE="default via $(cat ${GATEWAY_INT}) dev $INTERFACE"
		ip route add $ROUTE
	fi

	return 0
}

##
## @fn use_interface
## @brief set the configuration for the given interface so it can be used as principal
## @param INTERFACE interface to configure
## @retval 0: all is OK, 2: inconsistency detected, 1: other reasons
##
use_interface()
{
	INTERFACE=$1

	RESOLV_INT=/run/resolv.conf.${INTERFACE}
	GATEWAY_INT=/run/gwip.${INTERFACE}

	checkInterfaceStatus $INTERFACE
	if [ $? != "0" ]
	then
		Log "### $INTERFACE not started correctly"
		return 1
	fi

	if ! is_cellular $INTERFACE
	then
	    create_static_ip_files $INTERFACE
	    ret=$?
	    if [ $ret != "0" ]
	    then
		    return $ret
	    fi
	fi

	if [ ! -f ${GATEWAY_INT} ] && ! is_cellular $INTERFACE
	then
		Log "### file ${GATEWAY_INT} does not exist"
		return 1
	fi

	# should the following error be differentiated and process by caller?
	set_route $INTERFACE || return 1

	update_dns $INTERFACE

	return 0
}

checks()
{

	loadConfig

	FORCE_FAILOVER=0
	if [ -f "/tmp/force_failover" ]; then
		# simulation: simulate failure of principal interface
		FORCE_FAILOVER=1
	fi

	# here, PRINCIPAL and RESCUE may have been changed or disabled
	principal_to_configure=""
	rescue_to_configure=""

	# unconfigure previous interfaces
	if [ "$PRINCIPAL" != "$PRINCIPAL_SAVE" ]; then
		# clean up previous principal ... nothing to do
		principal_to_configure=$PRINCIPAL
	fi
	if [ "${RESCUE}" != "${RESCUE_SAVE}" ]; then
		# clean up previous rescue: remove ip rules if set
		[ "${RESCUESVP_SAVE}" = "1" ] && remove_old_ip_rules
	fi

	# and configure new ones
	if [ ! -z "${principal_to_configure}" ]; then
		PRINCIPAL=$principal_to_configure
		# use_interface calls create_static_ip_files
		use_interface $PRINCIPAL
		# PT-1664: is the configuration consistent -> if not, exit and wait for the next call
		if [ $? -eq $INCONSISTENT_CONFIG ]
		then
			WAITCONFIG=5
			Log "### Inconsistent configuration, likely still in progress. Next cycle in $WAITCONFIG"
			sleep $WAITCONFIG
			return 1
		fi

		# reset interface setting as maybe no more sense with new configuration
		CURRENT=${PRINCIPAL}
		DNS_ITF=${PRINCIPAL}
	fi
	if [ ! -z "${rescue_to_configure}" ]; then
		RESCUE=$rescue_to_configure
		create_static_ip_files $RESCUE
	fi

	# DNS_ITF is set to working interface or principal by default (not tested yet or all itf down)
	check_dns ${DNS_ITF}
	if [ $? != 0 ]; then
		update_dns ${DNS_ITF}
	fi

	#
	# now adaptation of network configuration to the actual state of each interface
	# then can move the active interface to rescue if principal is not working properly
	#

	ipfailover2_periodic_control $PRINCIPAL

	# check if the interface works by pinging remote servers (IP or hostname)
	# nb of success will be used to determine if interface is stable enough
	check $PRINCIPAL
	cnt=$?

	if [ "${FORCE_FAILOVER}" != 0 ]; then
		cnt=0
	fi


	if [ "${CURRENT}" != "ERROR" ]
	then
		# 2 possible outputs
		# default via 10.100.53.254 dev eth0
		# default dev wwan0 scope link

		# check 1st output
		defroute="$(ip route | grep default | grep -v metric | awk '{print $5}')"
		if [ "$defroute" != "${CURRENT}" ]
		then
			# check 2nd output
			defroute="$(ip route | grep default | grep -v metric | awk '{print $3}')"
			if [ "$defroute" != "${CURRENT}" ]
			then
				Log "### def route $defroute doesnt match ${CURRENT}"
				CURRENT="ERROR"
			fi
		fi
	fi


	if [ $cnt -ge $SUCCESSCOUNT ]
	then

		# PRINCIPAL is OK

		CURRENT_SAVE=${CURRENT}
		FAILED_PRINCIPAL=0
		if [ "${CURRENT}" != "${PRINCIPAL}" ]
		then
			# switch from Rescue to Principal
			# here: CURRENT may be ERROR if route is not on the "current" interface

			Log "Set and use principal ${PRINCIPAL}"
			use_interface ${PRINCIPAL}
			if [ $? = "0" ]
			then
				# Principal is set correctly
				CURRENT=${PRINCIPAL}
				DNS_ITF=${PRINCIPAL}
			else
				# issue while switching on Principal also it "should" work: set all at the cycle
				CURRENT="ERROR"
			fi
			# if issue on Principal and previous interface was Rescue, switch back on
			if [ "${CURRENT_SAVE}" = "${RESCUE}" ]
			then
				# Restart rescue interface to force reconnection of LRR to LRC
				restartInterface $RESCUE
				set_route $CURRENT
			fi
		fi


		Log "Stay ${CHECKFREQ} sec on ${PRINCIPAL}/${CURRENT}"
		[ "${RESCUESVP}" = "0" ] && remove_old_ip_rules
		[ "${RESCUESVP}" = "1" ] && ipRuleSet $RESCUE
		updateStateFile "$CURRENT"
		sleep ${CHECKFREQ}

	else

		# Principal is not OK

		FAILED_PRINCIPAL=`expr $FAILED_PRINCIPAL + 1`
		if [ ${FAILED_PRINCIPAL} -ge ${MAX_FAILED_PRINCIPAL} ]
		then
			# try to restart it during some cycles
			if restartInterface $PRINCIPAL; then
				FAILED_PRINCIPAL=0
				# restarting eth0 delete default route if set on it (no rescue)
				# => need to create again default route
				[ "${RESCUESVP}" != "1" ] && use_interface ${PRINCIPAL}
			fi
		fi

		# in any case, be sure to use RESCUE if defined
		if [ "${CURRENT}" = "${RESCUE}" ]
		then
			Log "Stay ${RETURNFREQ} sec on ${RESCUE}/${CURRENT}"
			ipRuleSet $PRINCIPAL
			updateStateFile "$CURRENT"
			sleep ${RETURNFREQ}
		elif [ "${CURRENT}" != "${RESCUE}" ] && [ "${RESCUESVP}" = "1" ]
		then
			Log "Set and use rescue ${RESCUE}"
			use_interface ${RESCUE}
			if [ $? = "0" ]
			then
				# RESCUE is OK: use it
				CURRENT=${RESCUE}
				DNS_ITF=${RESCUE}
				Log "Stay ${RETURNFREQ} sec on ${RESCUE}/${CURRENT}"
				ipRuleSet $PRINCIPAL
				updateStateFile "$CURRENT"
				sleep ${RETURNFREQ}
			else
				# Rescue also down: no more interface
				CURRENT="ERROR"
				Log "Stay ${CHECKFREQ} sec on ${RESCUE}/${CURRENT}"
				ipRuleSet $PRINCIPAL
				updateStateFile "$CURRENT"
				sleep ${CHECKFREQ}
			fi
		else
			# Principal is off and no rescue (off or not defined): stay on Principal
			# here: CURRENT may be ERROR if route is not on the "current" interface

			CURRENT="ERROR"
			# stay on PRINCIPAL for DNS
			DNS_ITF=${PRINCIPAL}
			Log "Stay ${CHECKFREQ} sec on ${PRINCIPAL}/${CURRENT}"
			# at startup routes can be incorrect and CURRENT=ERROR
			# there is no rescue interface => set route on principal
			set_route $PRINCIPAL
			ipRuleSet $PRINCIPAL
			updateStateFile "$CURRENT"
			sleep ${CHECKFREQ}
		fi
	fi

	if [ "$DELAY_REMOVE_SSH" = "0" ]
	then
		CheckIptablesStatus
		if [ $? = 1 ]
		then
			AllowSSH
		fi
	else
		CheckIptablesStatus
		if [ $? = 0 ]
		then
			CheckConnectivityToLRC
			if [ $? = 0 ]
			then
				BlockSSH
			fi
		fi
	fi

	PRINCIPAL_SAVE=${PRINCIPAL}
	RESCUE_SAVE=${RESCUE}
	RESCUESVP_SAVE=${RESCUESVP}
}

killExisting()
{
	if [ -f /var/run/ifacefailover2.pid ]
	then
		p=$(cat /var/run/ifacefailover2.pid)
		name=$(cat /proc/${p}/cmdline 2>/dev/null | grep ifacefailover2 >/dev/null)
		if [ $? = "0" ]
		then
			Log "Kill existing pid $p for principal process"
			kill -9 $p
		fi
	fi
	echo $$ >/var/run/ifacefailover2.pid

	if [ -f /var/run/ifacerescuesvp2.pid ]
	then
		p=$(cat /var/run/ifacerescuesvp2.pid)
		name=$(cat /proc/${p}/cmdline 2>/dev/null | grep ifacerescuesvp2 >/dev/null)
		if [ $? = "0" ]
		then
			Log "Kill existing pid $p for rescue process"
			kill -9 $p
		fi
	fi

}

rescueSpv()
{
	SystemGetFilePath "$SERVROOTDIR" "ifacerescuesvp2.sh"
	$sysfilepath > /dev/null 2>&1 &
	PRINCIPAL_PID=$$
	RESCUE_PID=$!
}

##
## @fn create_static_ip_files
## @brief may create /run/gwip.<interface> and /run/resolv.conf.<interface>, depending on configuration
##
## @param INTERFACE  interface name
## @retval O:OK, INCONSISTENT_CONFIG: interface not defined in system file, 1: other issues
##
create_static_ip_files()
{
	INTERFACE=$1

	[ -z "$INTERFACE" ] && return 1

	if is_cellular $INTERFACE
	then
		return 0
	fi

	ret=0

	if grep "iface ${INTERFACE} inet" ${SYSNETW_FILE}; then
		# Interface configured using ${SYSNETW_FILE}
		grep "iface ${INTERFACE} inet" ${SYSNETW_FILE} | grep dhcp
		if [ $? -ne 0 ]; then
			grep -E -A1000 "iface\s+${INTERFACE}" ${SYSNETW_FILE} | sed '/gateway/q' | grep gateway | awk '$1=$1' | cut -d' ' -f2 > /run/gwip.${INTERFACE}
			rm /run/resolv.conf.${INTERFACE}
			cp /dev/null /run/resolv.conf.${INTERFACE}
			if [ -f ${STATICCONF}.${INTERFACE} ]; then
				. ${STATICCONF}.${INTERFACE}
				[ ! -z "$DNSSERVER1" ] && echo "nameserver $DNSSERVER1" >> /run/resolv.conf.${INTERFACE}
				[ ! -z "$DNSSERVER2" ] && echo "nameserver $DNSSERVER2" >> /run/resolv.conf.${INTERFACE}
			else
				for dns in $(grep -E -A1000 "iface\s+${INTERFACE}" ${SYSNETW_FILE} | sed '/dns-nameservers/q' | grep dns-nameservers | awk '$1=$1' | sed 's/dns-nameservers\s*//'); do
					echo "nameserver $dns" >> /run/resolv.conf.${INTERFACE}
				done
			fi
		fi
	else
		# PT-1664: the interface doesn't exist in the network file so looks like an inconsistency to be reported
		# Used on Kerlink to detect error but is system file used on all gateways (maybe firmware to be tested)
		ret=$INCONSISTENT_CONFIG
	fi
	return $ret
}

# =================================================================================
# All previously defined functions can be superseded with target specific ones
# =================================================================================

# Load custom
SystemGetFilePath "$SERVROOTDIR" ipfailover_custom.sh
[ -f "$sysfilepath" ] && source $sysfilepath



Log "#############################################"
Log "### Start $$"
Log "#############################################"

# If not active (lrr.ini:[services].ipfailover2=1) just do nothing
# A ipfailover2 restart is required to reread configuration
active=$(getIniConf $ROOTACT/usr/etc/lrr/lrr.ini services ipfailover2)
[ $? = 0 ] && active=$(getIniConf $ROOTACT/lrr/config/lrr.ini services ipfailover2)

if [ "$active" != "1" ]
then
	Log "ipfailover2 unactivated, doing nothing ..."
	while true
	do
		sleep 3600
	done
	exit 1
else
	ipfailover2_prestart_hook
fi

# clean table 100
remove_old_ip_rules

loadConfig
killExisting

PRINCIPAL_SAVE=${PRINCIPAL}
RESCUE_SAVE=${RESCUE}
RESCUESVP_SAVE=${RESCUESVP}
DNS_ITF=${PRINCIPAL}

[ ! -f /run/gwip.${PRINCIPAL} ] && ip route | grep -qE "default .* dev ${PRINCIPAL}" && ip route | grep -E "default .* dev ${PRINCIPAL}" | cut -d' ' -f3 > /run/gwip.${PRINCIPAL}
[ ! -f /run/gwip.${RESCUE} ] && ip route | grep -qE "default .* dev ${RESCUE}" && ip route | grep -E "default .* dev ${RESCUE}" | cut -d' ' -f3 > /run/gwip.${RESCUE}

# Create gw/resolv for static interfaces
create_static_ip_files $PRINCIPAL
create_static_ip_files $RESCUE

RESOLV_INT=/run/resolv.conf.${PRINCIPAL}
GATEWAY_INT=/run/gwip.${PRINCIPAL}
set_route $PRINCIPAL

if ! check_dns $PRINCIPAL; then
	update_dns $PRINCIPAL
fi

# If interface is NOT up or no ping success, force interface restart (check return valid ping count, ie 0 is actually failure)
if ! checkInterfaceStatus $PRINCIPAL || check $PRINCIPAL
then
	restartInterface $PRINCIPAL
fi

rescueSpv

Log "sleep 10"
### give time to have the eth0 gateway in /tmp/gateway.eth0
sleep 5
ifconfig >>${LOGFILE}
route -n >>${LOGFILE}

while true
do
	checks
done
