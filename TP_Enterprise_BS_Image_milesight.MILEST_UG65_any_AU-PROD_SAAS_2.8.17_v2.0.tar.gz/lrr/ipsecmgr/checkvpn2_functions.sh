#!/bn/sh
# vim:ft=sh:set noet ts=4 sw=4:
#
#   			checkvpn2.sh
#
#   Monitor VPN state:
#   - look for a process named charon or charon-tkm. Execute "ipsec start" if missing
#   - check state of the connections. Execute "ipsec stop" + "ipsec start" if state is not ESTABLISHED

if [ -f /var/run/lrrsystem ]; then
    . /var/run/lrrsystem
fi

setting=${ROOTACT}/lrr/com/system_setting.sh
if [ -f $setting ]; then
    . $setting
else
    . $ROOTACT/lrr/base/TARGET
    . $ROOTACT/usr/etc/lrr/_parameters.sh
fi

. $ROOTACT/lrr/com/_functions.sh
. ${ROOTACT}/lrr/com/system_api.sh

# init particular setting to avoid undefined variables in numeric comparison
KERLINK_SECURE=0
HOST_IPSEC=0
HOST_CONF_INSTALLED=0

# Commands & configuration: exported tp all scripts
OPENSSL_BINARY="openssl"
CONFIG_LD_LIBRARY_PATH=""

DBG_LOG() {
	if [ "$VERBOSE" = "yes" ]
	then
		if [ ! -z "$TRACEFILE" ]
		then
			echo "$1" >> $TRACEFILE
		else
			echo "$1"
		fi
	fi
}

DBG_CAT() {
    if [ "$VERBOSE" = "yes" ]
    then
        if [ ! -z "$TRACEFILE" ]
        then
            cat "$1" >> $TRACEFILE
        else
            cat "$1"
        fi
    fi

}

# From checkvpn2.conf
if [ -f $ROOTACT/lrr/ipsecmgr/checkvpn2.conf ]
then
	. $ROOTACT/lrr/ipsecmgr/checkvpn2.conf
	cvLoadConf
fi

# is there a additional file for this model (can superseded some setting)
SystemGetFilePath "$ROOTACT/lrr/ipsecmgr" "_checkvpn2_custom_functions.sh"
if [ -f "$sysfilepath" ]; then
    . $sysfilepath
fi

DAEMON_NAME="charon"
if [ -f "$FLAG_SECURE_STORE" ]
then
    DAEMON_NAME="charon-tkm"
fi

# get LRR UUID
UID_MODE=$(getGlobalIniConf lrr uidmode)

LRR_UUID=$(echo "$LRROUI-$LRRGID" | tr '[a-z]' '[A-Z]')
if [ -z $UID_MODE -o $UID_MODE = "local" ]; then
	getLrrId
	LRR_UUID=${LRR_ID}
fi
DECRYPTION_KEY=$(echo "pass:")
DECRYPTION_KEY=$DECRYPTION_KEY"$(echo "${LRR_UUID}" | tr '[a-z]' '[A-Z]')"

INFRAINI="$LOCAL_ETC/infra.ini"
IPFAILOVER2INI="$ROOTACT/usr/etc/lrr/ipfailover2.ini"
LOCAL_VPN_KEYS="$LOCAL_ETC/localkeys"
CNXCHECK="$CMDVPN status"
STARTVPN="$CMDVPN start"
STOPVPN="$CMDVPN stop"
CNXDOWN="$CMDVPN down"
CNXUP="$CMDVPN up"
LOOPWAIT=120             		# Time (seconds) between each check
LOOPWAIT=$(getSystemIniConf "checkvpn2" "vpncheckfreq" $LOOPWAIT)
MAXWAITCONFIGURING=240  		# Max time waiting in state configuring before trying a restart
MAXWAITDISCONNECTED=300 		# Max time waiting disconnected before trying to get a new configuration
LASTUP=0	  			# last time the VPN was up
LASTUP_BEFORE_NEW_CONF=$(date +%s)	# Initialization - Initial time or last time the VPN was up

# management of certificates expiration
MAXWAITBEFORERENEW=5			# Number of days before expiration to start trying to download new certificates
MAXDOWNLOADNEWPERDAY=3			# Max number of attempts of downloading new certificates per day
LAST_DOWNLOAD_NEW=0				# last time downloading a new certificate was tried because current ones are close to expiration

VERBOSE=no

get_opt() {
	sed -e "s;^[[:space:]]*;;" -e "s;[[:space:]]*$;;" \
		-e "s;[[:space:]]*=[[:space:]]*;=;" "$1" |
		grep -i "^$2=" | sed -e "s;^[^=]*=;;"
}

# rollback timer in progress ? no autocommit on applied but not commited conf : break rollback
isRollbacktimerOn()
{
	ls $ROOTACT/usr/data/lrr/lrrplan/[0-9]*-rollback
	return $?
}

# UpdateLrrConf
# This function is used to update SLRC addresses in ipfailover2 conf and lrr conf
_updateAddresses()
{
	# If NFR920 is disabled, checkvpn2 shall not force route update to LRC/SLRC (may be not pingeable)
	nfr920=$(getIniConf $ROOTACT/usr/etc/lrr/lrr.ini suplog nfr920)
	[ -z "$nfr920" ] && nfr920=0

	DBG_LOG "Check need for changing slrc addresses in lrr.ini"
	lrrmgr="$ROOTACT/lrr/com/cmd_shells/genericmgr.sh lrrmgr"
	failmgr="$ROOTACT/lrr/com/cmd_shells/genericmgr.sh failovermgr"
	tmpfile="/tmp/_checkvpn2$$"

	netitf0_ping=$(getIniConf $ROOTACT/usr/etc/lrr/lrr.ini "netitf:0" pingaddr | sed s"/:.*//")
	netitf1_ping=$(getIniConf $ROOTACT/usr/etc/lrr/lrr.ini "netitf:1" pingaddr | sed s"/:.*//")

	if [ -f "$INFRAINI" ]
	then
		slrc1=$(getIniConf $INFRAINI "laplrc:0" tls | sed s"/:.*//")
		slrc2=$(getIniConf $INFRAINI "laplrc:1" tls | sed s"/:.*//")
	fi

	# Use alternative method if infra.ini does not exist or no info were retrieved from file
	if [ ! -z $IPSECCONF ] && ( [ ! -f "$INFRAINI" ] || [ -z "$slrc1" -a -z "$slrc2" ] )
	then
		slrc1=$(cat $IPSECCONF | sed 's/#.*//' | sed -n "/^conn lrc1/,/^[^ \t]/p" | awk "/^[ \t]*right[ \t]*=/" | sed "s/.*=//")
		slrc2=$(cat $IPSECCONF | sed 's/#.*//' | sed -n "/^conn lrc2/,/^[^ \t]/p" | awk "/^[ \t]*right[ \t]*=/" | sed "s/.*=//")
	fi

	if [ -z "$slrc1" -a -z "$slrc2" ]; then
		DBG_LOG "Unable to get SLRCs address from config"
		return 1
	fi


	# Default to slrc1 for ping addr
	pingaddr=""
	[ ! -z "$slrc2" ] && pingaddr="$slrc2"
	[ ! -z "$slrc1" ] && pingaddr="$slrc1"

	lrrIniUpdated=0
	if [ ! -z "$pingaddr" ]
	then
		rm -f $tmpfile
		if [ $nfr920 -eq 1 ]; then
			[ "$netitf0_ping" != "$pingaddr" ] && lrrIniUpdated=1
			[ "$netitf1_ping" != "$pingaddr" ] && lrrIniUpdated=1
		else
			# When NFR920 is disabled, only force pingaddr to SLRC when pingaddr are empty
			# to avoid unreachable private IP LRC issue on rescue interface
			[ -z "$netitf0_ping" ] && lrrIniUpdated=1
			[ -z "$netitf1_ping" ] && lrrIniUpdated=1
		fi
		if [ $lrrIniUpdated -eq 1 ]; then
			DBG_LOG "Change detected: updating slrc addresses in lrr.ini"
			echo "[netitf:0]" >> $tmpfile
			echo "	pingaddr=$pingaddr" >> $tmpfile
			if ip rule > /dev/null 2>&1; then
				echo "	pingaddrsrc=@itf" >> $tmpfile
			else
				echo "	pingaddrsrc=" >> $tmpfile
			fi
			echo "[netitf:1]" >> $tmpfile
			echo "	pingaddr=$pingaddr" >> $tmpfile
			if ip rule > /dev/null 2>&1; then
				echo "	pingaddrsrc=@itf" >> $tmpfile
			else
				echo "	pingaddrsrc=" >> $tmpfile
			fi

			if [ "$VERBOSE" = "yes" ]
			then
				if [ ! -z "$TRACEFILE" ]
				then
					{
						echo "File for lrr.ini:"
						cat $tmpfile
					} >> $TRACEFILE
				fi
			fi
			if isRollbacktimerOn; then
				DBG_LOG "$lrrmgr --apply $tmpfile lrr.ini"
				$lrrmgr --apply $tmpfile lrr.ini
			else
				DBG_LOG "$lrrmgr --autocommit $tmpfile lrr.ini"
				$lrrmgr --autocommit $tmpfile lrr.ini
			fi
		fi
	fi
	rm -f $tmpfile

	# No further automatic configuration if NFR920 is disabled
	[ $nfr920 -eq 0 ] && return 0

	DBG_LOG "Check need for changing slrc addresses in ipfailover2.ini"
	ipFOIniUpdated=0
	if [ ! -z "$slrc1" -o ! -z "$slrc2" ] && [ -f $IPFAILOVER2INI ]
	then
		primary=$(getIniConf $IPFAILOVER2INI "ipfailover2" principal)
		secondary=$(getIniConf $IPFAILOVER2INI "ipfailover2" rescue)

		slrclst=$(echo "\"$slrc1 $slrc2\"" | sed 's/[ \t]*\"$/\"/')
		ipforoutes=$(getIniConf $IPFAILOVER2INI "ipfailover2" routes)
		ipforescueroutes=$(getIniConf $IPFAILOVER2INI "ipfailover2" rescueroutes)

		[ "$slrclst" != "$ipforoutes" ] && ipFOIniUpdated=1 && DBG_LOG "slrclst : $slrclst / ipforoutes : $ipforoutes : routes updated to slrcs"
		[ "$slrclst" != "$ipforescueroutes" ] && [ ! -z "$secondary" ] && ipFOIniUpdated=1 && DBG_LOG "slrclst : $slrclst / ipforescueroutes : $ipforescueroutes : rescueroutes updated to slrcs"

		if [ $ipFOIniUpdated -eq 1 ]; then
			DBG_LOG "Change detected: updating slrc addresses in ipfailover2.ini"
			echo "{" >> $tmpfile
			echo "	\"ipfailover2\": {" >> $tmpfile
			echo "		\"ints\": [" >> $tmpfile
			if [ ! -z "$primary" ]
			then
				echo "		{" >> $tmpfile
				echo "			\"status\": \"primary\"," >> $tmpfile
				echo "			\"icmpdests\": [" >> $tmpfile
				echo "				\"$slrc1 $slrc2\"" | sed 's/[ \t]*\"$/\"/' >> $tmpfile
				echo "			]" >> $tmpfile
				if [ ! -z "$secondary" ]
				then
					echo "		}," >> $tmpfile
				else
					echo "		}" >> $tmpfile
				fi
			fi
			if [ ! -z "$secondary" ]
			then
				echo "		{" >> $tmpfile
				echo "			\"status\": \"secondary\"," >> $tmpfile
				echo "			\"icmpdests\": [" >> $tmpfile
				echo "				\"$slrc1 $slrc2\"" | sed 's/[ \t]*\"$/\"/' >> $tmpfile
				echo "			]" >> $tmpfile
				echo "		}" >> $tmpfile
			fi
			echo "		]" >> $tmpfile
			echo "	}" >> $tmpfile
			echo "}" >> $tmpfile
			if [ "$VERBOSE" = "yes" ]
			then
				if [ ! -z "$TRACEFILE" ]
				then
					{
						echo "File for ipfailover2.ini:"
						cat $tmpfile
					} >> $TRACEFILE
				fi
			fi
			if isRollbacktimerOn; then
				DBG_LOG "$failmgr --apply < $tmpfile"
				$failmgr --apply < $tmpfile
			else
				DBG_LOG "$failmgr --autocommit < $tmpfile"
				$failmgr --autocommit < $tmpfile
			fi
		fi
	fi
	rm -f $tmpfile
}

updateIpsecIgnoreRoutingTables()
{
	if grep -rqE '^\s*ignore_routing_tables\s*=' ${LOCAL_ETC}; then
		res=$(grep -rE '^\s*ignore_routing_tables\s*=' ${LOCAL_ETC})
		file=$(echo $res | cut -f1 -d':')
		tables=$(grep -E '^\s*ignore_routing_tables\s*=' ${file} | cut -f2 -d'=' | sed 's/^\s//g' | tr -s ' ' | tr ',' '\n')
		for table in $tables
		do
			if [ $table = "100" ]; then
				table100=1
			fi;
			tables_output="${tables_output} ${table}"
		done;
		if [ -z $table100 ]; then
			tables_output="${tables_output} 100"
		fi
		sed -i "s/^\s*ignore_routing_tables\s*=.*/\tignore_routing_tables = ${tables_output}/g" ${file}
	else
		if grep -rqE '^\s*#\s*ignore_routing_tables\s*=' ${LOCAL_ETC}; then
			res=$(grep -rE '^\s*#\s*ignore_routing_tables\s*=' ${LOCAL_ETC})
			file=$(echo $res | cut -f1 -d':')
			sed -i 's/\s*#\s*ignore_routing_tables\s*=.*/\tignore_routing_tables = 100/g' ${file}
		else
cat << EOF >> ${LOCAL_ETC}/strongswan.conf
charon {
	ignore_routing_tables = 100
}
EOF
		fi
	fi
}

# Fix strongswan.conf for Strongswan >= 5.7.0
fixLogging()
{
    strongswan_conf_file=$1
    strongswan_new_syntax=0
    strongswan_version=$(ipsec version | grep -oiE 'strongSwan U[0-9]+\.[0-9]+\.[0-9]+' | sed 's/strongswan\s*U*//I')
    if [ ! -z "$strongswan_version" ]; then
        strongswan_version_major=$(echo "$strongswan_version" | cut -f1 -d.)
        strongswan_version_minor=$(echo "$strongswan_version" | cut -f2 -d.)
        strongswan_version_patch=$(echo "$strongswan_version" | cut -f3 -d.)
        if [ ! -z "$strongswan_version_major" ] && [ ! -z "$strongswan_version_minor" ]; then
            if [ $strongswan_version_major -gt 5 ]; then
                strongswan_new_syntax=1
            elif [ $strongswan_version_major -eq 5 ] && [ $strongswan_version_minor -ge 7 ]; then
                strongswan_new_syntax=1
            fi
        fi
    fi

    if [ $strongswan_new_syntax -eq 1 ]; then
        DBG_LOG "StrongSwan version ${strongswan_version_major}.${strongswan_version_minor}.${strongswan_version_patch} found... Using new syntax for log path"
        # change old syntax f used to new one
        sed -i "s/\/var\/log\/charon.log\s*{/charon \{\n\t\t\tpath = \/var\/log\/charon.log/" $strongswan_conf_file
    else
        DBG_LOG "StrongSwan version ${strongswan_version_major}.${strongswan_version_minor}.${strongswan_version_patch} found... Using old syntax for log path"
        # change new syntax if used to new one
        cat << EOF > /tmp/sed.txt
/charon\s*{/ {
    #check next line to see if it contains "path = ..."
    N;
    /path\s*=/ {
        s/path =.*//
        s/charon/\/var\/log\/charon.log/
        p;
        d;
    }
}
EOF
        sed -i -f /tmp/sed.txt $strongswan_conf_file
        sed -i "s/default = 1/default = -1/g" $strongswan_conf_file
    fi
}

# Check VPN state with ipsec command
# return best state: 0=down, 1=connecting, 2=up
CheckVpnCnx()
{

	DBG_LOG "Check VPN connections"

	if [ "$HOST_IPSEC" -eq 1 ]; then
		beststate=0
		# use the local ipsec.conf to know the list of server to check
		# IPSECCONF is set to a fake file: use the actual path
		cnx_list=$(grep -E '^conn [^%]' ${LOCAL_ETC}/ipsec.conf | cut -f2 -d ' ')
		if [ -z "$cnx_list" ]; then
			if [ ! -f "${LOCAL_ETC}/ipsec.conf" ]; then
				DBG_LOG "ERROR: ${LOCAL_ETC}/ipsec.conf missing!"
			else
				DBG_LOG "ERROR: connection list not found in  ${LOCAL_ETC}/ipsec.conf"
				DBG_LOG "-----------------"
				DBG_CAT ${LOCAL_ETC}/ipsec.conf
				DBG_LOG "-----------------"
			fi
		fi
		for cnx in $cnx_list
		do
			host_check_connection $cnx
			res=$?
			if [ $res -eq 0 ]
			then
				# down
				# - restart connection
				host_stop_connection $cnx
				host_start_connection $cnx
				beststate=1
			elif [ $res -eq 1 ]
			then
				# connecting
				[ $beststate -lt 1 ] && beststate=1
			else
				# up
				[ $beststate -lt 2 ] && beststate=2
				LASTUP=$(date +%s)
				LASTUP_BEFORE_NEW_CONF=$(date +%s)
			fi
		done
		return $beststate
	fi

	beststate=0
	# Parse all connection from ipsec.conf
	for cnx in $(grep -E '^conn [^%]' ${IPSECCONF} | cut -f2 -d ' ')
	do
		res=$($CNXCHECK $cnx)
		DBG_LOG "$cnx >>>>> $res"
		if [ -z "$res" ]
		then
			DBG_LOG "$cnx: down"
			$CNXDOWN $cnx
			$CNXUP $cnx
			beststate=1
			continue
		fi
		res2=$(echo "$res" | grep INSTALLED)
		if [ ! -z "$res2" ]
		then
			DBG_LOG "$cnx: up"
			# Check if routes are up
			if [ -z "$(ip route show table 220 | grep $(echo "$res" | grep -Eo "${CONN}.*:.*===.*" | sed 's/^\s*//g' | tr -s ' ' |  cut -f 4 -d ' '))" ]; then
				# Routes are not up, something went wrong
				DBG_LOG "$cnx: connection installed, but routes are not set-up."
				$CNXDOWN $cnx
				$CNXUP $cnx
				beststate=1
			else
				# Check if IPSEC status virtual IP is attached to a virtual interface
				res3=$(ip address | grep $(echo "$res" | grep -Eo "${CONN}.*:.*===" | sed 's/^\s*//g' | tr -s ' ' |  cut -f 2 -d ' '))
				if [ ! -z "$res3" ]
				then
					[ $beststate -lt 2 ] && beststate=2
					LASTUP=$(date +%s)
					LASTUP_BEFORE_NEW_CONF=$(date +%s)
				else
					DBG_LOG "$cnx: ip not bind"
					$CNXDOWN $cnx
					$CNXUP $cnx
					beststate=1
				fi
			fi
			continue
		fi
		res2=$(echo "$res" | grep CONNECTING)
		if [ ! -z "$res2" ]
		then
			echo "$cnx: connecting"
			[ $beststate -lt 1 ] && beststate=1
			continue
		fi
		res2=$(echo "$res" | grep "no match")
		if [ ! -z "$res2" ]
		then
			echo "$cnx: down"
			echo "$CNXDOWN $cnx"
			$CNXDOWN $cnx
			echo "$CNXUP $cnx"
			$CNXUP $cnx
			beststate=1
			continue
		fi
		DBG_LOG "$cnx: ???"
	done
	return $beststate
}

# Check if VPN is configured
CheckVpnConfigured()
{
    # case of container with host ipsec: call on gateway specific checking
	if [ "$HOST_IPSEC" -eq 1 ]; then

		res=$(grep lrc ${LOCAL_ETC}/ipsec.conf)
		if [ -z "$res" ]
		then
			DBG_LOG "No connection information in ${LOCAL_ETC}/ipsec.conf"
			return 1
		fi
		# check that all connection are correctly configured
		cnx_list=$(grep -E '^conn [^%]' ${LOCAL_ETC}/ipsec.conf | cut -f2 -d ' ')
		host_check_configuration $cnx_list
		return $?
	fi

	DBG_LOG "Check VPN configuration"

	if [ ! -f "$CMDVPN" ]
	then
		DBG_LOG "vpn not installed"
		return 1
	fi

	res=$(grep lrc $IPSECCONF)
	if [ -z "$res" ]
	then
		DBG_LOG "vpn not configured in ${IPSECCONF}"
		return 1
    fi

	if [ "$FIRMWARE" = "keros" -a $KERLINK_SECURE_STORE -eq 1 ]; then
		are_certificates_installed
		if [ $? == "1" ]; then
			DBG_LOG "vpn not installed configured"
			return 1
		fi
		set_certificates_installed
	fi

    #nothing shows that certificates are not installed so return 0
    return 0
}

# Check if VPN process charon is running
CheckVpnProcess()
{

	if [ "$HOST_IPSEC" -eq 1 ]; then
		host_check_vpn_process
		return $?
	fi

	DBG_LOG "Check VPN process"

	if [ ! -z $(pidof starter) ] && [ ! -z $(pidof ${DAEMON_NAME}) ]
	then
		DBG_LOG "vpn process: ok"
		return 0
	else
		DBG_LOG "vpn process: error"
		return 1
	fi
}

CheckVpnValidity()
{
	# Function check validity of certificates and in case they expire in less than a certain number of days
	# it will run the process to get the new certificate files.

	DBG_LOG "Check Certificates Expiration"

	if [ "$HOST_IPSEC" -eq 1 ]; then
        # must set HOST_REMAINING_1 to 3
		host_get_certificates_expiration
		DaysToExpire1=$HOST_REMAINING_1
		DaysToExpire2=$HOST_REMAINING_2
		DaysToExpire3=$HOST_REMAINING_3
	else
		DaysToExpire=$(${CMDVPN}  listcerts | grep expires |  awk '{print $10}')
		DaysToExpire1=$(echo -e $DaysToExpire | awk '{print $1}')
		DaysToExpire2=$(echo -e $DaysToExpire | awk '{print $2}')
		DaysToExpire3=$(echo -e $DaysToExpire | awk '{print $3}')
    fi

	DaysBeforeGetNEW="$MAXWAITBEFORERENEW"
	if [ "$DaysToExpire1" -le "$DaysBeforeGetNEW" ] || [ "$DaysToExpire2" -le "$DaysBeforeGetNEW" ] || [ "$DaysToExpire3" -le "$DaysBeforeGetNEW" ]
	then

		# limit the number of attempts per day
		now=$(date +%s)
		NB_SEC_PER_DAY=86400 # 24 * 60 * 60
		nexttry=$(($LAST_DOWNLOAD_NEW + ($NB_SEC_PER_DAY / $MAXDOWNLOADNEWPERDAY)))
		if [ $nexttry -lt $now ]
		then
			LAST_DOWNLOAD_NEW=$now
			DBG_LOG "Time to Get New VPN Keys"
			GetVpnKeys
			if [ $? = 0 ]
			then
				DBG_LOG "Certificates downloaded. Need to restart VPN"
				# Reload (Re-Read) ALL IPSEC Data
				# ipsec rereadall
				RestartVpnProcess
			else
				DBG_LOG "Failed to download new certificates"
			fi
		fi
	else
		echo "$LINENO - Keys are valid"
		echo $DaysToExpire1 $DaysToExpire2 $DaysToExpire3
	fi
}

# Get initial local VPN keys
GetLocalVpnKeys()
{
	if [ -z "$LOCAL_VPN_KEYS" ] || [ ! -f "$LOCAL_VPN_KEYS" ]
	then
		return 1
	fi

	DBG_LOG "Getting local VPN keys"

	# create directories and copy files
	IPSEC_D="$LOCAL_ETC/ipsec.d"
	[ ! -d "$IPSEC_D" ] && mkdir $IPSEC_D

	cp $LOCAL_VPN_KEYS/ipsec.conf $LOCAL_ETC
	cp $LOCAL_VPN_KEYS/ipsec.secrets $LOCAL_ETC
	cp $LOCAL_VPN_KEYS/strongswan.conf $LOCAL_ETC

	cp -r $LOCAL_VPN_KEYS/cacerts $IPSEC_D
	cp -r $LOCAL_VPN_KEYS/certs $IPSEC_D
	cp -r $LOCAL_VPN_KEYS/private $IPSEC_D

	[ ! -d "$IPSEC_D/acerts" ] && $IPSEC_D/acerts
	[ ! -d "$IPSEC_D/ocspcerts" ] && mkdir $IPSEC_D/ocspcerts
	[ ! -d "$IPSEC_D/crls" ] && mkdir $IPSEC_D/crls

	chmod 644 $IPSEC_D/certs/*.pem
	chmod 600 $IPSEC_D/private/*

	fixLogging "$LOCAL_ETC/strongswan.conf"
	# update slrc addresses in lrr.ini and ipfailover2.ini
	_updateAddresses

	DBG_LOG "configuration finished"
	return 0
}

# Get initial VPN keys
GetVpnKeys()
{
	DBG_LOG "Getting VPN keys"

	# start configuration
	VPN_CFG="$ROOTACT/usr/etc/lrr/vpn.cfg"
	if [ ! -f "$VPN_CFG" ]
	then
		if [ -z "$LOCAL_VPN_KEYS" ]
		then
			DBG_LOG "Missing download server cfg file"
		else
			# Retrieve initial local VPN keys
			GetLocalVpnKeys
		fi
		return 1
	fi

	PLATFORM=$(grep -e "PLATFORM=" $VPN_CFG | cut -d"=" -f2)
	OPERATOR=$(grep -e "OPERATOR=" $VPN_CFG | cut -d"=" -f2)

	SRV=$(grep -e "SRV=" $VPN_CFG | cut -d"=" -f2)
	ID=$(grep -e "PRESTAGER=" $VPN_CFG | cut -d"=" -f2)
	KEY=$(grep -e "KEY=" $VPN_CFG | cut -d"=" -f2)
	PASS=$(grep -e "PASS=" $VPN_CFG | sed -e 's/^PASS=//')
	USE_IDENTITY=$(get_opt $VPN_CFG "USE_IDENTITY")
	PORT=$(get_opt $VPN_CFG "PORT")
	[ -z "$PORT" ] && PORT=22

	PRIVKEYFILE=$(getIniConf $ROOTACT/usr/etc/lrr/lrr.ini suplog privatekeyfile)
	[ $? = 0 ] && PRIVKEYFILE=$(getIniConf $ROOTACT/lrr/config/lrr.ini suplog privatekeyfile)
	[ ! -z "$PRIVKEYFILE" ] && eval "PRIVKEYFILE=$PRIVKEYFILE"	# to eval ${ROOTACT}

	#CFG_TAR="LRR_${LRR_UUID}.tar.gz"
	CFG_TAR="Lrr_${PLATFORM}_${OPERATOR}_${LRR_UUID}.tar.gz"
	ENC_TAR="${CFG_TAR}.enc"

	if [ -z "$SRV" ] || [ -z "$ID" ] || [ -z "$KEY" ] || [ -z "$PASS" ]
	then
		DBG_LOG "Missing download server configuration"
		return 1
	fi

	if [ "${USE_IDENTITY}" = "1" ]
	then
		USER=$(get_opt $VPN_CFG "USER")
		if [ -z "$USER" ]
		then
			DBG_LOG "Missing download server configuration"
			return 1
		fi
	else
		USER="download${ID}"
		if [ -z "$KEY" ] || [ -z "$PASS" ]
		then
			DBG_LOG "Missing download server configuration"
			return 1
		fi
	fi

	LOC_DIR="/tmp/secure"
	SRV_DIR="/Lrr_${PLATFORM}_${OPERATOR}_${LRR_UUID}"
	CFG_DIR="${ID}${SRV_DIR}"

	[ ! -d "${LOC_DIR}" ] && mkdir ${LOC_DIR}
	cd ${LOC_DIR}

	DBG_LOG "Retrieving ${SRV_DIR}/${ENC_TAR}"
	if [ "${USE_IDENTITY}" = "1" ]
	then
		DBG_LOG "lrr_DownloadFromRemote -u ${USER} -i ${PRIVKEYFILE} -p ${PORT} -a ${SRV} -r ${SRV_DIR}/${ENC_TAR} -l ${LOC_DIR}/${ENC_TAR} -s 1"
		lrr_DownloadFromRemote -u ${USER} -i ${PRIVKEYFILE} -p ${PORT} -a ${SRV} -r ${SRV_DIR}/${ENC_TAR} -l ${LOC_DIR}/${ENC_TAR} -s 1
	else
		if [ "$NOENCODE" = "1" ]
		then
			password=$PASS
		else
			password=$(echo "$PASS" | ${OPENSSL_BINARY} enc -md md5 -aes-256-cbc -base64 -d -pass pass:"${KEY}+${ID}" | awk '{ printf $1 }')
		fi

		if [ -z "$password" ]
		then
			DBG_LOG "Wrong password!"
			return 1
		fi
		DBG_LOG "lrr_DownloadFromRemote -u ${USER} -w XXXXXXXX -p ${PORT} -a ${SRV} -r ${SRV_DIR}/${ENC_TAR} -l ${LOC_DIR}/${ENC_TAR} -s 1"
		lrr_DownloadFromRemote -u ${USER} -w ${password} -p ${PORT} -a ${SRV} -r ${SRV_DIR}/${ENC_TAR} -l ${LOC_DIR}/${ENC_TAR} -s 1
	fi

	if [ ! -f "${ENC_TAR}" ]
	then
		DBG_CAT $LRR_CMD_LOG
		DBG_LOG "Couldn't retrieve configuration files."
		return 1;
	fi

	if [ "$NOENCODE" = "1" ]
	then
		mv ${ENC_TAR} ${CFG_TAR}
	else
		#v1.4 version
		${OPENSSL_BINARY} enc -md md5 -aes-256-cbc -d -in ${ENC_TAR} -out ${CFG_TAR} -pass $DECRYPTION_KEY
	fi
	tar xzvf ${CFG_TAR}
	if [ $? == 0 ]
	then

		if [ "$HOST_IPSEC" -ne 1 ]; then
			# not a container with IPsec on host side
			# create directories and copy files
			IPSEC_D="$LOCAL_ETC/ipsec.d"
			[ ! -d "$IPSEC_D" ] && mkdir $IPSEC_D

			cp $ID/Lrr_${PLATFORM}_${OPERATOR}_${LRR_UUID}/ipsec.conf $LOCAL_ETC
			cp $ID/Lrr_${PLATFORM}_${OPERATOR}_${LRR_UUID}/ipsec.secrets $LOCAL_ETC
			cp $ID/Lrr_${PLATFORM}_${OPERATOR}_${LRR_UUID}/strongswan.conf $LOCAL_ETC
			cp $ID/Lrr_${PLATFORM}_${OPERATOR}_${LRR_UUID}/infra.ini     ${INFRAINI}

			cp -r $ID/Lrr_${PLATFORM}_${OPERATOR}_${LRR_UUID}/cacerts $IPSEC_D
			cp -r $ID/Lrr_${PLATFORM}_${OPERATOR}_${LRR_UUID}/certs $IPSEC_D
			cp -r $ID/Lrr_${PLATFORM}_${OPERATOR}_${LRR_UUID}/private $IPSEC_D

			[ ! -d "$IPSEC_D/acerts" ] && mkdir $IPSEC_D/acerts
			[ ! -d "$IPSEC_D/ocspcerts" ] && mkdir $IPSEC_D/ocspcerts
			[ ! -d "$IPSEC_D/crls" ] && mkdir $IPSEC_D/crls

			chmod 644 $IPSEC_D/certs/*.pem
			chmod 600 $IPSEC_D/private/*

			fixLogging "$LOCAL_ETC/strongswan.conf"
			# update slrc addresses in lrr.ini and ipfailover2.ini
		else
			# file used to get the list of connections while checking status
			cp $ID/Lrr_${PLATFORM}_${OPERATOR}_${LRR_UUID}/ipsec.conf $LOCAL_ETC
			# PT-1883: _updateAddress uses IPSECCONF so be sure to get also a copy of the file at this place
			cp $ID/Lrr_${PLATFORM}_${OPERATOR}_${LRR_UUID}/ipsec.conf $IPSECCONF
		fi

		_updateAddresses

        # PT-1670: disable secure store on Kerlink when CN is too long
        [ "$FIRMWARE" = "keros" ] && check_securestore

        if [ "$FIRMWARE" = "keros" -a "$KERLINK_SECURE_STORE" -eq 1 ]; then
            DBG_LOG "Will start the encryption of the downloaded certificate"
			configure_encryption "${ID}${SRV_DIR}" "$LRR_UUID" "$LOCAL_ETC"
			if [ $? == 1 ]; then
				DBG_LOG "configure_encryption() failed"
				return 1
			fi
		fi

		# container with IPsec on host side
		if [ "$HOST_IPSEC" -eq 1 ]; then
			host_convert_configuration "$PWD/$ID/Lrr_${PLATFORM}_${OPERATOR}_${LRR_UUID}/ipsec.conf"
			if [ $? -ne 0 ]; then
				return $?
			fi
			host_convert_certificates "$PWD/$ID/Lrr_${PLATFORM}_${OPERATOR}_${LRR_UUID}"
			if [ $? -ne 0 ]; then
				return $?
			fi
			host_install_configuration
			if [ $? -ne 0 ]; then
				return $?
			fi
			host_install_certificates
			if [ $? -ne 0 ]; then
				return $?
			fi
			HOST_CONF_INSTALLED=1
		fi

		# Push an empty file on the SFTP server, under the /done subdirectory, to indicate that the archive has been downloaded and handled correctly
		# Then, for security reasons, the SFTP server will delete the archive
		echo > ${ENC_TAR}

		if [ "${USE_IDENTITY}" = "1" ]; then
			lrr_UploadToRemote -u ${USER} -i ${PRIVKEYFILE} -a ${SRV} -p ${PORT} -l ${ENC_TAR} -r "/done/${ENC_TAR}" -s 1
		else
			lrr_UploadToRemote -u ${USER} -w ${password} -a ${SRV} -p ${PORT} -l ${ENC_TAR} -r "/done/${ENC_TAR}" -s 1
		fi

		if [ "$LRR_CMD_STATUS" != 0 ]
		then
			DBG_CAT $LRR_CMD_LOG
			DBG_LOG "Warning: cannot upload Done file on server"
		fi

        # Delete the certificate copied to temporary dir
        rm -rf ${LOC_DIR}/

		DBG_LOG "configuration finished"
		if [ "$FIRMWARE" = "keros" -a $KERLINK_SECURE_STORE -eq 1 ]; then
			set_certificates_installed
            # remove certificate files now stored
            rm -rf $IPSEC_D/cacerts/ \
                   $IPSEC_D/certs/ \
                   $IPSEC_D/private/
		fi

		# remove useless files after host configuration
		if [ "$HOST_IPSEC" -eq 1 ]; then
			rm -rf $IPSEC_D/cacerts/ \
				$IPSEC_D/certs/ \
				$IPSEC_D/private/
		fi

		return 0
	else
		DBG_LOG "configuration failed"
		return 1
	fi
}

# Start VPN
StartVpnProcess()
{
	DBG_LOG "Starting VPN"
	$STARTVPN
}

# Stop VPN
StopVpnProcess()
{
	DBG_LOG "Stopping VPN"

	if [ "$HOST_IPSEC" -eq 1 ]; then
		host_stop_vpn
		return $?
	fi

	$STOPVPN
	if [ ! -z $(pidof starter) ]
	then
		DBG_LOG "Need to kill starter"
		kill -9 $(pidof starter)
	fi

	if [ ! -z $(pidof ${DAEMON_NAME}) ]
	then
		DBG_LOG "Need to kill $DAEMON_NAME"
		kill -9 $(pidof ${DAEMON_NAME})
	fi
}

# Restart VPN
RestartVpnProcess()
{
	StopVpnProcess
	sleep 5
	StartVpnProcess
}

Use()
{
	echo "checkvpn2.sh [-V] || [-v] start|stop"
	echo "  -v: verbose"
	echo "  -V: get version and exit"
	exit
}

StartMonitoring()
{

	while [ 1 ]
	do
		[ ! -z "$firstCall" ] && sleep $LOOPWAIT
		firstCall=no
		curDate=$(date +"%d/%m %H:%M:%S")
		DBG_LOG "$curDate Check VPN state"

		export LD_LIBRARY_PATH=/usr/python/lib:/usr/lib:/usr/lib/iptables
		DBG_LOG "Clear iptables nat"
		iptables -t nat -F
		iptables -t nat -X
		DBG_LOG "Clear iptables nat down,ret:$?"

		CheckVpnConfigured

		if [ $? -ne 0 ]
		then
			DBG_LOG "Not Configured"
			if [ ! -z "$CONFIG_LD_LIBRARY_PATH" ]
			then
				unset LD_LIBRARY_PATH
			fi

			GetVpnKeys
			if [ $? = 0 ]
			then
				RestartVpnProcess
			fi
		else
			# Ensure all ipfailover2/lrr ping adresses are ok
			_updateAddresses

			if [ ! -z "$CONFIG_LD_LIBRARY_PATH" ]
			then
				export LD_LIBRARY_PATH=$CONFIG_LD_LIBRARY_PATH
			fi

			# Check VPN Keys Validity
			# limit the number of attempts of downloading new certificates per day
			CheckVpnValidity

			CheckVpnProcess
			# Vpn not started
			if [ $? = 1 ]
			then
				RestartVpnProcess
				sleep 10
				continue
			fi
			CheckVpnCnx
			# best state is down
			cr=$?
			if [ $cr = 0 ]
			then
				DBG_LOG "Vpn down, restart"
				RestartVpnProcess
				continue
				# best state is connecting
			elif [ $cr = 1 ]
			then
				now=$(date +%s)
				restartTime=$(($LASTUP + $MAXWAITCONFIGURING))
				if [ $restartTime -lt $now ]
				then
					LASTUP=$(date +%s)
					echo "In state connecting for more than $MAXWAITCONFIGURING seconds, restart"
					CheckVpnCnx
				fi
			else
				# connections are UP
				# on host needing to save configuration, do it first time after after installing
				if [ "$HOST_IPSEC" -eq 1 ]
				then
					if [ "$HOST_CONF_INSTALLED" -eq 1 ]
					then
						host_commit_configuration
						HOST_CONF_INSTALLED=0
					fi
				fi
			fi

			# If the gateway has a configuration and cannot be connected for $MAXWAITDISCONNECTED, try to retrieve a new conf
			now=$(date +%s)
			newConfTime=$(($LASTUP_BEFORE_NEW_CONF + $MAXWAITDISCONNECTED))
			if [ $newConfTime -lt $now ]
			then
				GetVpnKeys
				LASTUP_BEFORE_NEW_CONF=$(date +%s)
				RestartVpnProcess
			fi

		fi
	done
}
