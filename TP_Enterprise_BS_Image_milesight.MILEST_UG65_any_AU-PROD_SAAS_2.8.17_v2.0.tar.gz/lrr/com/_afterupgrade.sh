#!/bin/sh

. $ROOTACT/lrr/com/system_setting.sh
. $ROOTACT/lrr/com/system_api.sh

FROM="${CURRENTVERSION}"
TO="${VERSION}"
FROMTO=${FROM}_${TO}

if [ -f ${ROOTACT}/lrr/com/_parameters.sh ]
then
	. ${ROOTACT}/lrr/com/_parameters.sh
fi
if [ -f ${ROOTACT}/lrr/com/_functions.sh ]
then
	. ${ROOTACT}/lrr/com/_functions.sh
fi


#
# update SYSTEM name where needed
#
updateSystemName() {
    old=$1
    new=$2

    # update _parameters.sh
    paramfile=$ROOTACT/usr/etc/lrr/_parameters.sh
    if [ -f "$paramfile" ]; then
        sed -i "s/SYSTEM=$old/SYSTEM=$new/g" $paramfile
    fi

    # update usr/etc/lrr/lrr.ini containing automatic system definition regarding netif
    userfile=$ROOTACT/usr/etc/lrr/lrr.ini
    if [ -f "$userfile" ]; then
        # change [<system>]
        sed -i "s/\[$old\]/\[$SYSTEM\]/g" $userfile
        # change [<system>/...]
        sed -i "s/\[$old\//\[$SYSTEM\//g" $userfile
    fi
}


# PT-1769: as SYSTEM name may be changed by the new version,
# perform needed changes if old and new system names are different

OLD=$SYSTEM

# PT-1826: force visibility of variables to caller
set -a

. $ROOTACT/lrr/com/system_setting.sh
if [ "$OLD" != "$SYSTEM" ]; then
    echo "Changing system name from $OLD to $SYSTEM"
    updateSystemName $OLD $SYSTEM
fi
# starting from now, settings are about the new system name if changed

echo	"_afterupgrade.sh on=$SYSTEM from=$FROM to=$TO"

# previoulsy sysconfiglrr.sh was run on a subset of gateways
# as sticky bit setting was not done for all, suplog.x fails when accessing its own logfile
# so no more restriction: done each time (requires also for partner's gateways)

${ROOTACT}/lrr/com/sysconfiglrr.sh

exit 0
