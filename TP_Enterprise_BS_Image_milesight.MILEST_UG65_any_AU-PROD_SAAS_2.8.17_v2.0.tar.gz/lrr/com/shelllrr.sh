#!/bin/sh

#PATH=${PATH//".:"/}
#PATH=${PATH//":.:"/}
export PATH=.:$PATH

LRRCMDSERIAL="0"
export LRRCMDSERIAL

COMMAND="${1}"
shift

DATE=$(date +%FT%T%z)

if	[ -z "$COMMAND" ]
then
	echo	"#no command"
	exit	1
fi

if	[ "${1}" = "-Z" ]
then
	shift
	LRRCMDSERIAL="${1}"
	export LRRCMDSERIAL
	shift
fi

if	[ "$COMMAND" = "stoplrr" -o "$COMMAND" = "stoplrr.sh" ]
then
	echo	"#lrr can not stop itself"
	exit	1
fi

if	[ "$COMMAND" = "startlrr" -o "$COMMAND" = "startlrr.sh" ]
then
	echo	"#lrr can not start itself"
	exit	1
fi

# new rootact definition
if [ -f /var/run/lrrsystem ]; then
    . /var/run/lrrsystem
fi

if	[ -z "$ROOTACT" ]
then
    # such a case should never happen as it would have failed on Kerlink 3.x
	export ROOTACT=/mnt/fsuser-1/actility
fi

if	[ ! -d "$ROOTACT" ]
then
	echo	"#ROOTACT does not exist"
	exit	1
fi

# execute a shell script
#
#   shell script name in $sysfilepath
#   argument in $args
#
executeShell() {

    if [ "$SHELL_MODE" = "exec" ]; then

        exec $sysfilepath $args

    else

	    echo $$ > $PPIDFILE
	    echo "#$sysfilepath $args"
	    echo "#"
	    $sysfilepath $args
	    ret=$?
	    pid=$!
	    echo $ret > $TERMFILE
	    [ -f $PPIDFILE ] && rm $PPIDFILE 2> /dev/null 2>&1
	    [ -f $PENDINGFILE ] && rm $PENDINGFILE 2> /dev/null 2>&1
    fi
}

# new mechanism
setting=${ROOTACT}/lrr/com/system_setting.sh
if [ -f $setting ]; then
    . $setting
else
    # already included by new mechanism
    if [ -f ${ROOTACT}/lrr/com/_parameters.sh ]
    then
	    . ${ROOTACT}/lrr/com/_parameters.sh
    fi
fi

if [ -f ${ROOTACT}/lrr/com/_functions.sh ]
then
 . ${ROOTACT}/lrr/com/_functions.sh
fi

lrr_CloseFiles

# old installs do not have SYSTEM in _parameters.sh
# new mechanism forces it on system definition file (so LRRSYSTEM should be based on)
if	[ -z "$SYSTEM" ]
then
	SYSTEM=$LRRSYSTEM
fi
export SYSTEM

if [ "$SHELL_MODE" != "exec" ]; then
    echo	"#"
    echo	"#DATE=$DATE"
    #echo	"#SYSTEM=$SYSTEM"
    echo	"#LRRSYSTEM=$LRRSYSTEM"
    echo	"#ROOTACT=$ROOTACT"
    echo	"#LRRCMDSERIAL=$LRRCMDSERIAL"
fi

cd $ROOTACT

PENDINGFILE=${ROOTACT}/usr/data/lrr/cmd_shells/${LRRCMDSERIAL}_pending
TERMFILE=${ROOTACT}/usr/data/lrr/cmd_shells/${LRRCMDSERIAL}_terminated
PPIDFILE=${ROOTACT}/usr/data/lrr/cmd_shells/${LRRCMDSERIAL}.pid

DIRCUSTOM=$ROOTACT/usr/etc/lrr/cmd_shells
DIRCOMMAND=$ROOTACT/lrr/com/cmd_shells

api=${ROOTACT}/lrr/com/system_api.sh
if [ -f "$api" ]; then
    args="$*"
    . $api
    # more categories: family, firmware and manufacturer in addition to system & generic
    SystemGetFilePath $DIRCUSTOM ${COMMAND}.sh
    if [ -x "${sysfilepath}" ]; then
        executeShell "${sysfilepath}"
        exit $ret
    fi
    SystemGetFilePath ${DIRCOMMAND} ${COMMAND}.sh
    if [ -x "${sysfilepath}" ]; then
        executeShell "${sysfilepath}"
        exit $ret
    fi
    echo	"#command ${COMMAND}.sh not found"
    exit 1

fi
# keep going with old mechanism
# old mechanism: only generic or system

if	[ -x ${DIRCUSTOM}/${COMMAND}.sh ]
then
	echo $$ > $PPIDFILE
	echo "#${DIRCUSTOM}/${COMMAND}.sh $*"
	echo "#"
	${DIRCUSTOM}/${COMMAND}.sh $*
	ret=$?
	pid=$!
	echo $ret > $TERMFILE
	[ -f $PPIDFILE ] && rm $PPIDFILE 2> /dev/null 2>&1
	[ -f $PENDINGFILE ] && rm $PENDINGFILE 2> /dev/null 2>&1
	exit $ret
fi

# command specific to the system but in the package
if	[ -x ${DIRCOMMAND}/${LRRSYSTEM}/${COMMAND}.sh ]
then
	echo $$ > $PPIDFILE
	echo "#${DIRCOMMAND}/${LRRSYSTEM}/${COMMAND}.sh $*"
	echo "#"
	${DIRCOMMAND}/${LRRSYSTEM}/${COMMAND}.sh $*
	ret=$?
	pid=$!
	echo $ret > $TERMFILE
	[ -f $PPIDFILE ] && rm $PPIDFILE 2> /dev/null 2>&1
	[ -f $PENDINGFILE ] && rm $PENDINGFILE 2> /dev/null 2>&1
	exit $ret
    echo	"#command ${COMMAND}.sh not found"
fi

# generic command
if	[ -x ${DIRCOMMAND}/${COMMAND}.sh ]
then
	echo $$ > $PPIDFILE
	echo "#${DIRCOMMAND}/${COMMAND}.sh $*"
	echo "#"
	${DIRCOMMAND}/${COMMAND}.sh $*
	ret=$?
	pid=$!
	echo $ret > $TERMFILE
	[ -f $PPIDFILE ] && rm $PPIDFILE 2> /dev/null 2>&1
	[ -f $PENDINGFILE ] && rm $PENDINGFILE 2> /dev/null 2>&1
	exit $ret
fi

echo	"#command ${COMMAND}.sh not found"

exit 1
