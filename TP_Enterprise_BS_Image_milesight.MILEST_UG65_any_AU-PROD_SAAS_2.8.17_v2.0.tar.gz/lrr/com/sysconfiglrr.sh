#!/bin/sh

##
## @file
## @author Actility
## @copyright Actility SA
## @brief installation and configuration of LRR package
##
## @details
## This script executes
## - the setup of the firmware (system configuration, installation of additional packages/tools)
## - the definition of boot services
## - the setup of support account and suplog access
##
## @ingroup porting
##

[ "$DEBUG" = 1 ] && set -x

# ask a question
# $1: variable name for the result
# $2: question to ask
# $3 $4 ...: choices
ask()
{
	resvarname="$1"
	question="$2"
	shift 2
	choice="$*"

	resp=0
	while [ $resp = 0 ]
	do
		# ask question
		echo "$question"

		# display choices
		count=1
		set $choice
		tot=$#
		while [ $count -le $tot ]
		do
			echo "$count	$1"

			shift
			count=$(($count + 1))
		done

		# get response
		echo -n "> "
		read resp

		# check response
		[ $resp -gt 0 -a $resp -lt $count ] && break
		resp=0
	done

	# set resulting variable with the choice made
	set $choice
	eval "$resvarname=\$$resp"
}

#
# determine pre-install configuration: system characteristics 
#
setSystemCharacteristics() {

    SYSDEF=$ROOTACT/lrr/system/system_definition.sh
    SYSCHAR=$ROOTACT/lrr/system/system_characteristics.sh
    SUPDEF=$ROOTACT/lrr/system/suplog_definition.sh
    SYSAUTO=$ROOTACT/lrr/com/system_def_tools

    SYSTEMPLATE=$SYSAUTO/bs_system_setting.template

    if [ ! -f $SYSDEF ]; then
        echo "No system definition file: system still using the old configuration mechanism"
        return
    fi
    # force export of variables
    set -a && . $SYSDEF

    # workaround for Gemtek ODU: strongswan installed by Actility so ipsec.conf not yet present during detection
    # create an empty one so autodetection works
    if [ "$SYSTEM" = "gemodu" ]
    then
        mkdir -p /usr/local/etc
        touch /usr/local/etc/ipsec.conf
    fi

    if [ "$SYSTEM" = "ciscoms" ]
    then
        # log file is present only if activated through a host command.
        # If not present, create a fake one to make autodetection working
        log=/var/run/messages
        if [ ! -f $log ]; then
            echo "'container log all' not executed" > $log
        fi
    fi

    if [ ! -f $SYSCHAR ]; then
        # file is not part of the delivery package and was not yet created
        if [ -f $SYSTEMPLATE ]; then
            echo "System characteristics: setting file not present: automatic creation ..."
            # change dir to get access to scripts use for dynamic setting (into autogen dir)
            curd=`pwd`
            cd $SYSAUTO ; ./envvar_generator.sh -f $SYSTEMPLATE > $SYSCHAR
            if [ $? != 0 ]; then
                echo "Error while running automatic setting of system characteristics"
                cat $SYSCHAR
                rm $SYSCHAR
                exit 1
            fi
        else
            echo "Error: cannot find system characteristics template file"
        fi
    fi
    if [ ! -f $SYSCHAR ]; then
        echo "$SYSCHAR not present: create manually if its automatic generation doesn't work"
        exit 1
    fi
    . $SYSCHAR
    if [ $? -ne 0 ]; then
        echo "Error while sourcing $SYSCHAR: maybe contain error indication"
        exit 1
    fi

    if [ ! -f $SUPDEF ]; then
        echo "$SUPDEF not present: create manually if its automatic generation doesn't work"
        exit 1
    fi
    . $SUPDEF
    if [ $? -ne 0 ]; then
        echo "Error while sourcing $SUPDEF: maybe contain error indication"
        exit 1
    fi


    # check that all mandatory variables are there: error should happen only during development phase
    $SYSAUTO/envvar_checking.sh system
    if [  $? -ne 0 ]; then
        echo "Invalid system definition: see error messages above"
        exit 1
    fi
}

#
# determine post-install configuraton like path to LRR files and so on
#
setLrrSetting() {

    SYSLRR=$ROOTACT/lrr/system/lrr_setting.sh
    LRRTEMPLATE=$SYSAUTO/bs_lrr_setting.template

    if [ ! -f $SYSDEF ]; then
        echo "No system definition file: system still using the old configuration mechanism"
        return
    fi

    if [ ! -f $SYSLRR ]; then
        # file is not part of the delivery package and was not yet created
        if [ -f $LRRTEMPLATE ]; then
            echo "LRR characteristics: setting file not present: automatic creation ..."
            # change dir to get access to scripts use for dynamic setting (into autogen dir)
            curd=`pwd`
            cd $SYSAUTO ; ./envvar_generator.sh -f $LRRTEMPLATE > $SYSLRR
            if [ $? != 0 ]; then
                echo "Error while running automatic setting of LRR characteristics"
                cat $SYSLRR
                rm $SYSLRR
                exit 1
            fi
        else
            echo "Error: cannot find LRR characteristics template file"
        fi
    fi
    if [ ! -f $SYSLRR ]; then
        echo "$SYSLRR not present: create manually if its automatic generation doesn't work"
        exit 1
    fi
    . $SYSLRR
    if [ $? -ne 0 ]; then
        echo "Error while sourcing $SYSLRR: maybe contain error indication"
        exit 1
    fi

    # check that all mandatory variables are there: error should happen only during development phase
    $SYSAUTO/envvar_checking.sh lrr
    if [  $? -ne 0 ]; then
        echo "Invalid system definition: see error messages above"
        exit 1
    fi
}

checkSupportUser()
{
	if [ "$SYSTEM" = "linux-x86" ]; then
		return
	fi
	if [ "$SYSTEM" = "linux-x86_64" ]; then
		return
	fi

	DEFAULT_SHELL=/bin/sh
	if [ "$SYSTEM" = "flexpico" ]; then
		DEFAULT_SHELL=/bin/ash
	fi

	# create /etc/shells if required
	if [ ! -f "/etc/shells" ]
	then
		echo "$DEFAULT_SHELL" >>/etc/shells
		echo "$ROOTACT/lrr/suplog/suplog.x" >>/etc/shells
	else
		# if /etc/shells exists, check if suplog.x is present
		check="$(grep "suplog.x" /etc/shells)"
		[ -z "$check" ] && echo "$ROOTACT/lrr/suplog/suplog.x" >>/etc/shells
	fi

	STDOPT="-s"
	if [ "$SYSTEM" = "oielec" ] || [ "$SYSTEM" = "sempico" ] ; then
		STDOPT="--shell"
	fi
	PWD_FILE=/etc/passwd
	# create user support if required
	check="$(grep "^support:" $PWD_FILE)"
	if [ -z "$check" ]
	then
		if [ "$SYSTEM" = "flexpico" ]; then
			# no adduser command on flexpico. Add support user manually
			echo "support:*:1000:1000:Support User:$ROOTACT:$ROOTACT/lrr/suplog/suplog.x" >> /etc/passwd
			passwd support <<END_ADD
support
support
END_ADD
		elif command -v adduser; then
			adduser $STDOPT $ROOTACT/lrr/suplog/suplog.x support <<END_ADD
support
support
END_ADD
		else
			useradd $STDOPT $ROOTACT/lrr/suplog/suplog.x support <<END_ADD
			passwd support <<END_ADD
support
support
END_ADD
		fi
	else
		#check that the user support has a different ID from root
		check="$(grep "^support:x:0" $PWD_FILE)"
		if [ ! -z "$check" ]
		then
			SUPPORTID=1000
			check="$(grep $SUPPORTID $PWD_FILE)"
			while [ ! -z "$check" ]
			do
				let SUPPORTID=SUPPORTID+1
				check="$(grep $SUPPORTID $PWD_FILE)"
			done
			SUPPORTGROUP="$(id -g support)"
			sed -i "s/support:x:0:${SUPPORTGROUP}/support:x:${SUPPORTID}:${SUPPORTID}/g" $PWD_FILE
		fi

		# check the existing user support has suplog.x as shell
		check=$(grep "^support:" $PWD_FILE | grep suplog.x)
		if [ -z "$check" ]
		then
			sed -i "/^support/s#/${DEFAULT_SHELL}#${ROOTACT}/lrr/suplog/suplog.x#g" $PWD_FILE
		fi
	fi

	# check setuid bit on /bin/su
}

checkSupportUserKeros()
{

    # add "support" account if not yet present.
    # if present, check if correctly configured
    # - if not, likely never configured: configure it and initialize the password

    exist_group=$(grep "^support:" $SYSTEM_ETC/group)
    if [ -z "${exist_group}" ]; then
        groupadd support
    fi
    exist_passwd=$(grep "^support:" $SYSTEM_ETC/passwd)
    exist_shadow=$(grep "^support:" $SYSTEM_ETC/shadow)

    if [ -z "${exist_passwd}" -o -z "${exist_shadow}" ]; then
        cmd=useradd
    else
        cmd=usermod
    fi

    set_password=0
    if [ -z "${exist_shadow}" ]; then
        set_password=1
    else
        # do not change password if support was already referencing suplog.x (upgrade)
        suplog_set=$(grep "support:.*suplog.x" $SYSTEM_ETC/passwd)
        if [ -z "$suplog_set" ]; then
            # full installation
            set_password=1
        fi
    fi
    if [ $set_password = 1 ]; then
        $cmd -g support -s $ROOTACT/lrr/suplog/suplog.x -p $(openssl passwd support) support
    else
        $cmd -g support -s $ROOTACT/lrr/suplog/suplog.x  support
    fi


    # for upward compatibility
    rm -f /user/login
    [ -f "$ROOTACT/lrr/suplog/suplog.x" ] && ln -s $ROOTACT/lrr/suplog/suplog.x /user/login

    cfgssh="$SYSTEM_ETC/ssh/sshd_config"
    res=$(grep "AllowUsers.*support" $cfgssh)
    if [ -z "$res" ]; then
        echo "AllowUsers support" >> $cfgssh
        # make it active immediately
        /etc/init.d/sshd restart
    fi
}

fixKerosNetwork() {

    # PT-1087: update nsswitch.conf to reduce hostname resolution time
    nsswitch=$SYSTEM_ETC/nsswitch.conf
    todo=$(grep "hosts:.*mdns4_minimal" $nsswitch)
    if [ ! -z "$todo" ]; then
        echo "Fix /etc/nsswitch.conf issue"
        sed -i -e '/hosts:/ s/mdns4_minimal/dns/' $nsswitch
    fi
}

checkSupportUserCiscoms()
{
	# As permissions are more restrictive by default than others gateways,
    # removed: need to find a way to not changed permission of key.priv
	# chmod -R g=rwX,o=rX $ROOTACT
	chmod 777 /tmp
	# Create group users GID 100 if needed
	check="$(grep "^users:" /etc/group)"
	if [ -z "$check" ];  then
		addgroup users -g 100
	else
		echo "group users already exists"
	fi
	# Create user support UID 1001 if needed
	check="$(grep "^support:" /etc/passwd)"
	if [ -z "$check" ];  then
		adduser support -u 1001 -G users -g "Support LRR" -s $ROOTACT/lrr/suplog/suplog.x << END_ADD
support
support
END_ADD
	else
		echo "user support already exists"
	fi
	# Add umask in profile if needed
	line=$(grep "umask 002" $INIT_PROF)
	if [ -z "$line" ]; then
		echo "umask 002" >> $INIT_PROF
	else
		echo "umask already present in $INIT_PROF"
	fi

	# Because permissions where not already available
	chown root:root $ROOTACT/lrr/suplog/suplog.x
	chmod u+s $ROOTACT/lrr/suplog/suplog.x
}

checkSupportUserGemtek()
{
        # create /etc/shells if required
        if [ ! -f "/etc/shells" ]
        then
                echo "/bin/sh" >>/etc/shells
                echo "$ROOTACT/lrr/suplog/suplog.x" >>/etc/shells
        else
                # if /etc/shells exists, check if suplog.x is present
                check="$(grep "suplog.x" /etc/shells)"
                [ -z "$check" ] && echo "$ROOTACT/lrr/suplog/suplog.x" >>/etc/shells
        fi

        STDOPT="-shell"
        PWD_FILE=/etc/passwd
        # create user support if required
        check="$(grep "^support:" $PWD_FILE)"
        if [ -z "$check" ]
        then
                adduser $STDOPT $ROOTACT/lrr/suplog/suplog.x support <<END_ADD
support
support




y
END_ADD
        else
                #check that the user support has a different ID from root
                check="$(grep "^support:x:0" $PWD_FILE)"
                if [ ! -z "$check" ]
                then
                        SUPPORTID=1000
                        check="$(grep $SUPPORTID $PWD_FILE)"
                        while [ ! -z "$check" ]
                        do
                                let SUPPORTID=SUPPORTID+1
                                check="$(grep $SUPPORTID $PWD_FILE)"
                        done
                        SUPPORTGROUP="$(id -g support)"
                        sed -i "s/support:x:0:${SUPPORTGROUP}/support:x:${SUPPORTID}:${SUPPORTID}/g" $PWD_FILE
                fi

                # check the existing user support has suplog.x as shell
                check=$(grep "^support:" $PWD_FILE | grep suplog.x)
                if [ -z "$check" ]
                then
                        sed -i "/^support/s#/bin/sh#${ROOTACT}/lrr/suplog/suplog.x#g" $PWD_FILE
                fi
        fi

        # check setuid bit on /bin/su
}

checkSupportUserGemPicoNext()
{
        # create /etc/shells if required
        if [ ! -f "/etc/shells" ]
        then
                echo "/bin/sh" >>/etc/shells
                echo "$ROOTACT/lrr/suplog/suplog.x" >>/etc/shells
        else
                # if /etc/shells exists, check if suplog.x is present
                check="$(grep "suplog.x" /etc/shells)"
                [ -z "$check" ] && echo "$ROOTACT/lrr/suplog/suplog.x" >>/etc/shells
        fi

        PWD_FILE=/etc/passwd
        # create user support if required
        check="$(grep "^support:" $PWD_FILE)"
        if [ -z "$check" ]
        then
                adduser support -s $ROOTACT/lrr/suplog/suplog.x support <<END_ADD
support
support
END_ADD
        else
		echo "user support already exists"
	fi
	# Add umask in profile if needed
	line=$(grep "umask 002" $INIT_PROF)
	if [ -z "$line" ]; then
		echo "umask 002" >> $INIT_PROF
	else
		echo "umask already present in $INIT_PROF"
	fi

	# Because permissions where not already available
	chown root:root $ROOTACT/lrr/suplog/suplog.x
	chmod u+s $ROOTACT/lrr/suplog/suplog.x
}


checkSupportUserTracknet()
{
   # create /etc/shells if required
   if [ ! -f "/etc/shells" ]
   then
       echo "/bin/sh" >>/etc/shells
       echo "$ROOTACT/lrr/suplog/suplog.x" >>/etc/shells
   else
       # if /etc/shells exists, check if suplog.x is present
       check="$(grep "suplog.x" /etc/shells)"
       [ -z "$check" ] && echo "$ROOTACT/lrr/suplog/suplog.x" >>/etc/shells
   fi
   
   # Create group users GID 100 if needed
   check="$(grep "^users:" /etc/group)"
   if [ -z "$check" ];  then
       addgroup users -g 100
   else
       echo "group users already exists"
   fi
   # Create user support UID 1001 if needed
   check="$(grep "^support:" /etc/passwd)"
   if [ -z "$check" ];  then
       mkdir -p /home/support
       adduser support -u 1001 -G users -g "Support LRR" -s $ROOTACT/lrr/suplog/suplog.x << END_ADD
support
support
END_ADD
   else
       echo "user support already exists"
   fi
   
   # Allow support user to be super user
   chown root:root $ROOTACT/lrr/suplog/suplog.x
   chmod u+s $ROOTACT/lrr/suplog/suplog.x
}

disableCfgmgr()
{
	echo "Disable cfgmgr Ethernet link checking"
	# on ufiSpace, cfgmgr performs an Ethernet link control detecting
	# connection loss. Unfortunately, it causes unstability as it 
	# "pings" server other than LRC so detects link loss inappropriately
	# check conf file presence (depends on the firmware and the gateway model)
	cfgmgr=/etc/cfgmgr.conf
	savcfg=/etc/cfgmgr.orig
	if [ -f $cfgmgr ]; then
		# already saved ? Do not supersede the original one from manufacturer
		if [ ! -f $savcfg ]; then
			cp $cfgmgr $savcfg
		fi
		echo "enable=0" > $cfgmgr
		echo "checkwanfreq=0" >> $cfgmgr
	fi
}

#
# addIptables
#

addIptables()
{

    type iptables > /dev/null 2>&1
    if [ $? != "0" ]
    then
        echo "iptables are not available"
        return 1
    fi

    if [ "$FIRMWARE" = "keros" -a "$SYSTEM" != "wirmav2" ]; then
        _bootscript=$SYSTEM_ETC/rcU.d/S89lrrfirewall
    else
        _bootscript=$SYSTEM_ETC/init.d/firewall
    fi

    SystemGetFilePath "$ROOTACT/lrr/com/shells" "firewall"
    if [ "$sysfilepath" = "" ]; then
        echo "ERROR: firewall file not found"
        exit 1
    fi

    _bootoriginal=${_bootscript}.original
	if [ ! -f ${_bootoriginal} -a -f ${_bootscript} ]
	then
		cp ${_bootscript} ${_bootoriginal}
        # remove original otherwise also executed if in a boot directory
        rm ${_bootoriginal}
	fi

	cat ${sysfilepath} | sed "s?_REPLACEWITHROOTACT_?$ROOTACT?" > ${_bootscript}
	chmod +x ${_bootscript}

	if [ "$SYSTEM" = "wirmav2" ]; then
		kerlink_firewall=/etc/rc.d/rc3.d/S80firewall
	else
		kerlink_firewall=/etc/rc5.d/S01firewall
	fi
	if [ -f "${kerlink_firewall}" ]; then
		echo "Stopping Kerlink firewall"
		${kerlink_firewall} stop
		rm -f ${kerlink_firewall}
		ln -s ${_bootscript} ${kerlink_firewall}
	fi

	echo "SERVICEFIREWALL=$_bootscript" >> $ROOTACT/usr/etc/lrr/_parameters.sh

	if [ "$FIRMWARE" = "keros" ]; then
		# start firewall as, during installation, it is in the same boot directory than postinstall
		# so was not present while boot mechanism looks for all scripts to run
		echo "Starting LRR firewall"
		${_bootscript} start
	fi

	if [ "$FIRMWARE" = "tekos" ]; then
		update-rc.d firewall defaults
	fi

	if [ "$SYSTEM" = "gempiconext" ]; then
	    if [ ! -f "/etc/init.d/S99firewall" ]
	    then
		# current version of gempiconext has no SysV ... so let's trick it
		#  using the script based init placed by default
		ln -s ${_bootscript} /etc/init.d/S99firewall > /dev/null
	    fi
	fi
	
	echo "iptables are installed"

	return 0
}

addHwDetection_wirmaar()
{
	cat $ROOTACT/lrr/com/cmd_shells/wirmaar/checkhw.sh | sed "s?_REPLACEWITHROOTACT_?$ROOTACT?" > $SYSTEM_ETC/rcU.d/S87checkhw
	chmod +x $SYSTEM_ETC/rcU.d/S87checkhw
	# execute it once
	$SYSTEM_ETC/rcU.d/S87checkhw
	echo "Script for Hardware detection installed and executed"
}

useBashInteadOfDash(){
	echo "dash dash/sh boolean false" | debconf-set-selections
	dpkg-reconfigure -f noninteractive dash
}

installService()
{
	shname="$1"
	srvname="$2"
	if [ ! -z "$3" ]; then
		srvprio=$3
	else
		srvprio=
	fi

	if [ -d $ROOTACT/lrr/system ]; then
        # new mechanism

		cat $shname | sed "s?_REPLACEWITHROOTACT_?$ROOTACT?" > ${SERVICEPREFIX}$srvname
		chmod +x ${SERVICEPREFIX}$srvname

		if [ "$FIRMWARE" = "mlinux" ]; then
			[ -z "$srvprio" ] && srvprio=99
			if [ ! -f "/etc/rc2.d/S${srvprio}${srvname}" ]
			then
				rm -f /etc/rc?.d/S??${srvname}
				ln -s ${SERVICEPREFIX}$srvname /etc/rc2.d/S${srvprio}${srvname}
				ln -s ${SERVICEPREFIX}$srvname /etc/rc3.d/S${srvprio}${srvname}
				ln -s ${SERVICEPREFIX}$srvname /etc/rc4.d/S${srvprio}${srvname}
				ln -s ${SERVICEPREFIX}$srvname /etc/rc5.d/S${srvprio}${srvname}
				ln -s ${SERVICEPREFIX}$srvname /etc/rc0.d/K01$srvname
				ln -s ${SERVICEPREFIX}$srvname /etc/rc6.d/K01$srvname
			fi

		fi

		if [ "$FIRMWARE" = "openwrt" ]; then
			[ -z "$srvprio" ] && srvprio=99
			ln -s ${SERVICEPREFIX}$srvname /etc/rc.d/S${srvprio}${srvname}
		fi

		if [ "$FIRMWARE" = "keros" ]; then
			[ -z "$srvprio" ] && srvprio=90
			if [ "$SYSTEM" = "wirmav2" ]; then
				if [ ! -f "/etc/rc.d/rc3.d/S${srvprio}${srvname}" ]
				then
					rm -f /etc/rc3.d/S??${srvname}
					# default runlevel is 3
					# according to kerlink wiki, lvl 2 and 4 are reserved for kerlink stuff
					ln -s ${SERVICEPREFIX}$srvname /etc/rc.d/rc3.d/S${srvprio}${srvname}
					ln -s ${SERVICEPREFIX}$srvname /etc/rc.d/rc0.d/K01$srvname
					ln -s ${SERVICEPREFIX}$srvname /etc/rc.d/rc6.d/K01$srvname
				fi
			fi
		fi

		if [ "$SYSTEM" = "gemodu" ]; then
			update-rc.d $srvname defaults
		fi

		if [ "$SYSTEM" = "gempiconext" ]; then
			if [ ! -f "/etc/init.d/S99$srvname" ]
			then
			        # current version of gempiconext has no SysV ... so let's trick it
			        #  using the script based init placed by default
				ln -s ${SERVICEPREFIX}$srvname /etc/init.d/S99$srvname > /dev/null
			fi
		fi

		if [ "$FIRMWARE" = "tekos" ]; then
			[ -z "$srvprio" ] && srvprio=99
			if [ ! -f "/etc/rc2.d/S${srvprio}${srvname}" ]
			then
				rm -f /etc/rc?.d/S??${srvname}
				# remove '2&>1', the command do nothing with that !
				# ln -s /etc/init.d/$srvname /etc/rc2.d/S${srvprio}${srvname} > /dev/null 2&>1
				ln -s ${SERVICEPREFIX}$srvname /etc/rc2.d/S${srvprio}${srvname} > /dev/null
				ln -s ${SERVICEPREFIX}$srvname /etc/rc3.d/S${srvprio}${srvname} > /dev/null
				ln -s ${SERVICEPREFIX}$srvname /etc/rc4.d/S${srvprio}${srvname} > /dev/null
				ln -s ${SERVICEPREFIX}$srvname /etc/rc5.d/S${srvprio}${srvname} > /dev/null
				ln -s ${SERVICEPREFIX}$srvname /etc/rc0.d/K01$srvname > /dev/null
				ln -s ${SERVICEPREFIX}$srvname /etc/rc6.d/K01$srvname > /dev/null
			fi
		fi
		return
	fi

	case $SYSTEM in
		rbpi_v1.0)	#RaspBerry SPI V1.0
			[ -z "$srvprio" ] && srvprio=90
			cat $shname | sed "s?_REPLACEWITHROOTACT_?$ROOTACT?" > ${SERVICEPREFIX}$srvname
			chmod +x ${SERVICEPREFIX}$srvname
			if [ ! -f "/etc/rc2.d/S${srvprio}${srvname}" ]
			then
				rm -f /etc/rc?.d/S??${srvname}
				ln -s ${SERVICEPREFIX}$srvname /etc/rc2.d/S${srvprio}${srvname}
				ln -s ${SERVICEPREFIX}$srvname /etc/rc3.d/S${srvprio}${srvname}
				ln -s ${SERVICEPREFIX}$srvname /etc/rc4.d/S${srvprio}${srvname}
				ln -s ${SERVICEPREFIX}$srvname /etc/rc5.d/S${srvprio}${srvname}
				ln -s ${SERVICEPREFIX}$srvname /etc/rc0.d/K01$srvname
				ln -s ${SERVICEPREFIX}$srvname /etc/rc6.d/K01$srvname
			fi
		;;
		natrbpi_usb_v1.0)	#RaspBerry USB V1.0
			[ -z "$srvprio" ] && srvprio=90
			cat $shname | sed "s?_REPLACEWITHROOTACT_?$ROOTACT?" > ${SERVICEPREFIX}$srvname
			chmod +x ${SERVICEPREFIX}$srvname
			if [ ! -f "/etc/rc2.d/S${srvprio}${srvname}" ]
			then
				rm -f /etc/rc?.d/S??${srvname}
				ln -s ${SERVICEPREFIX}$srvname /etc/rc2.d/S${srvprio}${srvname}
				ln -s ${SERVICEPREFIX}$srvname /etc/rc3.d/S${srvprio}${srvname}
				ln -s ${SERVICEPREFIX}$srvname /etc/rc4.d/S${srvprio}${srvname}
				ln -s ${SERVICEPREFIX}$srvname /etc/rc5.d/S${srvprio}${srvname}
				ln -s ${SERVICEPREFIX}$srvname /etc/rc0.d/K01$srvname
				ln -s ${SERVICEPREFIX}$srvname /etc/rc6.d/K01$srvname
			fi
		;;
		sempico)	#Semtech Picocell gateway V1.5
			cat $shname | sed "s?_REPLACEWITHROOTACT_?$ROOTACT?" > /etc/init.d/$srvname
			chmod +x /etc/init.d/$srvname
			if [ ! -f "/etc/rc2.d/S${srvprio}${srvname}" ]
			then
				rm -f /etc/rc?.d/S??${srvname}
				ln -s /etc/init.d/$srvname /etc/rc2.d/S${srvprio}${srvname}
				ln -s /etc/init.d/$srvname /etc/rc3.d/S${srvprio}${srvname}
				ln -s /etc/init.d/$srvname /etc/rc4.d/S${srvprio}${srvname}
				ln -s /etc/init.d/$srvname /etc/rc5.d/S${srvprio}${srvname}
				ln -s /etc/init.d/$srvname /etc/rc0.d/K01$srvname
				ln -s /etc/init.d/$srvname /etc/rc6.d/K01$srvname
			fi
		;;

		fcmlb|fcpico|fcloc|fclamp)	#Foxconn gateways
			[ -z "$srvprio" ] && srvprio=99
			cat $shname | sed "s?_REPLACEWITHROOTACT_?$ROOTACT?" > ${SERVICEPREFIX}$srvname
			chmod +x ${SERVICEPREFIX}$srvname
			if [ ! -f "/etc/rc2.d/S${srvprio}${srvname}" ]; then
				rm -f /etc/rc?.d/S??${srvname}
				ln -s ${SERVICEPREFIX}$srvname /etc/rc2.d/S${srvprio}${srvname}
				ln -s ${SERVICEPREFIX}$srvname /etc/rc3.d/S${srvprio}${srvname}
				ln -s ${SERVICEPREFIX}$srvname /etc/rc4.d/S${srvprio}${srvname}
				ln -s ${SERVICEPREFIX}$srvname /etc/rc5.d/S${srvprio}${srvname}
				ln -s ${SERVICEPREFIX}$srvname /etc/rc0.d/K01$srvname
				ln -s ${SERVICEPREFIX}$srvname /etc/rc6.d/K01$srvname
			fi
		;;

		oielec)	#OIelec
			cat $shname | sed "s?_REPLACEWITHROOTACT_?$ROOTACT?" > ${SERVICEPREFIX}$srvname
			chmod +x ${SERVICEPREFIX}$srvname
			update-rc.d $srvname defaults
		;;
		flexpico) # Flex Pico
			[ -z "$srvprio" ] && srvprio=99
			cat $shname | sed "s?_REPLACEWITHROOTACT_?$ROOTACT?" > ${SERVICEPREFIX}$srvname
			chmod +x ${SERVICEPREFIX}$srvname
			# Then add the lrr service instead
			if [ ! -f "/etc/rc.d/S${srvprio}${srvname}" ]; then
				rm -f /etc/rc.d/S??${srvname}
				ln -s ${SERVICEPREFIX}$srvname /etc/rc.d/S${srvprio}${srvname}
			fi
		;;
	esac

}

# Service checkvpn2 before 2.4.47 used a script checkvpn.sh
# it is a problem when the old checkvpn.sh not provided with the lrr
# is used: stopping the service checkvpn2 killed old checkvpn.sh
treatCheckvpn()
{
	# If running, need to restart checkvpn not provided with the lrr because it use lrr scripts
	pidold=$(ps | grep checkvpn.sh | grep -v "ipsecmgr/checkvpn.sh" | grep -v grep | awk '{ print $1 }')
	if [ -f "${SERVICEPREFIX}checkvpn.sh" ]
	then
		res=$(grep lrr_DownloadFromRemote "${SERVICEPREFIX}checkvpn.sh" 2>/dev/null)
		if [ ! -z "$res" ]
		then
			# checkvpn.sh version that uses scripts from the lrr
			if [ -f "${SERVICEPREFIX}checkvpn" ]
			then
				echo "New version of external checkvpn detected, restart it"
				# prefere kill to service restart because of the possible bug where
				# pids file are the same for checkvpn and checkvpn2 and restart fails
				kill $pidold >/dev/null 2>&1
			else
				echo "Error: new version of external checkvpn detected, but no service to restart it"
			fi
		fi
	fi


	# If running, need to stop old checkvpn2 that run a script named checkvpn.sh to replace it
	# with the last version that run checkvpn2.sh
	pidnew=$(ps | grep "ipsecmgr/checkvpn.sh" | grep -v grep | awk '{ print $1 }')
	if [ ! -z "$pidnew" ]
	then
		echo "Old version of checkvpn2 detected, stop it"
		pidserv=$(ps | grep "checkvpn2" | grep "_respawnService" | grep -v grep | awk '{ print $1 }')
		# kill service checkvpn2 first to avoid automatic restart
		kill $pidserv >/dev/null 2>&1
		kill $pidnew >/dev/null 2>&1
	fi
}

# Problems with old failover scripts (before nfr920) and first version of nfr920 failover scripts (FVONF)
# With the FVONF, the service kills all scripts named ifacefailover.sh and ifacerescue.sh when
# stopping/restarting the service, even old failover scripts.
# The last version uses script named '...2', no problem. But some cleaning is required
treatFailover()
{
	# old failover scripts, before nfr920
	pidfoold=$(ps | grep ifacefailover.sh | grep -v "/failovermgr/" | grep -v grep | awk '{ print $1 }')
	pidspvold=$(ps | grep ifacerescue.sh | grep -v "/failovermgr/" | grep -v grep | awk '{ print $1 }')
	# first version of nfr920 failover scripts
	pidfo=$(ps | grep ifacefailover.sh | grep "/failovermgr/" | grep -v grep | awk '{ print $1 }')
	pidspv=$(ps | grep ifacerescue.sh | grep "/failovermgr/" | grep -v grep | awk '{ print $1 }')
	pidservice=$(ps | grep "/ipfailover[^2]" | grep "_respawnService" | grep -v grep | awk '{ print $1 }')

	# If first version of failover nfr920 is running, stop service and scripts
	if [ ! -z "$pidservice" ]
	then
		echo "Stop previous version of ipfailover service"
		# kill service to avoid autorestart
		kill $pidservice
	fi
	if [ ! -z "$pidfo" -o ! -z "$pidspv" ]
	then
		echo "Stop scripts of previous version of ipfailover"
		kill $pidfo $pidspv
	fi
	if [ -f "${SERVICEPREFIX}ipfailover" ]
	then
		echo "Update ipfailover to ipfailover2"
		# remove service, the new one will be created later
		rm -f ${SERVICEPREFIX}ipfailover
	fi

	# if old version of failover (before nfr920) is active but the script is not running,
	# it's probably because the first version of failover nfr920 killed it
	oldactive=$(getIniConf "$ROOTACT/usr/etc/lrr/lrr.ini" "ifacefailover" "enable")
	if [ "$oldactive" = "1" -a -z "$pidfoold" ]
	then
		echo "OLD IPFAILOVER ACTIVATED BUT NOT RUNNING, YOU NEED TO RESTART THE LRR !"
	fi
}

# create services from files found in $ROOTACT/lrr/services
createServices()
{
	# get directory of the service, set $SERVICEPREFIX
	getServicePrefix

	# treat problems with first version of nfr920 checkvpn
	treatCheckvpn

	# treat problems with first version of nfr920 failover
	treatFailover

	srvdir="$ROOTACT/lrr/services"

	[ ! -d "$srvdir" ] && return

	# scan all files
	for f in $(ls $srvdir)
	do
		unset SERVICENAME SERVICESOURCE SERVICEPRIORITY ONSYSTEM

		# ignore readme
		[ ! -f "$srvdir/$f" -o "$f" = "readme" ] && continue

		# set SERVICENAME and SERVICESOURCE
		. $srvdir/$f

        # all redesigned gateways should support new services
        # check ONSYSTEM if it is not the new mechanism
		if [ ! -d $ROOTACT/lrr/system ]; then
		    # if ONSYSTEM set, activated only if system is specified
		    [ ! -z "$ONSYSTEM" -a -z "$(echo $ONSYSTEM | grep $SYSTEM)" ] && continue
        fi

		# check SERVICENAME and SERVICESOURCE
		if [ -z "$SERVICENAME" -o -z "$SERVICESOURCE" ]
		then
			echo "SERVICENAME or SERVICESOURCE not set, file '$f' ignored"
			return
		fi

		# check if SERVICESOURCE file exist
		if [ ! -f "$SERVICESOURCE" ]
		then
			echo "Can't find '$SERVICESOURCE', creation of service '$SERVICENAME' aborted"
			continue
		fi

		# create service
		echo "create service $SERVICENAME"
		if [ -z "$SERVICEPRIORITY" ]; then
			installService "$SERVICESOURCE" "$SERVICENAME"
		else
			installService "$SERVICESOURCE" "$SERVICENAME" "$SERVICEPRIORITY"
		fi
	done
}

restartService()
{
	srvdir="$1"
	srvname="$2"

	[ -z "$srvdir" -o ! -e "$srvdir/$srvname" ] && continue

	unset SERVICENAME SERVICESOURCE ONSYSTEM

	# ignore readme
	[ ! -f "$srvdir/$srvname" -o "$srvname" = "readme" ] && continue

	# don't restart lrr this way
	[ ! -f "$srvdir/$srvname" -o "$srvname" = "lrr" ] && continue

	# set SERVICENAME and SERVICESOURCE
	. $srvdir/$srvname

	# if ONSYSTEM set, activated only if system is specified
	[ ! -z "$ONSYSTEM" -a -z "$(echo $ONSYSTEM | grep $SYSTEM)" ] && continue

	# check SERVICENAME and SERVICESOURCE
	if [ -z "$SERVICENAME" -o -z "$SERVICESOURCE" ]
	then
		echo "SERVICENAME or SERVICESOURCE not set, file '$srvname' ignored"
		return
	fi

	# identify service path
	case $SYSTEM in
		wir*)	#Kerlink
			if [ "$SYSTEM" = "wirmav2" ]; then
				srv="$SYSTEM_ETC/rc.d/rc3.d/S90$SERVICENAME"
			else
				srv="$SYSTEM_ETC/rcU.d/S90$SERVICENAME"
			fi
		;;
		ciscoms)
			srv="/etc/init.d/S90$SERVICENAME"
		;;

		*)	# default
			srv="/etc/init.d/$SERVICENAME"
		;;
	esac

	# check if service file exists
	if [ ! -f "$srv" ]
	then
		echo "Can't find '$srv', can't restart service"
		continue
	fi

	echo "restart service $SERVICENAME"
	$srv restart
}

restartServices()
{
	srvdir="$ROOTACT/lrr/services"

	[ ! -d "$srvdir" ] && return

	# scan all files
	for f in $(ls $srvdir)
	do
		restartService "$srvdir" "$f"
	done
}

# -------------------------------------------
# execute additional scripts
#

#
# generic function executing script from a directory
#
# 1: directory to analyse
#

executeScript() {

    scriptdir=$1

    [ ! -d "$scriptdir" ] && return
	# scan all files
	for f in $(ls $scriptdir/*.sh)
	do
		file="$criptdir/$f"

		# ignore readme
		[ ! -f "$file" ] && continue

		# execute postinstall script
		echo "execute script $file"
		$file
	done
}

#
# execute script related to firmare, os, model and so on
# before performing LRR configuration
#

doSystemUpdate ()
{
    echo "Execute system preparation scripts if any"
    executeScript "$ROOTACT/system/preinstall"
}

#
# execute LRR postinstall script
#

doPostinstall()
{
    echo "Execute post-installation scripts if any"
	executeScript "$ROOTACT/lrr/postinstall"
}

# --------------------------------------------

use()
{
	echo "$0 [-m usb|spi] [-x x1|x8]"
	echo "Incorrect command, default values used !"
}

usage() {

    echo "$0: [--norestart]"
    echo "  with"
    echo "  --norestart     do not restart services after installation"
    echo "                  (usefull when called in a postinstall boot service)"
}

# ==============================================================================
#
# Main
#
# ==============================================================================

RESTART_SERVICES=1
if [ ! -z "$1" ]; then
    if [ "$1" = "--norestart" ]; then
        RESTART_SERVICES=0
    else
        usage
        exit 1
    fi
fi


# ROOTACT should be determined by the actual installation directory
if [ -z "$ROOTACT" ]; then
    d=`dirname $0`
    # move to rootact and display current dir to remove relative elements
    export ROOTACT=`cd $d/../.. ; pwd`
    echo "Detected ROOTACT: $ROOTACT"
fi

# update system if needed
doSystemUpdate

# test if system characteristics are defined, otherwise create them
setSystemCharacteristics
# all is not defined (LRR setting done when LRR is configured
. $ROOTACT/lrr/com/system_setting.sh

# include system API
. $ROOTACT/lrr/com/system_api.sh

# get parameters
while [ $# -gt 0 ] 
do 
	case $1 in
                -m)
                        SERIALMODE="$2"
			if [ "$SERIALMODE" != "usb" -a "$SERIALMODE" != "spi" ]
			then
				use
				SERIALMODE="spi"
			fi
                        shift
                ;;
                -x)
                        BOARDTYPE="$2"
			if [ "$BOARDTYPE" != "x1" -a "$BOARDTYPE" != "x8" ]
			then
				use
				BOARDTYPE="x1"
			fi
                        shift
                ;;
        esac
        shift
done

if	[ ! -d "$ROOTACT" ]
then
	echo	"$ROOTACT does not exist"
	exit	0
fi

if [ -f $ROOTACT/lrr/suplog/suplog.x ]
then
chown root:root $ROOTACT/lrr/suplog/suplog.x
chmod u+s $ROOTACT/lrr/suplog/suplog.x
fi

mkdir -p $ROOTACT/usr/etc/lrr > /dev/null 2>&1

echo	"$ROOTACT used as root directory"

if [ -f ${ROOTACT}/lrr/com/_parameters.sh ]
then
	. ${ROOTACT}/lrr/com/_parameters.sh
fi
if [ -f ${ROOTACT}/lrr/com/_functions.sh ]
then
	. ${ROOTACT}/lrr/com/_functions.sh
fi

if	[ -z "$SYSTEM" ]
then
	if	[ ! -z "$(uname -a | grep -i raspberrypi)" ]
	then
		#If this is a SPI model then there will be  /dev/spidev0.0 and /dev/spidev0.1 devices
		if	[ ! -z "$(ls /dev/spidev*)" ]; then
			echo	"System : rbpi_v1.0"
			SYSTEM=rbpi_v1.0
		# If this is a PI 0 card then there will be /dev/ttyACM0 device
		elif	[ ! -z "$(ls /dev/ttyACM*)" ]; then
			echo	"System : sempico"
			SYSTEM=sempico
		else
			echo	"System : natrbpi_usb_v1.0"
			SYSTEM=natrbpi_usb_v1.0
		fi
	fi
	if	[ ! -z "$(uname -a | grep -i am335x)" ]
	then
#		As we can not distinguish fcmlb, fcloc, fcpico and fclamp with uname methode,
#		we can use hw_version value from nvram, with defaults should be
#			For Macro GW 1.0/1.5	: BST100_Rev1.4
#			For Macro GW 2.1	: BST200_Rev1.0
#			For Pico GW 1.5		: PCG020C-V2
#			For Orange Lamp		: LGW010E-V0 or F04I0xx
#			Rem: Orange Lamp is seen as a Pico GW for now
		if [ ! -z "$(nvram get hw_version | grep -i BST200)" ]; then
			echo    "System : fcloc"
			SYSTEM=fcloc
		elif [ ! -z "$(nvram get hw_version | grep -e PCG020)" ]; then
			echo	"System : fcpico"
			SYSTEM=fcpico
		elif [ ! -z "$(nvram get hw_version | grep -e LGW010 -e F04I0)" ]; then
			echo    "System : fclamp"
			SYSTEM=fclamp
		else
			echo    "System : fcmlb"
			SYSTEM=fcmlb
		fi
	fi
	if	[ ! -z "$(uname -a | grep -i 'Linux oinet937')" ]
	then
		echo	"System : oielec"
		SYSTEM=oielec
	fi
	# Flex Pico
	if [ ! -z "$(uname -a | grep -i 'OpenWrt')" ]; then
		SYSTEM=flexpico
	fi
    # all Tracknet
    if [ ! -z "$(uname -a | grep 'InDoor')" ]; then
        echo "System : tracknet"
        SYSTEM=tracknet
    fi
    if [ ! -z "$(uname -a | grep -i 'TabsHub')" ]; then
        echo "System : tracknet"
        SYSTEM=tracknet
    fi
    if [ ! -z "$(uname -a | grep -i 'MinolGW')" ]; then
        echo "System : tracknet"
        SYSTEM=tracknet
    fi
fi

if	[ -z "$SYSTEM" ]
then
	echo	"cannot find host system"
	exit	0
fi

echo	"# Generated lrr configuration file ($(date))" > $ROOTACT/usr/etc/lrr/_parameters.sh
echo	"SYSTEM=${SYSTEM}" >> $ROOTACT/usr/etc/lrr/_parameters.sh
echo	"SYSTEM_ETC=${SYSTEM_ETC}" >> $ROOTACT/usr/etc/lrr/_parameters.sh

echo	"System : $SYSTEM"
export SYSTEM

date > $ROOTACT/usr/etc/lrr/sysconfig_done

#
# add following lines in /etc/profile if not present
#
UPDATE_PROFILE=1
if [ "$FIRMWARE" = "keros" ]; then
    UPDATE_PROFILE=0
    if [ "$SYSTEM_ETC" = "/etc" ]; then
        UPDATE_PROFILE=1
    fi
elif [ "$SYSTEM" = "linux-x86" -o "$SYSTEM" = "linux-x86_64" ]; then
    UPDATE_PROFILE=0
fi

if [ $UPDATE_PROFILE = 1 ]
then
    if [ -z "$INIT_PROF" ]; then
        INIT_PROF=$SYSTEM_ETC/profile
    fi
	PROF_LINE="export ROOTACT=${ROOTACT}"
	SCFG_LINE="export SYSTEM_ETC=${SYSTEM_ETC}"
    ADD_PATH=""
    if [ "$SYSTEM" = "ciscoms" ]; then
        rm $INIT_PROF
        # to add command wrappers
        ADD_PATH="\$ROOTACT/lrr/com/cmd_shells/$SYSTEM:"
    fi
	PATH_LINE="export PATH=$ADD_PATH\$PATH:\$ROOTACT/lrr/com:\$ROOTACT/system/bin"
	ALIA_LINE="alias cdr='cd \$ROOTACT'"
	line=$(grep "$PROF_LINE" $INIT_PROF)
	if	[ -z "$line" ]
	then
		echo	"ROOTACT not present in $INIT_PROF : add it"
		echo	>> $INIT_PROF
		echo	$PROF_LINE >> $INIT_PROF
		echo	$SCFG_LINE >> $INIT_PROF
		echo	$PATH_LINE >> $INIT_PROF
		echo	$ALIA_LINE >> $INIT_PROF
		echo "alias l='ls --color=auto'" >> $INIT_PROF
		echo "alias ll='ls -l --color=auto'" >> $INIT_PROF
	else
		echo	"ROOTACT already present in $INIT_PROF"
	fi
	if [ -z "$(grep system_setting $INIT_PROF)" ]; then
		echo    "if [ -f "\$ROOTACT/lrr/com/system_setting.sh" ]; then . \$ROOTACT/lrr/com/system_setting.sh ; fi" >> $INIT_PROF
	fi


else
	echo	"Do not change /etc/profile on target $SYSTEM"
fi


# customize shell to ease daily work of support team
# - autocompletion with only directories on "cd"
mkdir -p /etc/profile.d
cat > /etc/profile.d/customize_shell.sh  <<EOF
complete -d cd 2> /dev/null
EOF
chmod a+x /etc/profile.d/customize_shell.sh

# force INIT_FILE because it will be removed from configuration file
# and it has always been /etc/profile
INIT_FILE=/etc/inittab
if	[ -f $INIT_FILE ]
then
#
# remove following line from /etc/inittab if present
#
#"lr:X:respawn:$ROOTACT/lrr/com/initlrr.sh -s inittab"

	line=$(grep "initlrr.sh" $INIT_FILE)
	if	[ ! -z "$line" ]
	then
		echo	"remove initlrr.sh line from $INIT_FILE"
		cp $INIT_FILE /tmp
		sed '/initlrr.sh/d' /tmp/$(basename $INIT_FILE) > $INIT_FILE
	fi
fi

# --------------------------------------------------------------------------------
# new mechanism grouping gateways model instead of using an exhaustive list
# --------------------------------------------------------------------------------

# system setting and system api support old and new mechanism

setting=$ROOTACT/lrr/com/system_setting.sh
. $setting

sysconfdir=$ROOTACT/lrr/system
if [ -d $sysconfdir ]; then

	echo "New installation mechanism detected"

	# common to all gateways

	echo "SERIALMODE=$ARCH_COMM" >> $ROOTACT/usr/etc/lrr/_parameters.sh
	echo "BOARDTYPE=x$ARCH_RADIO_VALUE" >> $ROOTACT/usr/etc/lrr/_parameters.sh
	LRROUI=$($ROOTACT/lrr/com/shells/getid.sh -o)
	LRRGID=$($ROOTACT/lrr/com/shells/getid.sh -u)
	echo "LRROUI=$LRROUI" >> $ROOTACT/usr/etc/lrr/_parameters.sh
	echo "LRRGID=$LRRGID" >> $ROOTACT/usr/etc/lrr/_parameters.sh

	createServices
	addIptables

	# default path to LRR service
	servicelrr=/etc/init.d/lrr

	# multitech
	if [ "$FIRMWARE" = "mlinux" ]; then
		#nothing particular
		echo "Mlinux system setting"
	fi

	# kerlink
	if [ "$FIRMWARE" = "keros" ]; then
        	echo "Keros system setting"

        	mkdir -p $SYSTEM_ETC/profile.d
	        cp /user/actility/lrr/envlrr $SYSTEM_ETC/profile.d/envlrr

        # old firmware 
        if [ "$SYSTEM" = "wirmav2" ]; then
            servicelrr="/etc/rc.d/rc3.d/S90lrr"
		    checkSupportUser
        else
            # new firmware
            servicelrr="/etc/rcU.d/S90lrr"
		    checkSupportUserKeros
            fixKerosNetwork

			if [ "$SYSTEM" = "wirmaar" ]; then
				addHwDetection_wirmaar
			fi
		fi
	fi

	if [ "$FIRMWARE" = "tekos" ]; then
                checkSupportUser
	fi

	if [ "$FIRMWARE" = "openwrt" ]; then
            	checkSupportUser
	fi


	if [ "$SYSTEM" = "gemodu" ]; then
		checkSupportUserGemtek
		update-rc.d firewall defaults
		/etc/init.d/firewall start
		useBashInteadOfDash
	fi

	if [ "$SYSTEM" = "gempiconext" ]; then
	    checkSupportUserGemPicoNext
	fi

	# cisco
	if [ "$SYSTEM" = "ciscoms" ]; then
		echo "Cisco system setting"
		servicelrr=/etc/init.d/S90lrr
		# remove deprecated scripts in case of upgrade
		[ -f /etc/init.d/S59box_setup ] && rm /etc/init.d/S59box_setup
		# name must be changed because some exceeds 15 char limit for a process name
		rm -f /etc/init.d/S90init*
		#
		# do not add firewall service anymore on Cisco since there is platform-specific ones with NFR920
		# not needed and moreover, not getting rules to allow container to access CLI
		#cat $ROOTACT/lrr/com/cmd_shells/ciscoms/iptables.sh > /etc/init.d/S48iptables
		#chmod +x /etc/init.d/S48iptables
		[ -f /etc/init.d/S48iptables ] && rm /etc/init.d/S48iptables
		
		cat ${sysfilepath} | sed "s?_REPLACEWITHROOTACT_?$ROOTACT?" > ${_bootscript}
		cat $ROOTACT/lrr/com/cmd_shells/ciscoms/hosts_service.sh| sed "s?_REPLACEWITHROOTACT_?$ROOTACT?"  > /etc/init.d/S58hosts
		chmod +x /etc/init.d/S58hosts
		cat $ROOTACT/lrr/com/cmd_shells/ciscoms/gatewayini_service.sh | sed "s?_REPLACEWITHROOTACT_?$ROOTACT?" > /etc/init.d/S59gatewayini
		chmod +x /etc/init.d/S59gatewayini
		# run what is required before starting LRR
		if [ "$RESTART_SERVICES" = 1 ]; then
			/etc/init.d/S58hosts restart
			/etc/init.d/S59gatewayini restart
		fi
		
		# create credential file required to access host through ssh
		if [ ! -f "$ROOTACT/usr/etc/lrr/credentials.txt" ]
		then
			echo "cisco" >> $ROOTACT/usr/etc/lrr/credentials.txt
			echo "actility" >> $ROOTACT/usr/etc/lrr/credentials.txt
			echo "actility" >> $ROOTACT/usr/etc/lrr/credentials.txt
		fi
		# PT-1227: "rm -rf /tmp/log" causes issue during LRR upgrade (no more TRACE.log)
		# but log is a link during the initial install so it must be deleted in this case
		# if it is a dir, nothing will happen (not empty)
		rm -f /tmp/log
		mkdir -p /tmp/log
		mkdir -p /tmp/log/_LRRLOG
	
		checkSupportUserCiscoms
	fi

	echo "SERVICELRR=$servicelrr" >> $ROOTACT/usr/etc/lrr/_parameters.sh

	# execute LRR generic usr postinstall script
	POSTINSTFILE=$ROOTACT/lrr/com/cmd_shells/usr_postinstall.sh
	if [ -f "$POSTINSTFILE" ]; then
		# this generic will call gateway-specific script if any
		echo "Executing LRR usr_postinstall.sh"
        $POSTINSTFILE
	fi
	# then user/platform specific one
	POSTINSTFILE=$ROOTACT/usr/etc/lrr/usr_postinstall.sh
	if [ -f "$POSTINSTFILE" ]; then
		echo "Executing user-defined usr_postinstall.sh"
		$POSTINSTFILE
		# remove it (executed once)
		rm $POSTINSTFILE
	fi

	# PT-1878: delete keygen-related files only after all usr_postinstall.sh were executed
	[ -f $ROOTACT/usr/etc/lrr/keygen.sh ] && rm -f $ROOTACT/usr/etc/lrr/keygen.sh
	[ -f $ROOTACT/usr/etc/lrr/keygen ] && rm -f $ROOTACT/usr/etc/lrr/keygen
	[ -f $ROOTACT/usr/etc/lrr/seed ] && rm -f $ROOTACT/usr/etc/lrr/seed

	if [ "$SYSTEM" = "ug6x" ]; then
		[ ! -f $ROOTACT/usr/etc/lrr/lrr.ini ] && cp $ROOTACT/lrr/config/lrr_ug6x.ini $ROOTACT/usr/etc/lrr/lrr.ini
		[ ! -f $ROOTACT/usr/etc/lrr/vpn.cfg ] && cp $ROOTACT/lrr/config/vpn_ug6x.cfg $ROOTACT/usr/etc/lrr/vpn.cfg
		[ -f /usr/sbin/ssh ] && cp /usr/sbin/ssh /usr/bin/ssh -f
	fi
else

# former mechanism

case $SYSTEM in
	rbpi_v1.0)	#RaspBerry SPI V1.0
		echo "SERIALMODE=spi" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		echo "BOARDTYPE=x1" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		echo "SERVICELRR=/etc/init.d/lrr" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		createServices
	;;
	natrbpi_usb_v1.0)	#RaspBerry USB V1.0
		echo "SERIALMODE=usb" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		echo "BOARDTYPE=x1" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		echo "SERVICELRR=/etc/init.d/lrr" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		createServices
	;;
	sempico)	#RaspBerry TTY V1.0
		echo "SERIALMODE=tty" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		echo "BOARDTYPE=x1" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		echo "SERVICELRR=/etc/init.d/lrr" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		# Force device to stick to a given name /dev/pico_gw
		if [ ! -f /etc/udev/rules.d/10-stpico.rules ]; then
			# Create rules to fix device
			echo "ACTION==\"add\", ATTRS{idVendor}==\"0483\", ATTRS{idProduct}==\"5740\", SYMLINK+=\"pico_gw\"" > /etc/udev/rules.d/10-stpico.rules
			# Relaod rules
			udevadm control --reload-rules && udevadm trigger
			# Reload LoRa board driver
			rmmod cdc_acm; modprobe cdc_acm
		fi
		createServices
		checkSupportUser
		addIptables
		update-rc.d firewall defaults
	;;

	fcmlb|fcpico|fclamp)	#Foxconn 1.0/1.5 GW
		echo "SERIALMODE=spi" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		echo "BOARDTYPE=x1" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		echo "SERVICELRR=/etc/init.d/lrr" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		LRROUI=$($ROOTACT/lrr/com/shells/getid.sh -o)
		LRRGID=$($ROOTACT/lrr/com/shells/getid.sh -u)
		echo "LRROUI=$LRROUI" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		echo "LRRGID=$LRRGID" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		fcswitchpart=/usr/bin/switch_partition.sh
		if [ ! -e ${ROOTACT}/lrr/com/cmd_shells/switch_partition.sh ] && [ -f ${fcswitchpart} ]; then
			ln -s ${fcswitchpart} ${ROOTACT}/lrr/com/cmd_shells
		fi
		createServices
		disableCfgmgr
		checkSupportUser
		addIptables
		if [ "$SYSTEM" = "fcpico" ]; then
			[ $(nvram get slot_1_select) = "4" ] || nvram set slot_1_select=4
			[ $(nvram get firewall_enable) = "false" ] || nvram set firewall_enable=false
			[ $(nvram get lrr_firewall_enable) = "true" ] || nvram set lrr_firewall_enable=true
			sync
		fi
	;;

	fcloc)	#Foxconn 2.1 GW
		echo "SERIALMODE=spi" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		echo "BOARDTYPE=x8" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		echo "SERVICELRR=/etc/init.d/lrr" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		LRROUI=$($ROOTACT/lrr/com/shells/getid.sh -o)
		LRRGID=$($ROOTACT/lrr/com/shells/getid.sh -u)
		echo "LRROUI=$LRROUI" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		echo "LRRGID=$LRRGID" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		fcswitchpart=/usr/bin/switch_partition.sh
		if [ ! -e ${ROOTACT}/lrr/com/cmd_shells/switch_partition.sh ] && [ -f ${fcswitchpart} ]; then
			ln -s ${fcswitchpart} ${ROOTACT}/lrr/com/cmd_shells
		fi
		createServices
		checkSupportUser
		addIptables
	;;

	oielec)	#OIelec
		echo "SERIALMODE=spi" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		echo "BOARDTYPE=x1" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		echo "SERVICELRR=/etc/init.d/lrr" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		LRROUI=$($ROOTACT/lrr/com/shells/getid.sh -o)
		LRRGID=$($ROOTACT/lrr/com/shells/getid.sh -u)
		echo "LRROUI=$LRROUI" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		echo "LRRGID=$LRRGID" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		cat $ROOTACT/lrr/com/lrrservice.sh | sed "s?_REPLACEWITHROOTACT_?$ROOTACT?" > /etc/init.d/lrr
		chmod +x /etc/init.d/lrr
		update-rc.d lrr defaults
		createServices
		checkSupportUser
	;;
	flexpico) # Flex Pico
		echo "SERIALMODE=spi" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		echo "BOARDTYPE=x1" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		echo "SERVICELRR=/etc/init.d/lrr" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		LRROUI=$($ROOTACT/lrr/com/shells/getid.sh -o)
		LRRGID=$($ROOTACT/lrr/com/shells/getid.sh -u)
		echo "LRROUI=$LRROUI" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		echo "LRRGID=$LRRGID" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		# Remove original factory lora service (lora_pkt_fwd, a simple pkt_forwarder) and disable its monitoring
		if [ -f "/etc/rc.d/S94lora" ]; then
			sed -i 's/^lora_pmon/#lora_pmon/' /etc/rc.local
			kill $(ps | grep lora_pmon | grep -v grep | awk -F " " '{print $1}')
			/etc/init.d/lora stop
			/etc/init.d/lora disable
		fi
		createServices
		checkSupportUser
	;;
    tracknet)

        echo "SERIALMODE=spi" >> $ROOTACT/usr/etc/lrr/_parameters.sh
        echo "BOARDTYPE=x1" >> $ROOTACT/usr/etc/lrr/_parameters.sh
        echo "SERVICELRR=/etc/init.d/lrr" >> $ROOTACT/usr/etc/lrr/_parameters.sh
        cat $ROOTACT/lrr/com/lrrservice.sh | sed "s?_REPLACEWITHROOTACT_?$ROOTACT?" > /etc/init.d/lrr
        chmod +x /etc/init.d/lrr
        cat > /etc/init.d/lrrs <<EOF
#!/bin/sh /etc/rc.common

START=99
STOP=99

start() {
    logger -s -p info -t "[ACT]" "Starting Actility LRR service."
   /etc/init.d/lrr start
}

stop() {
    logger -s -p info -t "[ACT]" "Stopping Actility LRR service."i
   /etc/init.d/lrr stop
}

EOF
        chmod +x /etc/init.d/lrrs
        if [ ! -f "/etc/rc.d/S99lrrs" ]
        then
            ln -s /etc/init.d/lrr /etc/rc.d/S99lrrs > /dev/null
        fi

        # custom antenna gain configuration
        #cat > $ROOTACT/usr/etc/lrr/custom.ini <<EOF
#[antenna:0]
#    cableloss=1.0
#    gain=3.0
#EOF
 
        checkSupportUserTracknet
        LRROUI=$($ROOTACT/lrr/com/shells/getid.sh -o) 
        LRRGID=$($ROOTACT/lrr/com/shells/getid.sh -u) 
        echo "LRROUI=$LRROUI" >> $ROOTACT/usr/etc/lrr/_parameters.sh 
        echo "LRRGID=$LRRGID" >> $ROOTACT/usr/etc/lrr/_parameters.sh            
        ;;

	linux-x86|linux-x86_64) #linux 32.64 bits generic with semtech pico via tty
		echo "SERIALMODE=tty" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		echo "BOARDTYPE=x1" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		echo "SERVICELRR=/etc/init.d/lrr" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		LRROUI=$($ROOTACT/lrr/com/shells/getid.sh -o)
		LRRGID=$($ROOTACT/lrr/com/shells/getid.sh -u)
		echo "LRROUI=$LRROUI" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		echo "LRRGID=$LRRGID" >> $ROOTACT/usr/etc/lrr/_parameters.sh
#		cat $ROOTACT/lrr/com/lrrservice.sh | sed "s?_REPLACEWITHROOTACT_?$ROOTACT?" > /etc/init.d/lrr
#		chmod +x /etc/init.d/lrr
#		update-rc.d lrr defaults

		echo "Do not create user support on target $SYSTEM"
		echo "Do not create service LRR on targe $SYSTEM"
	;;

esac

# end of former mechanism
fi

#
# set postinstall configuration
#
setLrrSetting

if [ "$SYSTEM" != "linux-x86" -a "$SYSTEM" != "linux-x86_64" ]
then
	doPostinstall
    if [ "$RESTART_SERVICES" = 1 ]; then
	    restartServices
    fi
fi

echo	"System configuration done"

exit	0
