#!/bin/sh

KERLINK_DIR=/usr/rootfs_rw/etc

if [ ! -d ${KERLINK_DIR} ]; then
    #either a standard gateway or a kerlink with a new firmware
    echo "/etc"
    exit 0
fi

# Kerlink spoecific directory present:
# - either firmware > 4.x: still present after an upgrade -> ignore it
# - or it is actually an old firmware so it has to be used

FW_MAJOR_VERSION=$(grep Version /.update/opkg/info/keros.control | awk '{print $2}' | cut -f1 -d'.')
if [ "$FW_MAJOR_VERSION" -ge 4  ]; then
    echo "/etc"
else
    echo "${KERLINK_DIR}"
fi



