#!/bin/sh

set -x

case $SYSTEM in
    wirmav2)
        SSH_OPTION_OPT="-y -N -I600"
        ;;
    fcloc|fclamp|fcpico|tektelic|tek_macro16|tek_micro8|tek_enterprise|tek_dish64)
        SSH_OPTION_OPT="-y -N -y -y"
        ;;
    *)
        SSH_OPTION_OPT="-y -N -o StrictHostKeyChecking=no"
        ;;
esac

echo "$SSH_OPTION_OPT"

exit 0
