##
## @file
## @author Actility
## @copyright Actility SA
## @brief Environment Variable Checking
##
## @details
## This script is used to perform checking of needed environment variables
## . build: variables needed during LRR build
## . system: variables related to system used before LRR installation
## . lrr: variables set during LRR installation
##

#
# check definition consistency
# do not use Bash specific mechanism
#

ERROR=0

usage() {
    echo "$0 [system|lrr]" 
}

success() {
    echo "OK: $1"
}

error() {
    echo "ERROR: $1"
    ERROR=1
}

getVal() {
    # most common syntax
    eval "val=\${$1}"
}

mandatory() {
    getVal $1
    if [ -z "$val" ]; then
        error "Mandatory variable $1 not set"
        return
    fi
    success "$1 defined: $val"
}

oneBoolean() {
    for var in $1; do
        getVal $var
        if [ "$val" = "y" ]; then
            success "at least one option set in [$1]"
            return
        fi
    done
    error "No boolan set in [$1]"
}

inList() {
    getVal $1
    if [ "$val" = "" ]; then
        current="empty"
    else
        current=$val
    fi
    for elem in $2; do
        if [ "$val" = "$elem" ]; then
            success "$1: $val in ($2)"
            return
        fi
    done
    error "$1 ($current) not in [$2]"
}

checkDir() {
    getVal $1
    if [ -z "$val" ]; then
        error "$1 empty instead of referencing a directory"
        return
    fi
    if [ ! -d "$val" ]; then
        error "$1: $val is not a valid directory"
        return
    fi
    success "$1: valid directory $val"
}

checkExe() {
    getVal $1
    if [ -z "$val" ]; then
        error "$1 empty instead of referencing a executable"
        return
    fi
    if [ ! -x "$val" ]; then
        error "$1: $val is not a valid executable (check path and permissions)"
    fi
    success "$1: valid executable $val"
}

checkFile() {
    getVal $1
    if [ -z "$val" ]; then
        error "$1 empty instead of referencing a file"
        return
    fi
    if [ ! -f "$val" ]; then
        error "$1: $val is not a valid file (check path and permissions)"
    fi
    success "$1: valid file $val"
}

if [ $# -lt 1 ]; then
    usage
    exit 1
fi

echo "-----------------------------------------------------------"
echo "Checking consistency of $1 definition"

if [ "$1" = "build" -o "$1" = "system" ]; then
    # control before building and before installing on gateway

    mandatory SYSTEM
    mandatory MANUFACTURER
    mandatory FIRMWARE
    mandatory MANUFACTURER_OUI

    inList SEMTECH_REFDESIGN "1.0 1.5 2.1 corecell"

    oneBoolean "SEMTECH_V1_0 SEMTECH_V1_5 SEMTECH_V2_1 SEMTECH_CORECELL"

    # commands used by suplog
    mandatory TERMINFO
    mandatory NETSTAT
    mandatory VIEW_NTP_CONF

    mandatory TRACE_BACKUP_DIR 

fi

if [ "$1" = "system" ]; then

    # control before installing on gateway

    oneBoolean "TAR_OPTION_X TAR_OPTION_EXCLUDE"

    checkFile NETWORK_INTERFACE_FILE

    checkDir SYSTEM_ETC

    checkExe IPSEC
    checkFile IPSEC_CONF
    if [ "$SYSTEM" != "ciscoms" ]; then
        checkFile NTP_SERVICE
    fi
    checkExe SFTP
    checkExe IPTABLES_BIN

    mandatory NETWORK_INTERFACE_FILE

fi

if [ "$1" = "lrr" ]; then

    # check services
    for svc in CHECKVPN IPFAILOVER; do
        service_file=$(echo $svc | tr '[A-Z]' '[a-z]')
        service_file="${service_file}2"
        var=${svc}_SERVICE
        source $ROOTACT/lrr/services/${service_file}
        [ ! -z "$ONSYSTEM" -a -z "$(echo $ONSYSTEM | grep $SYSTEM)" ] && continue
        checkExe $var
    done

    # setting used by suplog
    checkFile SYSTEM_LOG
    # not always present (depend on config) and not abslolutely mandatory (just to view it)
    # checkFile CHARON_LOG


fi

echo "-----------------------------------------------------------"
exit $ERROR
