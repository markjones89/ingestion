#!/bin/sh

product=$(urtool -g | grep -E ^product | cut -d':' -f2 | sed 's/ //g')
partnumber=$(urtool -g | grep -E ^sonboardsn | cut -d':' -f2 | sed 's/ //g')
echo "UG$product-$partnumber"