#!/bin/sh

ROOTACT=/home/actility

SYSTEM_ETC=/etc

SERVICEPREFIX="$SYSTEM_ETC/init.d/"

servicelrr=/etc/init.d/lrr

startService()
{
    srvdir="$1"
    srvname="$2"

    [ -z "$srvdir" -o ! -e "$srvdir/$srvname" ] && continue

    unset SERVICENAME SERVICESOURCE ONSYSTEM

    # ignore readme
    [ ! -f "$srvdir/$srvname" -o "$srvname" = "readme" ] && continue

    # set SERVICENAME and SERVICESOURCE
    . $srvdir/$srvname

    # if ONSYSTEM set, activated only if system is specified
    [ ! -z "$ONSYSTEM" -a -z "$(echo $ONSYSTEM | grep $SYSTEM)" ] && continue

    # check SERVICENAME and SERVICESOURCE
    if [ -z "$SERVICENAME" -o -z "$SERVICESOURCE" ]
    then
        echo "SERVICENAME or SERVICESOURCE not set, file '$srvname' ignored"
        return
    fi

    # identify service path

    srv="/etc/init.d/$SERVICENAME"

    # check if service file exists
    if [ ! -f "$srv" ]
    then
        echo "Can't find '$srv', can't start service"
        continue
    fi

    echo "start service $SERVICENAME"
    $srv start
}

startServices()
{
    srvdir="$ROOTACT/lrr/services"

    [ ! -d "$srvdir" ] && return

    # scan all files
    for f in $(ls $srvdir)
    do
        startService "$srvdir" "$f"
    done
}

startServices