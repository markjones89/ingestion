#!/bin/sh

cat /etc/issue