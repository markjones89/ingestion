#!/bin/sh

ps $*
exit $?
