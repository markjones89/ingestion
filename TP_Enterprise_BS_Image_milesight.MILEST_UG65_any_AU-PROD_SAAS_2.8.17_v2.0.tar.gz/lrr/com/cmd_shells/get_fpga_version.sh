#!/bin/sh

export PATH=$PATH:$ROOTACT/lrr/com/

. ${ROOTACT}/lrr/com/_functions.sh

get_spidevice

if [ "$SYSTEM" = "ug6x" ];then
	echo "no support fpga"
	exit 0
fi

#This will call the get_fpga_version.x binary and format the returned version

if [ ! -f $ROOTACT/lrr/com/get_fpga_version.x ]; then
	echo "get_fpga_version.x not found, cannot read FPGA version"
	exit 1
fi

#run FPGA binary
get_fpga_version.x -d ${SPIDEVICE} | grep 'FPGA Version' | sed 's/FPGA Version://g'
