#!/bin/sh

cat $ROOTACT/var/log/lrr/logicchan.txt
exit 0
