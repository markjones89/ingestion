#!/bin/sh

DELAY="15"
WAIT="0"
while   [ $# -gt 0 ]
do
	case "$1" in
		-E)	WAIT="1"
			shift
			;;
		*)	DELAY=$1
			shift
			;;
	esac
done
echo    "lrr will be restarted in $DELAY sec"
if [ "$WAIT" = "1" ]
then
	$ROOTACT/lrr/com/cmd_shells/restart_pending.sh $DELAY > /dev/null 2>&1
else
	$ROOTACT/lrr/com/cmd_shells/restart_pending.sh $DELAY > /dev/null 2>&1 &
fi
exit 0
