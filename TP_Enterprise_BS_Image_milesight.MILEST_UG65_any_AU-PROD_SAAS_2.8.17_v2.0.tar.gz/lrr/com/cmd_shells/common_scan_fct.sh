#!/bin/sh

[ -f /var/run/lrrsystem ] && . /var/run/lrrsystem
[ -f $ROOTACT/lrr/com/system_setting.sh ] && . $ROOTACT/lrr/com/system_setting.sh

. ${ROOTACT}/lrr/com/_functions.sh

#
# Definition of functions used by gateway-specific rfscanv1.sh
#

#
# parse command arguments
# to be called as described below
#   parse_arguments "$@"
#

parse_arguments() {

    # in the original rfscanv1.sh version, remaining parameters
    # were passed to the scan command. Except that all options
    # are consumed by the loop

    [ -z "$FTPUSERSUPPORT" ] && FTPUSERSUPPORT=ftp
    [ -z "$FTPPASSSUPPORT" ] && FTPPASSSUPPORT=
    [ -z "$FTPHOSTSUPPORT" ] && FTPHOSTSUPPORT=support1.actility.com
    [ -z "$FTPPORTSUPPORT" ] && FTPPORTSUPPORT=21
    [ -z "$USE_SFTP_SUPPORT" ] && USE_SFTP_SUPPORT=0
    [ -z "$BKPFTPUSERSUPPORT" ] && BKPFTPUSERSUPPORT=ftp
    [ -z "$BKPFTPPASSSUPPORT" ] && BKPFTPPASSSUPPORT=
    [ -z "$BKPFTPHOSTSUPPORT" ] && BKPFTPHOSTSUPPORT=support2.actility.com
    [ -z "$BKPFTPPORTSUPPORT" ] && BKPFTPPORTSUPPORT=21

    if [ "$LRRSYSTEM" = "ciscoms" ]; then
        [ -z "$SPIDEVICE" ] && SPIDEVICE=/dev/spidev1.0
    fi
    # note: method should be used for all gateways
    # not changed yet as it requires testing on each impacted gateways: to be done before validating them
    if [ -z "$SPIDEVICE" ]; then
        get_spidevice
        if [ -z "$SPIDEVICE" ]; then
            echo "SPI device for $LRRSYSTEM not defined in any lrr.ini"
            exit 1
        fi
    fi

    TOKEN=""
    FORCE="0"
    RANGE=""
    while	[ $# -gt 0 ]
    do
	    case	$1 in
		    -A)
			    shift
			    FTPHOSTSUPPORT="${1}"
			    shift
		    ;;
		    -P)
			    shift
			    FTPPORTSUPPORT="${1}"
			    shift
		    ;;
		    -U)
			    shift
			    FTPUSERSUPPORT="${1}"
			    shift
		    ;;
		    -W)
			    shift
			    FTPPASSSUPPORT="${1}"
			    shift
		    ;;
		    -F)
			    shift
			    FORCE="1"
		    ;;
		    -T)
			    shift
			    TOKEN="${1}"
			    shift
		    ;;
		    -X)
			    shift
			    USE_SFTP_SUPPORT="${1}"
			    shift
		    ;;
            -D)
                shift
                SPIDEVICE="${1}"
                shift
            ;;
            -f)
                shift
                RANGE="${1}"
                analyse_range
                shift
            ;;
		    *)
			    break
		    ;;
	    esac
    done
}

init_lrr_env() {

    # set $ROOTACT
    if	[ -z "$ROOTACT" ]
    then
	    if	[ -d /mnt/fsuser-1/actility ]
	    then
		    export ROOTACT=/mnt/fsuser-1/actility
	    else
		    export ROOTACT=/home/actility
	    fi
    fi

    # check if $ROOTACT directory exists
    if	[ ! -d "$ROOTACT" ]
    then
	    echo	"$ROOTACT does not exist"
	    exit	1
    fi

    if [ -f ${ROOTACT}/lrr/com/_parameters.sh ]
    then
	    . ${ROOTACT}/lrr/com/_parameters.sh
    fi
    if [ -f ${ROOTACT}/lrr/com/_functions.sh ]
    then
	    . ${ROOTACT}/lrr/com/_functions.sh
    fi
}

analyse_range() {

    FORCED_START=`echo $RANGE | awk -F: '{print $1}'`
    FORCED_STEP=`echo $RANGE | awk -F: '{print $2}'`
    FORCED_STOP=`echo $RANGE | awk -F: '{print $3}'`

    if [ -z "$FORCED_START"  ]; then
        exit 1
    fi
    if [ -z "$FORCED_STEP"  ]; then
        exit 1
    fi
    if [ -z "$FORCED_STOP"  ]; then
        exit 1
    fi
}

#
# check that a frequency is in a range
# !!! all are floating values !!!
#
# 1: value to check
# 2: min of the range
# 3: max of the range
check_range() {

    # convert floating values in decimal
    # for example 868.1 -> 868100
    v=`echo - | awk "{ print $1 * 1000 }"`
    val=${v%f.*}
    v=`echo - | awk "{ print $2 * 1000 }"`
    min=${v%f.*}
    v=`echo - | awk "{ print $3 * 1000 }"`
    max=${v%f.*}

    VALID=1
    if [ $val -lt $min ]; then
        VALID=0
    fi
    if [ $val -gt $max ]; then
        VALID=0
    fi
}

# retrieve value in usr/etc/lrr/lrr.ini and lrr/config/lrr.ini
# 1: section
# 2: keywork
get_lrrconf() {
    section="$1"
    keyword="$2"
    lrr_list="$ROOTACT/usr/etc/lrr/lrr.ini ${ROOTACT}/lrr/config/lrr.ini"
    for lrr_f in $lrr_list; do
        VALUE=$(getIniConf "$lrr_f" "$section" "$keyword")
        if [ ! -z "$VALUE" ]; then
            return
        fi
    done
}

get_ism_band() {

    ISM=""

    gib_list="$ROOTACT/usr/etc/lrr/lgw.ini $ROOTACT/usr/etc/lrr/lrr.ini ${ROOTACT}/lrr/config/lrr.ini"
    for gib_f in $gib_list; do
        ISM=`cat $gib_f | grep band= | sed "s/^;.*//g" | grep -oE "[^=]+$"`
        if [ ! -z "$ISM" ]; then
            return
        fi
    done
}

compute_rfreq() {
    RFREQ=`echo - | awk "{print ($FSTOP -$FSTART) / 2 + $FSTART}"`
}

# control that forced value are in the expected range
# useful to not break gateway or to comply with limitation
# of util_spectral_scan (on fcmlb for instance)
control_forced_range() {

    if [ ! -z "$RANGE" ]; then
        # check that forced values are in the supported range
        check_range $FORCED_START $FSTART $FSTOP
        if [ $VALID -eq 0 ]; then
            echo "$FORCED_START not in the range $FSTART $FSTOP"
            exit 1
        fi
        check_range $FORCED_STOP $FSTART $FSTOP
        if [ $VALID -eq 0 ]; then
            echo "$FORCED_STOP not in the range $FSTART $FSTOP"
            exit 1
        fi

        FSTART=$FORCED_START
        FSTEP=$FORCED_STEP
        FSTOP=$FORCED_STOP
    else
        # if values were not forced by the user, check if there is a custom value
        get_lrrconf "rfscan" "step"
        if [ ! -z "$VALUE" ]; then
            FSTEP=$VALUE
        fi
    fi
}

#
# INTEGER_RANGE=1 triggers value specific to fcpico
#
get_range_parameters() {

    # use for gateway-specific code on unknown ISM
    DEFAULT_RANGE=0

    if [ -z "$ISM" ]; then
        echo "ISM band not defined"
        exit 1
    fi

    # used by fcloc
    BAND="EU868"

    # use the ISM to determine range
    # if a range is forced, these values will be used for validation

    case "$ISM" in
	    eu868*)
			#Scan the whole band, no matter 8, 16 or 32 channels
		    FSTART="863.1"
		    FSTOP="869.9"
		    FSTEP="0.1"
		    BAND="EU868"
	        ;;
	    us915*)
			#Scan the whole band, no matter 8, 16 or 72 channels
		    FSTART="902.3"
		    FSTOP="914.9"
		    FSTEP="0.2"
		    BAND="US915"
 	        ;;
	    au915*)
		    FSTART="915.2"
		    FSTOP="927.8"
            FSTEP="0.2"
		    BAND="NONE"
	        ;;
	    as923*)
		    FSTART="915.2"
		    FSTOP="927.8"
            FSTEP="0.1"
		    BAND="NONE"
	        ;;
	    kr920*)
		    FSTART="917.1"
		    FSTOP="923.5"
            FSTEP="0.1"
		    BAND="NONE"
	        ;;
	    in865*)
		    FSTART="865.0"
		    FSTOP="867.0"
            FSTEP="0.0125"
		    BAND="NONE"
	        ;;
	    cn470*)
		    FSTART="470.3"
		    FSTOP="489.3"
            FSTEP="0.2"
		    BAND="NONE"
	        ;;
	    cn779*)
		    FSTART="779.1"
		    FSTOP="786.9"
            FSTEP="0.1"
		    BAND="NONE"
	        ;;
	    eu433*)
		    FSTART="433.175"
		    FSTOP="434.675"
            FSTEP="0.025"
		    BAND="NONE"
	        ;;
	    *)
            # for gateway-specific on default range
            DEFAULT_RANGE=1
	        ;;
    esac


    compute_rfreq

    control_forced_range
}

check_scan_tool() {
    if [ ! -x ${SCAN} ]
    then
        echo    "${SCAN} not found"
        exit 1
    fi
}

wait_for_radio_stop() {
    sleep 3
}

wait_for_scan_end() {
    sleep 3
}

init_scan() {

    LOGFILE=rfscanv1.log
    cd /tmp
    if	[ "$FORCE" = "1" ]
    then
	    rm -f /tmp/rfscan.pid
    fi
    if	[ -f /tmp/rfscan.pid ]
    then
	    echo "rfscan already running"
	    exit 1
    fi
    echo $$ > /tmp/rfscan.pid
    rm -f rssi_histogram.csv $LOGFILE
}

scan_with_rfreq() {

    DEVOPT=""
    if [ ! -z "$SPIDEVICE" ]; then
        DEVOPT="-d $SPIDEVICE"
    fi

    args="$DEVOPT $* $SCANOPT --rfreq $RFREQ -f $FSTART:$FSTEP:$FSTOP"
    echo "start scan $args"
    echo "$args" > $LOGFILE
    $SCAN $args >> $LOGFILE 2>&1
}

scan_with_band() {
    args="$* $SCANOPT --band $BAND -f $FSTART:$FSTEP:$FSTOP"
    echo "start scan $args"
    echo "$args" > $LOGFILE
    $SCAN $args >> $LOGFILE 2>&1
}

scan_with_minmax_rtype() {

    # RTYPE set in specific rfscanv1.sh

    DEVOPT=""
    if [ ! -z "$SPIDEVICE" ]; then
        DEVOPT="-d $SPIDEVICE"
    fi

    args="$DEVOPT $* $SCANOPT --fmin $FSTART --fmax $FSTOP --rtype $RTYPE"
    echo "start scan $args"
    echo "$args" > $LOGFILE
    $SCAN $args >> $LOGFILE 2>&1
}

scan_simple() {
    DEVOPT=""
    if [ "$LRRSYSTEM" = "tracknet" ]; then
        if [ ! -z "$SPIDEVICE" ]; then
            DEVOPT="-d $SPIDEVICE"
        fi
    fi

    args="$DEVOPT $* $SCANOPT -f $FSTART:$FSTEP:$FSTOP"
    echo "start scan $args"
    echo "$args" > $LOGFILE
    $SCAN $args >> $LOGFILE 2>&1
}

check_fcloc_compatibility() {

    # check FPGA/HAL compatibility
    if [ "$FPGA_VER" = "v48" ]
    then
        if [ "$HAL_VERSION" != "3.5.0" ]
        then
            echo "rfscan can not run on the FPGA version $FPGA_VER with HAL version $HAL_VERSION"
            exit 1
        fi
    elif [ "$FPGA_VER" = "v58" ]
    then
        if [ "$HAL_VERSION" != "4.0.0" -a "$HAL_VERSION" != "5.0.0" ]
        then
            echo "rfscan can not run on the FPGA version $FPGA_VER with HAL version $HAL_VERSION"
            exit 1
        fi
    elif [ "$FPGA_VER" = "v61" ]
    then
        if [ "$HAL_VERSION" != "5.1.0" ]
        then
            echo "rfscan can not run on the FPGA version $FPGA_VER with HAL version $HAL_VERSION"
            exit 1
        fi
    fi

    if [ "$FPGA_VER" = "v48" -a "$BAND" = "NONE" ]
    then
        echo "The ISM band $ISM not support to run rfscan on FPGA version $FPGA_VER"
        exit 1
    fi
}

#
# upload the scan output to the support servers
# 
# note: to comply with PT-1410, result file will contain board number if several boards are present
# 
# 1: optional: board number or empty if not in a multi-board environment
#

upload_csv() {

    board=$1

    # the exit code of the scan util is always 0 ... we return a empty file
    if [ ! -f rssi_histogram.csv ]
    then
	    touch rfscan_${LRRID}.csv
    else
        mv rssi_histogram.csv rfscan_${LRRID}.csv
    fi

    DATE=$(date '+%Y%m%d%H%M%S')
    FILESRC="/tmp/rfscan_${LRRID}.csv"

    EXTRA=""
    if [ ! -z "$board" ]; then
        # multiboard environment
        EXTRA="-${board}"
    fi

    if	[ "$TOKEN" = "" ]
    then
	    FILEDST="UPLOAD_LRR/RFSCAN/rfscan_${LRRID}${EXTRA}_${DATE}.csv"
    else
	    FILEDST="UPLOAD_LRR/RFSCAN/rfscan_${LRRID}${EXTRA}_${TOKEN}_${DATE}.csv"
    fi
    type gzip > /dev/null 2>&1
    if [ $? = 0 ]
    then
	    rm -f ${FILESRC}.gz
	    gzip -f $FILESRC
	    FILESRC=${FILESRC}.gz
	    FILEDST=${FILEDST}.gz
    fi

    UPLOADERR=0
    echo "lrr_UploadToRemote -u ${FTPUSERSUPPORT} -w ZZZZZZZZ -a ${FTPHOSTSUPPORT} -p ${FTPPORTSUPPORT} -l ${FILESRC} -r ${FILEDST} -s ${USE_SFTP_SUPPORT}"
    lrr_UploadToRemote -u ${FTPUSERSUPPORT} -w ${FTPPASSSUPPORT} -a ${FTPHOSTSUPPORT} -p ${FTPPORTSUPPORT} -l ${FILESRC} -r ${FILEDST} -s ${USE_SFTP_SUPPORT}

    [ "$?" != "0" ] && UPLOADERR=$(($UPLOADERR + 1))

    echo "lrr_UploadToRemote -u ${BKPFTPUSERSUPPORT} -w ZZZZZZZZ -a ${BKPFTPHOSTSUPPORT} -p ${BKPFTPPORTSUPPORT} -l ${FILESRC} -r ${FILEDST} -s ${USE_SFTP_SUPPORT}"
    lrr_UploadToRemote -u ${BKPFTPUSERSUPPORT} -w ${BKPFTPPASSSUPPORT} -a ${BKPFTPHOSTSUPPORT} -p ${BKPFTPPORTSUPPORT} -l ${FILESRC} -r ${FILEDST} -s ${USE_SFTP_SUPPORT}

    [ "$?" != "0" ] && UPLOADERR=$(($UPLOADERR + 1))

    if [ "$UPLOADERR" = "2" ]
    then
	    rm /tmp/rfscan.pid
	    echo "lrr_UploadToRemote failure $FILEDST not uploaded"
	    exit 1
    fi
    rm /tmp/rfscan.pid
}

