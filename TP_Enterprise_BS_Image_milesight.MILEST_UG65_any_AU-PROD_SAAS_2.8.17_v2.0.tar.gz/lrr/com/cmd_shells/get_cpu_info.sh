#!/bin/sh

cpu_count=$(cat /proc/stat | grep '^cpu[0-9]' | wc -l)

if [ $cpu_count -ge 1 ]; then
	echo "$cpu_count"
else
	# Default to 1
	echo "1"
fi
