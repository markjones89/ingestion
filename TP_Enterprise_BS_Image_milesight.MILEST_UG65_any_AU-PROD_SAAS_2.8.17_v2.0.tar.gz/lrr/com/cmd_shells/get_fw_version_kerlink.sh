#!/bin/sh

cat /etc/klk-version | grep FW | cut -d "=" -f 2

