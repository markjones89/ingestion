#!/bin/sh

. /var/run/lrrsystem

. ${ROOTACT}/lrr/com/system_setting.sh

if [ -z "$SEMTECH_REFDESIGN" ]; then
    echo "unknown"
fi
echo $SEMTECH_REFDESIGN
