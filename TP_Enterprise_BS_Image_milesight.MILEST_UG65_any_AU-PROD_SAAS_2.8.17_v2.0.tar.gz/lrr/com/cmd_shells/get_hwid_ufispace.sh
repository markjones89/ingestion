#!/bin/sh

nvram get hw_version
