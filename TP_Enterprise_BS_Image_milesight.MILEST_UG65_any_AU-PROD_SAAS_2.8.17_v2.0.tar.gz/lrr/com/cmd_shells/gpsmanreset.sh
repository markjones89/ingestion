#!/bin/sh


GPSMAN="${ROOTACT}/usr/etc/lrr/gpsman.ini"

if      [ ! -f ${GPSMAN} ]  
then                        
	echo    "no GPS location set manually"
	exit    1            
fi                                   

rm -f ${GPSMAN}

while	[ $# -gt 0 ]
do
	case	$1 in
		-E)	WAIT="-E"
			shift
		;;
		*)
			shift
		;;
	esac
done
$ROOTACT/lrr/com/cmd_shells/restart.sh $WAIT 3
exit $?
