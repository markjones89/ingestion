#!/bin/sh
#
#	Execute a radio scan
#	

[ -f "$ROOTACT/lrr/com/system_setting.sh" ] && . $ROOTACT/lrr/com/system_setting.sh
[ -f "$ROOTACT/lrr/com/system_api.sh" ] && . $ROOTACT/lrr/com/system_api.sh

. ${ROOTACT}/lrr/com/cmd_shells/common_scan_fct.sh

SystemGetFilePath "$ROOTACT/lrr/com/cmd_shells" "scan_fct.sh"
[ ! -z "$sysfilepath" ] && . $sysfilepath

SCAN=${ROOTACT}/lrr/util_spectral_scan/util_spectral_scan


# scan 1 board
# 1: board number if in multiple board mode, otherwise emtpy

scan_board() {

    # spidevice automatically compute in normal mode, just force it in multiboard environment
    board=$1
    if [ ! -z "$board" ]; then
        # retrieve the SPI device
        get_spidevice $board
        if [ -z "$SPIDEVICE" ]; then
            return
        fi
    fi

    init_scan
    SCANOPT=""
    if [ "$LRRSYSTEM" = "gemodu" -o "$LRRSYSTEM" = "tracknet" ]; then
        scan_simple
    elif [ "$LRRSYSTEM" = "fcloc" ]; then
        if [ "$FPGA_VER" = "v61" ]; then
            scan_with_rfreq
        else
            scan_with_band
        fi
    else
        # new mechanism: execute the command based on Semtech ref design
        if [ "$SEMTECH_REFDESIGN" != "" ]; then
            if [ "$SEMTECH_REFDESIGN" = "2.1" ]; then
                scan_with_rfreq
            else
                SCANOPT="-n 128"
                scan_simple
            fi 
        else
            scan_with_rfreq
        fi
    fi

    #sleep again if scan util exit immediatly
    wait_for_scan_end

    # board: empty or contains a board number in multiboard env. Ok with upload_csv
    upload_csv $board
}

parse_arguments "$@"

init_lrr_env

# PT-1410
# detect if multi-board scan is not disabled and several boards are present
nb_boards=1
multiboard_scan=$(getIniConf $ROOTACT/usr/etc/lrr/lrr.ini "lrr" "multiboard_scan")
if [ ! -z "$multiboard_scan" -a "$multiboard_scan" = 1 ]; then
    nb_boards=$(getIniConf $ROOTACT/usr/etc/lrr/lgw.ini "gen" "board")
    if [ -z "nb_boards" ]; then
        nb_boards=1
    fi
fi

get_ism_band
get_range_parameters

#
# gateway-specific checking
#

if [ "$LRRSYSTEM" = "fcloc" ]; then
    # check FGPA/HAL compatibility.
    # also check ISM band support.
    # exit if not supported.
    FPGA_VER=`${ROOTACT}/lrr/com/cmd_shells/${LRRSYSTEM}/util_gw_revision -f`
    check_fcloc_compatibility
fi

# GEMTEK ODU: hangs if LBT and FPGA version are not in sync
if [ "$SYSTEM" = "gemodu" ]; then
    FPGA_VER=$(${ROOTACT}/lrr/com/cmd_shells/get_fpga_version.sh)
    LBT_STATE=$(grep "lbt enable" ${ROOTACT}/var/log/lrr/radioparams.txt | awk '{print $2}')
    if [ "$FPGA_VER" = "31" ]
    then
        if [ "$LBT_STATE" = "enable=1" ]
        then
            echo "rfscan can not run on the FPGA version \"$FPGA_VER\" with lbt \"$LBT_STATE\""
            exit 1
        fi
    elif [ "$FPGA_VER" = "33" ]
    then
        if [ "$LBT_STATE" = "enable=0" ]
        then
            echo "rfscan can not run on the FPGA version \"$FPGA_VER\" with lbt \"$LBT_STATE\""
            exit 1
        fi
    else
        echo "rfscan can not run on the unknow FPGA version \"$FPGA_VER\""
        exit 1
    fi
fi

#give time to lrr process to stop radio thread
wait_for_radio_stop

check_scan_tool

LOGFILE=rfscanv1.log
if	[ "$FORCE" = "0" -a "$LRRSYSTEM" = "wirmav2" ]
then
	LORABOARD=$(get_version | grep LORABOARD_)
	if	[ -z "$LORABOARD" ]
	then
		echo "cannot detect if required hardware is present, try rfscanv0"
		SCAN=${ROOTACT}/lrr/util_rssi_histogram/util_rssi_histogram
        check_scan_tool
		LOGFILE=rfscanv0.log
	fi
#	TODO more checks on hardware are required
#	eval $LORABOARD ... check type / version ...
fi

if [ $nb_boards -gt 1 ]; then
    i=0
    while [ $i -lt $nb_boards ]; do
        scan_board $i
        i=$(($i + 1))
    done
else
    scan_board
fi

exit 0
