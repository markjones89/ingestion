#!/bin/sh

exec > /dev/null 2>&1

. /var/run/lrrsystem
. $ROOTACT/lrr/com/system_setting.sh
. $ROOTACT/lrr/com/system_api.sh

DELAY="15"
if	[ "$1" != "" ]
then
	DELAY=$1
fi

# "noroot" prevents the script to detect itself (prevent recursive calls)
SystemGetFilePath "$ROOTACT/lrr/com/cmd_shells" "reboot_pending.sh" "noroot"
if [ -x "$sysfilepath" ]; then
    # some version doesn't support delay so do it here and don't request it
    sleep $DELAY
    $sysfilepath 0
    # reboot is delayed so exit
    exit 0
fi

sleep $DELAY
reboot
