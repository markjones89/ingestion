#!/bin/sh

cat ${ROOTACT}/lrr/Version
