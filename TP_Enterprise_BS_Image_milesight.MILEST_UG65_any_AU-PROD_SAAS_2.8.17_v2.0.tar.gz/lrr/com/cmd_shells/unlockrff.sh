#!/bin/sh

. /var/run/lrrsystem

rm $ROOTACT/usr/etc/lrr/execrff_locked
exit $?
