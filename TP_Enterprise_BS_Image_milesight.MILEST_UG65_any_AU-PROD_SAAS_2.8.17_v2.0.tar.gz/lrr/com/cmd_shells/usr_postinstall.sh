#!/bin/sh

#
# this script is executed by sysconfiglrr.sh before executing $ROOTACT/usr/etc/lrr/usr_postinstall.sh if any
# Before exiting, it calls gateway-specific usr_postinstall.sh if present
#
# it contains mostly what was integrated into gateway packagers that should contain only configuration
#

echo "Common usr_postinstall.sh"

. $ROOTACT/lrr/com/system_api.sh

# execute root password generation if components are present
if [[ -f $ROOTACT/usr/etc/lrr/seed && -f $ROOTACT/usr/etc/lrr/keygen && -f $ROOTACT/usr/etc/lrr/keygen.sh ]]
then
    # PT-1878: do not delete keygen.sh as it can be used to set support pasword
    echo "- generate root password"
    $ROOTACT/usr/etc/lrr/keygen.sh update_pwd
fi

# create an preconfigure checkvpn2.ini: requested by Operations to avoid adding it in all config of all packagers
file=$ROOTACT/usr/etc/lrr/checkvpn2.ini
if [ ! -f "$file" ]; then
    echo "- generate checkvpn2.ini"
    cat > $file << EOF
[checkvpn2]
    tracelvl=0
EOF
fi

# execute gateway-specific usr_postinstall.sh if any
# "noroot" to avoid the script to call itself recursively
SystemGetFilePath "$ROOTACT/lrr/com/cmd_shells" "usr_postinstall.sh" "noroot"
if [ ! -z "$sysfilepath" ]; then
    $sysfilepath
fi
