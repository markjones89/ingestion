#!/bin/sh

# lrrplan.sh: executes tasks periodically or at a given time
# scan $ROOTACT/usr/data/lrrplan directory looking for file with name:
#   <YYYYMMDD>-<HHMMSS>-*
#   <YYYYMMDD>-<HHMMSS>-REPEAT<XY>-*
#   REPEAT<XY> can be used for periodic tasks. X=value Y=unit
#   units are S=seconds, H=hours, D=days
#   ex: 20180205-120000-test => february the 5th of 2018 at noon
#   ex: 20180205-120000-REPEAT1D-test2 => from february the 5th of 2018 at noon, repeat every day
# LOGFILE is by default /tmp/_resultlrrplan. It is deleted each time the size reach 100 K 

. /var/run/lrrsystem
. $ROOTACT/lrr/com/system_setting.sh

exec 2> /dev/null

TASKDIR=$ROOTACT/usr/data/lrr/lrrplan
LOGDIR=$ROOTACT/var/log/lrr/lrrplan
PERIOD=60
LOGFILE=$LOGDIR/resultlrrplan
LOGFILEMAXSZ=100000		# in bytes

# extract timestamp from filename
# filename must be of the form YYYYMMDD-HHMMSS-*
gettimestamp()
{
	f="$1"
	bf=$(basename $f)
#	y=${bf:0:4}
#	m=${bf:4:2}
#	d=${bf:6:2}
#	h=${bf:9:2}
#	min=${bf:11:2}
#	s=${bf:13:2}
	y=$(echo $bf | cut -c1-4)
	m=$(echo $bf | cut -c5-6)
	d=$(echo $bf | cut -c7-8)
	h=$(echo $bf | cut -c10-11)
	min=$(echo $bf | cut -c12-13)
	s=$(echo $bf | cut -c14-15)

	[ ! -z "$VERBOSE" ] && echo "$f => $y/$m/$d $h:$min:$s" >&2

	date -u -d "$y-$m-$d $h:$min:$s" +%s

}

# list files in $TASKDIR directory
# only files with name of the form YYYYMMDD-HHMMSS-* are listed
listfiles()
{
	# File names: YYYYMMDD-HHMMSS-*
#	[ ! -z "$VERBOSE" ] && echo "ls $TASKDIR" >&2
	ls $TASKDIR/[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]-[0-9][0-9][0-9][0-9][0-9][0-9]-* 2>/dev/null
}

# check if there are task to run
# set LSTTORUN with the list of script to run
# set PERIODONCE if period must be reduced for next time
listtorun()
{
	now=$(date -u +%s)
	next=$(($now + $PERIOD))
	[ ! -z "$VERBOSE" ] && echo "now=$now defaultnext=$next" >&2

	lst=$(listfiles)
	[ ! -z "$VERBOSE" ] && echo "lst='$lst'" >&2

	LSTTORUN=""
	for f in $lst
	do
		# calculate timestamp
		t=$(gettimestamp $f)

		# to be run
		if [ $t -le $now ]
		then
			[ ! -z "$VERBOSE" ] && echo "$f must be run" >&2
			LSTTORUN="$LSTTORUN $f"
			continue
		fi

		# to be run before next time => reduce PERIOD
		if [ $t -lt $next ]
		then
			diff=$(($t - $now))
			if [ $diff -lt $PERIODONCE ]
			then
				PERIODONCE=$diff
				next=$(($now + $PERIODONCE))
				[ ! -z "$VERBOSE" ] && echo "reduce period to $PERIODONCE" >&2
			fi
		fi
	done
}

# Extract REPEAT value if present
# If the filename is of the form YYYYMMDD-HHMMSS-REPEATXY-*, extract XY
# and return the corresponding value in seconds
getrepeat()
{
	f="$1"
	bf="$(basename $f)"
#	repeat="${bf:16:6}"
	repeat=$(echo $bf | cut -c17-22)

	if [ "$repeat" != "REPEAT" ]
	then
		echo "0"
		return
	fi

#	extract="${bf:22}"
	extract=$(echo $bf | cut -c23-)
#	dur="${extract%%[SHD]-*}"
	dur=$(echo $extract | sed "s/[SHD]-.*//")
#	extract="${extract%%-*}"
	extract=$(echo $bf | sed "s/^[0-9]*//")
#	unit="${extract:(-1)}"
	unit=$(echo $extract | cut -c1)

	add=0
	[ "$unit" = "S" ] && add=$dur
	[ "$unit" = "H" ] && add=$((3600 * $dur))
	[ "$unit" = "D" ] && add=$((86400 * $dur))

	echo "$add"
}

# rename file
# if it is a repeating script, rename with the timestamp of the next run
# if it is a one shot script, rename it DONE-<previousname>
# set PERIODONCE if needed
renamefile()
{
	f="$1"
	add=$(getrepeat $f)
	bf="$(basename $f)"
	df="$(dirname $f)"

	if [ $add -gt 0 ]
	then
		now=$(date -u +%s)
		t=$(gettimestamp $f)
		nt=$(($t + $add))
		diff=$(($nt - $now))
		if [ $diff -ge 0 -a $diff -lt $PERIODONCE ]
		then
			PERIODONCE=$diff
			[ ! -z "$VERBOSE" ] && echo "reduce period to $PERIODONCE" >&2
		fi
#		nf="$df/$(date -d @$nt +%Y%m%d-%H%M%S)-${bf:16}"
		nf="$df/$(date -u -d @$nt +%Y%m%d-%H%M%S)-$(echo $bf | cut -c17-)"
		[ ! -z "$VERBOSE" ] && echo "mv $f $nf"
		mv $f $nf
		return
	fi

	nf="$df/DONE-$bf"
	[ ! -z "$VERBOSE" ] && echo "mv $f $nf"
	mv $f $nf

}

# check if a file exists and if it's name is correct
checkfile()
{
	f="$1"
	if [ -z "$f" ]
	then
		echo "A filename is required !"
		exit 1
	fi

	if [ ! -f "$f" ]
	then
		echo "Can not find file '$f' !"
		exit 1
	fi

	if [ ${#f} -lt 17 ]
	then
		echo "Incorrect filename '$f' ! (too short)"
		use
		exit 1
	fi

	t=$(gettimestamp $f)
	if [ -z "$t" ]
	then
		echo "Incorrect filename '$f' ! (date not correct)"
		use
		exit 1
	fi
	if [ $t -eq 0 ]
	then
		echo "Incorrect filename '$f' ! (date not correct, convert pb)"
		use
		exit 1
	fi

	return 0
}

# print help
use()
{
	echo "$0 [-p <period>] [-d <taskdir>] [-l <logfile>] [-s <maxlogsize>] [-v] => run daemon"
	echo "or $0 [-a <filename>] [-v] [-h] => add a task and stop"
	echo "or $0 [-r <filename>] => calculate remaining time before execution of file"
	echo "  -p <period>: set period. Daemon will wake up ever <period> seconds to check for new tasks to run"
	echo "               default: 60 s"
	echo "  -d <taskdir>: set directory where tasks are found (for tests only)"
	echo "  -l <logfile>: set logfile. default is /tmp/_resultlrrplan"
	echo "  -s <maxlogsize>: set max size of logfile. File is deleted if size reach the max. default is 100 K"
	echo "  -r <filename>: just calculate remaining time before execution of a file with this name"
	echo "  -a <filename>: add a task. Copy <filename> to taskdir directory."
	echo "     Filename must respect format <YYYYMMDD>-<HHMMSS>-[REPEAT<XY>-]*"
	echo "     Examples: 20180204-180000-mytask"
	echo "               20180204-180000-REPEAT1D-mydailytask"
	echo "  -g <nbsec>: get name to use for a script that must be run in <nbsec> seconds"
	echo "  -v: verbose mode"
	echo "  -h: help"
}


#
# Main
#

SAVCMD="$0 $*"

# get parameters
while [ $# -gt 0 ]
do
	case $1 in
                -a)
			shift
			if [ -z "$1" ]
			then
				echo "Filename required with option -a !"
				use
				exit 1
			fi
                        FILETOADD=$1
                ;;
                -p)
			shift
                        PERIOD=$1
                ;;
                -r)
			shift
			REMAINING="1"
			REMFILE="$1"
                ;;
                -d)
			shift
                        TASKDIR=$1
                ;;
                -l)
			shift
			LOGFILE=$1
			[ -z "$LOGFILE" ] && exit 1
                ;;
                -s)
			shift
			LOGFILEMAXSZ=$1
                ;;
                -v)
			VERBOSE="1"
                ;;
                -g)
			shift
			GETNAME="$1"
                ;;
                -h)
			use
			exit 1
                ;;
        esac
        shift
done

[ ! -z "$VERBOSE" ] && echo "$SAVCMD"

if	[ ! -d "$ROOTACT" ]
then
	echo	"$ROOTACT does not exist"
	exit	0
fi

if [ ! -z "$GETNAME" ]
then
	now=$(date -u +%s)
	tm=$(($now + $GETNAME))
	name=$(date -u -d @$tm +%Y%m%d-%H%M%S)
	echo "$name"
	exit 0
fi

if [ ! -z "$REMAINING" ]
then
	[ -z "$REMFILE" ] && exit 1
	t=$(gettimestamp $REMFILE)
	now=$(date -u +%s)
	diff=$(($t - $now))
	echo "$diff"
	exit 0
fi

if [ ! -z "$FILETOADD" ]
then
	if [ ! -f "$FILETOADD" ]
	then
		echo "Can not find file '$FILETOADD' !"
		use
		exit 1
	fi

	checkfile $FILETOADD
	if [ $? -ne 0 ]
	then
		exit 1
	fi

	[ ! -x "$FILETOADD" ] && chmod +x "$FILETOADD"

	[ ! -d "$TASKDIR" ] && mkdir -p $TASKDIR
	cp $FILETOADD $TASKDIR
	exit 0
fi

# main loop
[ ! -d "$LOGDIR" ] && mkdir -p "$LOGDIR"
PERIODONCE=$(($PERIOD + 10))
run="1"
echo "################################################################" >> $LOGFILE
echo "$(date -u '+%y/%m/%d %H:%M:%S'): Start lrrplan.sh period=$PERIOD" >> $LOGFILE
echo "################################################################" >> $LOGFILE
while [ "$run" = "1" ]
do
	# identify tasks to be run now
	echo
	echo "$(date -u '+%y/%m/%d %H:%M:%S'): New loop  ..."
	listtorun
#	[ ! -z "$VERBOSE" ] && echo "LSTTORUN='$LSTTORUN'"

	# run task to be run
	for f in $LSTTORUN
	do
		[ -f $LOGFILE -a $(du -b $LOGFILE | cut -f 1) -gt $LOGFILEMAXSZ ] && rm -f $LOGFILE
		echo "$(date -u '+%y/%m/%d %H:%M:%S'): Run $f ..."
		echo "$(date -u '+%y/%m/%d %H:%M:%S'): Run $f ..." >> $LOGFILE

		# PT-1590: execute wia a temporary file to allow renaming of script without the need
		# to check if background shell has already launched it
		fname=$(basename $f)
		tmpfile=/tmp/EXEC-$fname
		cp $f $tmpfile
		sh -c "$tmpfile >>$LOGFILE 2>&1 ; rm $tmpfile" &
		res=$?
		[ ! -z "$VERBOSE" ] && echo "   result=$res"
#		[ ! -z "$VERBOSE" ] && echo "   output='$(cat /tmp/_resultlrrplan)'"

		# can be renamed safely as the original script is no more used
		renamefile $f
	done

	# if needed sleep less time to execute next task at the good time
	if [ $PERIODONCE -lt $PERIOD ]
	then
		[ ! -z "$VERBOSE" ] && echo "$(date -u +%s): sleep only $PERIODONCE"
		sleep $PERIODONCE
		PERIODONCE=$(($PERIOD + 10))
	else
		[ ! -z "$VERBOSE" ] && echo "sleep $PERIOD"
		sleep $PERIOD
	fi
done


