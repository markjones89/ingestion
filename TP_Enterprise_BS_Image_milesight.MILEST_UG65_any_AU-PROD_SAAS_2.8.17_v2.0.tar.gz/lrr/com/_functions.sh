#!/bin/sh
# vim:ft=sh:set noet ts=4 sw=4:

# Return codes
RET_FAILURE=1
RET_SUCCESS=0


#	_checkUseSftp
#
#	This function is used to check the availability of sftp and sshpass binaries
#
#	It takes no arguments
#
#	Returns: RET_SUCCESS or RET_FAILURE
#
_checkUseSftp () {

    setting=$ROOTACT/lrr/com/system_setting.sh
    if [ -f $setting ]; then
        . $setting
    fi

	# if not launched by shelllrr (service or manually) LRRSYSTEM is not set
	[ -z "$LRRSYSTEM" -a ! -z "$SYSTEM" ] && LRRSYSTEM="$SYSTEM"

	# TODO: set available arguments at build time (sftp4lrr) or by testing arguments during installation
	if	[ "$FIRMWARE" = "keros" -a "$LRRSYSTEM" != "wirmav2" ] || [ "$FIRMWARE" = "mlinux" -o "$LRRSYSTEM" = "gemodu" -o "$LRRSYSTEM" = "gempiconext" ] || [ "$SYSTEM" = "ciscoms" ] || [ "$SYSTEM" = "ug6x" ]
	then
		SSH_OPTIONS=" -oStrictHostKeyChecking=no -oBatchMode=no"
		if [ "$LRRSYSTEM" = "gemodu" ]; then
			SSH_OPTIONS="$SSH_OPTIONS -oUserKnownHostsFile=/dev/null"
		fi
	else
		SSH_OPTIONS=" -y -y "
	fi

	# use sftp from the lrr by default
	if [ -f "${ROOTACT}/lrr/sftp/sftp" ]
	then
		EXESFTP=${ROOTACT}/lrr/sftp/sftp
	else
		# check if a sftp is present
		type sftp > /dev/null 2>&1
		if [ $? -eq 0 ]
		then
			EXESFTP=sftp
		else
			echo "sftp binary not found !"
			return $RET_FAILURE
		fi
	fi

	EXESSHPASS=sshpass
	EXESSHPASS_ACT=${ROOTACT}/lrr/com/sshpass.x
	type $EXESSHPASS > /dev/null 2>&1
	ret1=$?
	type $EXESSHPASS_ACT > /dev/null 2>&1
	ret2=$?
	if [ $ret1 -eq 0 ] || [ $ret2 -eq  0 ]; then
		if [ $ret1 != 0 ] ; then
			EXESSHPASS=$EXESSHPASS_ACT
		fi
	else
		echo "sshpass binary not found !"
		return $RET_FAILURE
	fi
	return $RET_SUCCESS
}


#	_getArgs
#
#	This function is used to parse and extract the arguments given to download or upload functions.
#
#	It takes no arguments
#
#	Returns: RET_SUCCESS or RET_FAILURE
#
_getArgs() {

	t_local_file=""
	t_remote_file=""
	t_host=""
	t_port=""
	t_user=""
	t_password=""
	t_use_sftp=""
	t_timeout=""

	while [ $# -gt 0 ]; do
		case $1 in
			-u)		shift
					t_user="${1}"
					;;
			-w) 	shift
					t_password="${1}"
					;;
			-a) 	shift
					t_host="${1}"
					;;
			-p)		shift
					t_port="${1}"
					;;
			-l)		shift
					t_local_file="${1}"
					;;
			-r)		shift
					t_remote_file="${1}"
					;;
			-s)		shift
					t_use_sftp="${1}"
					;;
			-c)		shift
					t_crypted="1"
					;;
			-i)     shift
					t_identity="${1}"
					;;
			-t)     shift
					t_timeout="${1}"
					;;
			*)		shift ;;
		esac
	done

	if [ -z "${t_remote_file}" ]; then
		t_remote_file="${t_local_file}"
	fi

	if [ -z "${t_user}" ]; then
		echo "ERROR: User must be set (even for an anonymous mode)"
		return $RET_FAILURE
	fi


	if [ ! -z "${t_use_sftp}" ] && [ ${t_use_sftp} -eq 1 ]; then
		if [ -z "${t_password}" -a -z "${t_identity}" ]; then
			echo "ERROR: Password or identity must be set for SFTP mode"
			return $RET_FAILURE
		fi
	fi

	# Specific use by suplog, password is encrypted, key is in environment var SUPLOGKEY
	if [ "$t_crypted" = "1" ]
	then
		DECRYPT="$ROOTACT/lrr/com/keycrypt.x -k SUPLOGKEY "
		t_password="$($DECRYPT $t_password)"
	fi

	return $RET_SUCCESS

}

#
#	lrr_checkPid()
#
#	check if the pid is valid = if the process is running
#
#	Input
#	1: pid
#
#	Return on stdout:
#		0 if the process exitss
#		different from 0 if pid not valid
#
lrr_checkPid()
{
	lcpPid="$1"
	if [ -z "$lcpPid" ]
	then
		echo "1"
		return
	fi

	# use ls /proc instead of ps that has not the same options on every gw
	ls /proc/$lcpPid/ >/dev/null 2>&1
	echo "$?"
}

#
#   lrr_Execute
#
#   execute a command
#   - make the command output available into a file referenced by LRR_CMD_LOG
#   - copy command output into LRR_CMD_LAST_ERROR_LOG in case of error so issue can be investigated even if successfull commands were run afterwards
#
#   Important
#   - command may contain password so it must not be added into the output file. Up to the caller to add it in its log if safe
#
#   Input
#   1: command to be executed
#
#   Returned value
#   - status of command execution
#
#   Results
#   LRR_CMD_LOG             file containing command outputs
#   LRR_CMD_LAST_ERROR_LOG  file updated only in case of error to always kept the outputs of the last failing command
#   LRR_CMD_STATUS          exit code of the executed command
#
lrr_Execute() {


    LRR_CMD_LOG=/tmp/last_cmd.log
    LRR_CMD_LAST_ERROR_LOG=/tmp/last_cmd_error.log

    # create and set permissions so any script can write: commands work only when "root" but allow rw access when "support"
    touch $LRR_CMD_LOG 2>/dev/null
    touch $LRR_CMD_LAST_ERROR_LOG 2>/dev/null
    chmod a+rw $LRR_CMD_LOG 2>/dev/null
    chmod a+rw $LRR_CMD_LAST_ERROR_LOG 2>/dev/null

    eval "$@" > $LRR_CMD_LOG 2>&1
    rc=$?
    if [ $rc != 0 ]; then
        cp $LRR_CMD_LOG $LRR_CMD_LAST_ERROR_LOG
        # permissions are reset when root
        chmod a+rw $LRR_CMD_LAST_ERROR_LOG 2>/dev/null
    fi
    LRR_CMD_STATUS=$rc
    return $rc
}

#
#	lrr_KillChild()
#
#	kill all children of a pid
#
#	Input
#	1: parent pid
#
lrr_KillChild()
{
        ppid="$1"
        [ -z "$ppid" ] && return
        lstpid=$(grep "^PPid:.*$ppid"  /proc/*/status | sed "s?^/proc/??" | sed "s?/.*??" 2>/dev/null)
        kill $lstpid 2> /dev/null
}

#
#   lrr_ExecuteMaxTime
#
#   execute a command
#   - make the command output available into a file referenced by LRR_CMD_LOG
#   - copy command output into LRR_CMD_LAST_ERROR_LOG in case of error so issue can be investigated even if successfull commands were run afterwards
#
#   Important
#   - command may contain password so it must not be added into the output file. Up to the caller to add it in its log if safe
#
#   Input
#   1: max time allowed
#   2: command to be executed
#
#   Returned value
#   - status of command execution
#
#   Results
#   LRR_CMD_LOG             file containing command outputs
#   LRR_CMD_LAST_ERROR_LOG  file updated only in case of error to always kept the outputs of the last failing command
#   LRR_CMD_STATUS          exit code of the executed command
#
lrr_ExecuteMaxTime() {
    LRR_CMD_LOG=/tmp/last_cmd.log
    LRR_CMD_LAST_ERROR_LOG=/tmp/last_cmd_error.log

    # create and set permissions so any script can write: commands work only when "root" but allow rw access when "support"
    touch $LRR_CMD_LOG 2>/dev/null
    touch $LRR_CMD_LAST_ERROR_LOG 2>/dev/null
    chmod a+rw $LRR_CMD_LOG 2>/dev/null
    chmod a+rw $LRR_CMD_LAST_ERROR_LOG 2>/dev/null

	starttime=$(date +%s)
	maxtime="$1"
	# security, max allowed time is one day
	if [ $maxtime -lt 0 -o $maxtime -gt 86400 ]
	then
		echo "lrr_ExecuteMaxTime error: firstparameter incorrect '$maxtime', expecting a duration is seconds"
		return
	fi
	shift

	savcmd="$@"
    eval "$@" > $LRR_CMD_LOG 2>&1 &
	pidcmd=$!
    rc=$?
	waittime=1
	timespent=0

	check=$(lrr_checkPid $pidcmd)
	while [ $check -eq 0 -a $timespent -lt $maxtime ]
	do
		sleep $waittime
		check=$(lrr_checkPid $pidcmd)
		[ $waittime -ne 3 ] && waittime=3
		timespent=$(($(date +%s) - $starttime))
	done

	check=$(lrr_checkPid $pidcmd)
	if [ $check -eq 0 ]
	then
		echo "Command '$savcmd' is still running after $maxtime seconds => killed"
		lrr_KillChild $pidcmd
		check=$(lrr_checkPid $pidcmd)
	fi

    if [ $check -eq 0 ]
	then
        cp $LRR_CMD_LOG $LRR_CMD_LAST_ERROR_LOG
        # permissions are reset when root

        chmod a+rw $LRR_CMD_LAST_ERROR_LOG 2>/dev/null
    fi
    LRR_CMD_STATUS=$check
    return $check
}

#	lrr_DownloadFromRemote -u username -w password -l local_filename [-r remote_filename] -a host_address -p host_port [-s use_sftp] [-t timeout]
#
#	This function is used to download a file from a remote server using either FTP or SFTP protocol.
#
#	Arguments:
#		-u username			remote host user login. Must be always set, even in case of anonymous FTP
#		-w password			remote host user password. Can be omitted in case of anonymous FTP. Mandatory in case of SFTP
#		-l local_filename	local file name
#		-r remote_filename	remote file name. If omitted, use the same path as local filename
#		-a host_address		remote host address
#		-p host_port		remote host port
#		-s use_sftp			set to 1 to use sftp. If 0 or not set, use classic ftp.
#
#	Returns: RET_FAILURE or the value returned by the transfert command
#
lrr_DownloadFromRemote() {
	if	[ $# -lt 6 ] ; then
		echo "lrr_DownloadFromRemote wrapper not enough arg"
		return $RET_FAILURE
	fi

	_getArgs $*
	if [ $? -eq $RET_FAILURE ]; then
		return $RET_FAILURE
	fi

	# if not launched by shelllrr (service or manually) LRRSYSTEM is not set
	[ -z "$LRRSYSTEM" -a ! -z "$SYSTEM" ] && LRRSYSTEM="$SYSTEM"

	$ROOTACT/lrr/com/ipvxchk.x -6 "${t_host}"
	if [ $? = "0" ]; then
		t_host="[${t_host}]"
		echo "brackets added to ipv6@ ${t_host}"
	fi

	# If requested, try with sftp
	if [ ! -z "${t_use_sftp}" ] && [ ${t_use_sftp} -eq 1 ]; then
		_checkUseSftp
		if [ $? -eq $RET_SUCCESS ]; then
			if [ -z "${t_identity}" ]; then
				echo "lrr_DownloadFromRemote uses ${EXESFTP} -P ${t_port} ${SSH_OPTIONS} \"${t_user}@${t_host}:${t_remote_file}\" ${t_local_file}"
				lrr_Execute ${EXESSHPASS} -p \"${t_password}\" ${EXESFTP} -P ${t_port} ${SSH_OPTIONS} \"${t_user}@${t_host}:${t_remote_file}\" \"${t_local_file}\"
				return $?
			else
				echo "lrr_DownloadFromRemote uses ${EXESFTP} -i ${t_identity} -P ${t_port} ${SSH_OPTIONS} \"${t_user}@${t_host}:${t_remote_file}\" ${t_local_file}"
				lrr_Execute ${EXESFTP} -i \"${t_identity}\" -P ${t_port} ${SSH_OPTIONS} \"${t_user}@${t_host}:${t_remote_file}\" \"${t_local_file}\"
				return $?
			fi
		else
			echo "Trying with classic ftp"
		fi
	fi

	# Try with ftp
	type curl > /dev/null 2>&1
	if [ $? = 0 ]; then
		# curl does not support arobase in password : convert to html code %40
		t_password=$(echo "$t_password" | sed 's/@/%40/g')
		if [ -z "$t_timeout" ]
		then
			echo "lrr_DownloadFromRemote uses curl"
			lrr_Execute curl -o \"${t_local_file}\" ftp://${t_user}:\"${t_password}\"@${t_host}:${t_port}/\"${t_remote_file}\"
		else
			echo "lrr_DownloadFromRemote uses curl, $t_timeout seconds maximum to complete the command"
			lrr_ExecuteMaxTime $t_timeout curl -o \"${t_local_file}\" ftp://${t_user}:\"${t_password}\"@${t_host}:${t_port}/\"${t_remote_file}\"
		fi
		return $?
	fi
	type wget > /dev/null 2>&1
	if [ $? = 0 ]; then
		if	[ "$LRRSYSTEM" = "fcpico" ]; then
			echo "lrr_DownloadFromRemote uses wget (${LRRSYSTEM} specific)"
			# RDTP-6637 (specific to fcpico for now. Extend to other gateways is possible in future dev)
			lrr_Execute wget -t 3 -T 10 -O \"${t_local_file}\" ftp://${t_user}:\"${t_password}\"@${t_host}:${t_port}/\"${t_remote_file}\"
		else
			echo "lrr_DownloadFromRemote uses wget"
			lrr_Execute wget -O \"${t_local_file}\" ftp://${t_user}:\"${t_password}\"@${t_host}:${t_port}/\"${t_remote_file}\"
		fi
		return $?
	fi

	echo "no command found for ftp download"
	return $RET_FAILURE
}


#	lrr_UploadToRemote -u username -w password -l local_filename [-r remote_filename] -a host_address -p host_port [-s use_sftp]
#
#	This function is used to upload a file to a remote server using either FTP or SFTP protocol.
#
#	Arguments:
#		-u username			remote host user login. Must be always set, even in case of anonymous FTP
#		-w password			remote host user password. Can be omitted in case of anonymous FTP. Mandatory in case of SFTP
#		-l local_filename	local file name
#		-r remote_filename	remote file name. If omitted, use the same path as local filename
#		-a host_address		remote host address
#		-p host_port		remote host port
#		-s use_sftp			set to 1 to use sftp. If 0 or not set, use classic ftp.
#
#	Returns: RET_FAILURE or the value returned by the transfert command
#
lrr_UploadToRemote() {
	if	[ $# -lt 6 ] ; then
		echo "lrr_UploadToRemote wrapper not enough arg"
		return $RET_FAILURE
	fi

	_getArgs $*
	if [ $? -eq $RET_FAILURE ]; then
		return $RET_FAILURE
	fi

	# If asked, try with sftp
	if [ ! -z "${t_use_sftp}" ] && [ ${t_use_sftp} -eq 1 ]; then
		_checkUseSftp
		if [ $? -eq $RET_SUCCESS ]; then
			local tmp_sftp_batch_file=/tmp/sftp-batch-file
			echo "put ${t_local_file} ${t_remote_file}" > ${tmp_sftp_batch_file}

			if [ -z "${t_identity}" ]; then
				echo "lrr_UploadToRemote uses ${EXESFTP} -P ${t_port} ${SSH_OPTIONS} -b ${tmp_sftp_batch_file} \"${t_user}@${t_host}\" "
				lrr_Execute ${EXESSHPASS} -p \"${t_password}\" ${EXESFTP} -P ${t_port} ${SSH_OPTIONS} -b ${tmp_sftp_batch_file} \"${t_user}@${t_host}\"
				ret=$?
			else
				echo "lrr_UploadToRemote uses ${EXESFTP} -i ${t_identity} -P ${t_port} ${SSH_OPTIONS} -b ${tmp_sftp_batch_file} \"${t_user}@${t_host}\" "
				lrr_Execute ${EXESFTP} -i \"${t_identity}\" -P ${t_port} ${SSH_OPTIONS} -b ${tmp_sftp_batch_file} \"${t_user}@${t_host}\"
				ret=$?
			fi
			if [ $ret = 0 ]; then echo "End of transfer: Success using SFTP"; else echo "ERROR: the transfer failed ! Check address, user and password"; fi
			rm -f ${tmp_sftp_batch_file}
			return $ret
		else
			echo "Trying with classic ftp"
		fi
	fi

	# Try with ftp
	type curl > /dev/null 2>&1
	if [ $? = 0 ]; then
		$ROOTACT/lrr/com/ipvxchk.x -6 "${t_host}"
		if [ $? = "0" ]; then
			t_host="[${t_host}]"
			echo "brackets added to ipv6@ ${t_host}"
		fi
		echo "lrr_UploadToRemote uses curl"
		# curl does not support arobase in password : convert to html code %40
		t_password=$(echo "$t_password" | sed 's/@/%40/g')
		lrr_Execute curl -T \"${t_local_file}\" ftp://${t_user}:\"${t_password}\"@${t_host}:${t_port}/\"${t_remote_file}\"
		if [ $? = 0 ]; then echo "End of transfer: Success using curl"; else echo "ERROR: the transfer failed ! Check address, user and password"; fi
		return $?
	fi
	type ftpput > /dev/null 2>&1
	if [ $? = 0 ]; then
		echo "lrr_UploadToRemote uses ftpput"
		lrr_Execute ftpput -u ${t_user} -p \"${t_password}\" -P ${t_port} ${t_host} \"${t_remote_file}\" \"${t_local_file}\"
		if [ $? = 0 ]; then echo "End of transfer: Success using ftpput"; else echo "ERROR: the transfer failed ! Check address, user and password"; fi
		return $?
	fi

	echo "no command found for ftp upload"
	return $RET_FAILURE
}


lrr_CloseFiles()
{
	if [ "$SYSTEM" = "oielec" -o "$SYSTEM" = "natrbpi_usb_v1.0" -o "$SYSTEM" = "rbpi_v1.0" -o "$SYSTEM" = "sempico" ]; then
		return
	fi
	if [ "$SYSTEM" = "linux-x86_64" -o "$SYSTEM" = "linux-x86" ]; then
#       on ubuntu /bin/sh is /bin/dash eval exec $fd>&- is not supported
        return
    fi
	if [ "$SYSTEM" = "linux" ]; then
#       on ubuntu /bin/sh is /bin/dash eval exec $fd>&- is not supported
        return
    fi
	for fd in $(ls /proc/$$/fd); do
		case "$fd" in
			0|1|2)
#			echo "do not close $fd"
			;;
			*)
#			echo "closing $fd"
			eval "exec $fd>&-"
			;;
		esac
	done
}



#	check_config_key keyname inifile value
#
#	This function is use to retrieve a value from an lrr ini file
#	If the result of checking is not null, the value will we override and echoed
#
#	Arguments:
# 		keyname		the key to be checked
#		inifile		path of the file in which to check
#		value			use this value if checking result is null
#
#	Returns: echoes the result, so the caller can retrieve it
#
check_config_key () {
	REGEX='^\s*[^;]'${1}'='
	INIFILE=${2}
	RESULT=${3}
	FOUND=""
	[[ -f $INIFILE ]] && FOUND=$(grep  $REGEX $INIFILE | cut -d"="  -f2)
	[[ ! -z $FOUND ]] && RESULT=$FOUND
	echo $RESULT
}

# getIniConf()
#
# get configuration from .ini file and print the result
#
# $1: file name
# $2: section name. If present, a '/' in section is replaced with '.'
# $3: key name
# return 1 if key found, 0 if not found (to distinguish not set and empty)
#
# usage: res=$(getIniConf file.ini secname key)
getIniConf()
{
	gicfile="$1"
	gicsection="$2"
	gickey="$3"

	[ -z "$gicfile" -o -z "$gicsection" -o -z "$gickey" ] && return 0
	[ ! -f "$gicfile" ] && return 0

	gicsection=$(echo "$gicsection" | sed "s?/?\.?g")
	gicext=$(cat $gicfile | sed 's/;.*//' | sed -n "/^[ \t]*\[$gicsection\]/,/^\[/p" | awk "/^[ \t]*$gickey[ \t]*=/")
	if [ -z "$gicext" ]
	then
		return 0
	else
		echo "$gicext" | sed 's/[^=]*=//'
		return 1
	fi
}

# getGlobalIniConf()
#
# return the applicable value from all config files
#
# $1 : section name
# $2 : key name
#
# return 1 if key found, 0 if not found (to distinguish not set and empty
#
getGlobalIniConf() {
    # if not launched by shelllrr (service or manually) LRRSYSTEM is not set
    [ -z "$LRRSYSTEM" -a ! -z "$SYSTEM" ] && LRRSYSTEM="$SYSTEM"

    ggicsection="$1"
    ggickey="$2"

    lrr_list="$ROOTACT/usr/etc/lrr/lrr.ini ${ROOTACT}/lrr/config/lrr.ini"
    sec_list="${LRRSYSTEM}.${ggicsection} ${ggicsection}"

    for lrr_f in $lrr_list; do
        for sec_v in $sec_list; do
            ggicext=$(getIniConf "${lrr_f}" ${sec_v} ${ggickey})
            if [ $? -eq 1 ]; then
                echo "$ggicext"
                return 1
            fi
        done
    done
}


# getGlobalIniConf()
#
# return the applicable value from all config files
#
# $1 : file name
# $2 : section name
# $3 : key name
#
# return 1 if key found, 0 if not found (to distinguish not set and empty
#
getGlobalIniFileConf() {
    # if not launched by shelllrr (service or manually) LRRSYSTEM is not set
    [ -z "$LRRSYSTEM" -a ! -z "$SYSTEM" ] && LRRSYSTEM="$SYSTEM"

    ggicfile="$1"
    ggicsection="$2"
    ggickey="$3"

    lrr_list="$ROOTACT/usr/etc/lrr/${ggicfile} ${ROOTACT}/lrr/config/${ggicfile}"
    sec_list="${LRRSYSTEM}.${ggicsection} ${ggicsection}"

    for lrr_f in $lrr_list; do
        for sec_v in $sec_list; do
            ggicext=$(getIniConf "${lrr_f}" ${sec_v} ${ggickey})
            if [ $? -eq 1 ]; then
                echo "$ggicext"
                return 1
            fi
        done
    done
}


# getSystemIniConf()
#
# return the applicable value from all config files, including custom.ini
# and for all possible gateway information (system, firmware, family, manufacturer)
#
# $1: $section name
# $2: key name
# $3: default value
#
# no return value

getSystemIniConf() {

    # if not launched by shelllrr (service or manually) LRRSYSTEM is not set
    [ -z "$LRRSYSTEM" -a ! -z "$SYSTEM" ] && LRRSYSTEM="$SYSTEM"

    ggicsection="$1"
    ggickey="$2"
    ggiret="$3"

    lrr_list="$ROOTACT/usr/etc/lrr/custom.ini $ROOTACT/usr/etc/lrr/lrr.ini ${ROOTACT}/lrr/config/lrr.ini"
    sec_list="${LRRSYSTEM}.${ggicsection}"
    [ ! -z "${FIRMWARE}" ] && sec_list="${sec_list} ${FIRMWARE}.${ggicsection}"
    [ ! -z "${FAMILY}" ] && sec_list="${sec_list} ${FAMILY}.${ggicsection}"
    [ ! -z "${MANUFACTURER}" ] && sec_list="${sec_list} ${MANUFACTURER}.${ggicsection}"
    sec_list="${sec_list} ${ggicsection}"

    ggifound=0
    for lrr_f in $lrr_list; do
        for sec_v in $sec_list; do
            ggicext=$(getIniConf "${lrr_f}" ${sec_v} ${ggickey})
            if [ $? -eq 1 ]; then
                ggiret=${ggicext}
                ggifound=1
                break
            fi
        done
        [ "$ggifound" = 1 ] && break
    done

    echo "$ggiret"
}



# get_spidevice
#
# return the spidevice of a system
#
# $1: board number (optional, default: 0)
#
# result in SPIDEVICE (empty if not found)
#
get_spidevice() {

    board=$1
    if [ -z "$board" ]; then
        board=0
    fi

    # if not launched by shelllrr (service or manually) LRRSYSTEM is not set
    [ -z "$LRRSYSTEM" -a ! -z "$SYSTEM" ] && LRRSYSTEM="$SYSTEM"

    # Note:
    # likely to retrieve fcloc-specific spi device without managing the section, "device" was duplicated
    # as "spidevice" for fcloc (at least)
    # this function then looks first for "spidevice" as it was designed specifically for rfscanv1
    # and may be not equal to "device" in some configs (or "device" may be missing)
    # then look for "device" if "spidevice" is not present
    # and seen in [<system>/spidevice:0] or in [<system>] sections.
    lrr_list="$ROOTACT/usr/etc/lrr/lrr.ini ${ROOTACT}/lrr/config/lrr.ini"
    for lrr_f in $lrr_list; do
        SPIDEVICE=$(getIniConf "$lrr_f" "$LRRSYSTEM/spidevice:$board" "spidevice")
        if [ ! -z "$SPIDEVICE" ]; then
            return
        fi
        SPIDEVICE=$(getIniConf "$lrr_f" "$LRRSYSTEM" "spidevice")
        if [ ! -z "$SPIDEVICE" ]; then
            return
        fi
        SPIDEVICE=$(getIniConf "$lrr_f" "$LRRSYSTEM/spidevice:$board" "device")
        if [ ! -z "$SPIDEVICE" ]; then
            return
        fi
        SPIDEVICE=$(getIniConf "$lrr_f" "$LRRSYSTEM" "device")
        if [ ! -z "$SPIDEVICE" ]; then
            return
        fi
    done
}

# getServicePrefix()
#
# get service location from $SYSTEM
#
# return: set SERVICEPREFIX with the result
# for example for service 'toto' use '${SERVICEPREFIX}toto start' to start the service
# warning: do not add a '/' between ${SERVICEPREFIX} and the service name
#
getServicePrefix()
{
	shname="$1"
	srvname="$2"

	SYSTEM_ETC=/etc

	case $SYSTEM in
		wir*)
			if [ "$SYSTEM" = "wirmav2" ]; then
				SERVICEPREFIX="$SYSTEM_ETC/rc.d/rc3.d/S90"
			else
				SERVICEPREFIX="$SYSTEM_ETC/rcU.d/S90"
			fi
		;;

		ciscoms)
			SERVICEPREFIX="$SYSTEM_ETC/init.d/S90"
		;;

		*)
			SERVICEPREFIX="$SYSTEM_ETC/init.d/"
		;;

	esac

}

# check if migration to NFR920 is requested
# return 1 if migration is requested, return 0 if not
isNFR920MigrationRequested()
{
	inmlrrini="$ROOTACT/usr/etc/lrr/lrr.ini"
	[ ! -z "$1" ] && inmlrrini="$1"
	inmlrrinidef="$ROOTACT/lrr/config/lrr.ini"
	inmtpe=$(getIniConf $inmlrrini suplog networkconfigtpe)
	[ $? -eq 0 ] && inmtpe=$(getIniConf $inmlrrinidef $SYSTEM.suplog networkconfigtpe)
	inmnfr920=$(getIniConf $inmlrrini suplog nfr920)
	[ $? -eq 0 ] && inmnfr920=$(getIniConf $inmlrrinidef $SYSTEM.suplog nfr920)
	inmmigration=$(getIniConf $inmlrrini suplog migrate2nfr920)
	[ $? -eq 0 ] &&  inmmigration=$(getIniConf $inmlrrinidef $SYSTEM.suplog migrate2nfr920)
#	echo "tpe=$inmtpe nfr920=$inmnfr920 mig=$inmmigration"
	[ "$inmtpe" != "1" -o "$inmnfr920" == "1" -o "$inmmigration" != "1" ] && return 0

	return 1
}

