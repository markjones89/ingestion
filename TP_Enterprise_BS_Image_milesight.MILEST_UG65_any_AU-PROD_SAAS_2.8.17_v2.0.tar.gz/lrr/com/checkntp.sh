#!/bin/sh

# Copyright (C) Actility, SA. All Rights Reserved.
# DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License version
# 2 only, as published by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License version 2 for more details (a copy is
# included at /legal/license.txt).
#
# You should have received a copy of the GNU General Public License
# version 2 along with this work; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
# 02110-1301 USA
#
# Please contact Actility, SA.,  4, rue Ampere 22300 LANNION FRANCE
# or visit www.actility.com if you need additional
# information or have any questions.

. $ROOTACT/lrr/com/system_setting.sh
. $ROOTACT/lrr/com/system_api.sh

. ${ROOTACT}/lrr/com/_parameters.sh
. $ROOTACT/lrr/com/_functions.sh
. ${INIT_PROF}

PATH=/sbin:/usr/sbin:/bin:/usr/bin:$PATH

CHECK_PERIOD_KO_SEC=60
CHECK_PERIOD_OK_SEC=600

do_ntp_restart()
{
    ${NTP_SERVICE} stop
    ntpdate -s $NTP_SERVERS
    ${NTP_SERVICE} start
}

check_ntpq()
{
    ACTIVE_SERVER_COUNT=$(ntpq -p | grep -vE '^(\s+remote|=====)' | grep -v LOCAL | wc -l)
    if [ "$ACTIVE_SERVER_COUNT" -eq 0 ]; then
        do_ntp_restart
        return 1
    else
        return 0
    fi
}

# If not active (lrr.ini:[services].checkntp=1) just do nothing
# A checkntp restart is required to reread configuration
# note: can be disabled for LRR into a container with [<reference>/services].checkntp=0
active=$(getSystemIniConf "services" "checkntp" 1) 

if [ "$active" != "1" ]
then
	echo "checkntp unactivated, doing nothing ..."
	while true
	do
		sleep 3600
	done
	exit 1
fi

while true; do
    sleep $CHECK_PERIOD_OK_SEC
    #NTP_SERVERS=$(grep -E '^server' /etc/ntp.conf | grep -v '127.127.' | sed 's/  */ /g' | cut -d' ' -f2 | tr '\n' ' ')
    #if [ ! -z "$NTP_SERVERS" ]; then
    #    if check_ntpq; then
    #        sleep $CHECK_PERIOD_OK_SEC
    #    else
    #        sleep $CHECK_PERIOD_KO_SEC
    #    fi
    #fi
done
