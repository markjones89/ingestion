#!/bin/sh
#

### BEGIN INIT INFO
# Provides:        lrrplan
# Required-Start:  $network $remote_fs $syslog
# Required-Stop:   $network $remote_fs $syslog
# Default-Start:   2 3 4 5
# Default-Stop:	   0 6
# Short-Description: Start the lrrplan.sh
### END INIT INFO

# lrrplan:       Starts the lrrplan.sh

exec 2> /dev/null

ROOTACT=_REPLACEWITHROOTACT_
export ROOTACT

setting=$ROOTACT/lrr/com/system_setting.sh
if [ -f $setting ]; then
    . $setting setrootact
fi

# here ROOTACT is available for all scripts
# all system definitions are defined if related files are present (new mechanism)

CURRENT_DIR=`dirname $0`
. $ROOTACT/lrr/com/functionsservice.sh

OPTIONS=""
LRRPLAN_DATA=$ROOTACT/usr/data/lrr/lrrplan
SERVICE="lrrplan"
SERVICE_RUNDIR="$ROOTACT/lrr/com"
PIDFILE=$LRRPLAN_DATA/lrrplan.pid
STOPFILE=$LRRPLAN_DATA/stop

usage() {
    echo "Usage: lrrplan [<options>] {start|stop|status|restart}"
    echo "  Where options are:"
    echo "   -h|--help    Print this help message"
}

preStart() {
	export PATH=.:$PATH:/usr/local/bin

	mkdir -p $LRRPLAN_DATA
	mkdir -p $ROOTACT/usr/etc/lrr > /dev/null 2>&1
}

serviceCommand() {
	echo "lrrplan.sh "$OPTIONS
}

stopService() {
	opt=""
	LRRPLAN_PIDS="$(pidof lrrplan.sh)"
	LRRPLAN_PIDS="$LRRPLAN_PIDS $(pidof -x lrrplan.sh)"
	[ -n "$LRRPLAN_PIDS" ] && kill -TERM $LRRPLAN_PIDS
}

abortService() {
	LRRPLAN_PIDS="$(pidof lrrplan.sh)"
	LRRPLAN_PIDS="$LRRPLAN_PIDS $(pidof -x lrrplan.sh)"
	[ -n "$LRRPLAN_PIDS" ] && kill -KILL $LRRPLAN_PIDS
}

[ -f "$ROOTACT/usr/etc/lrr/_parameters.sh" ] && . $ROOTACT/usr/etc/lrr/_parameters.sh

# getopt is not present on major gw
getopt_present=$(which getopt)
if [ ! -z "$getopt_present" ]
then
	GETOPTTEMP=`getopt -o a:hi --long help,init -- $@`
	if [ $? != 0 ] ; then usage >&2 ; exit 1 ; fi
	eval set -- "$GETOPTTEMP"

	# Read the arguments
	while [ -n "$1" ]
	do
	    case "$1" in
		"-a") shift; OPTIONS=$OPTIONS" -a "$1;;
		"-h"|"--help") usage; exit;;
		"-i"|"--init") OPTIONS=$OPTIONS" -i";;
		"--") shift; break ;;
		* ) echo "Internal error ($*)!"; exit 1;;
	    esac
	    shift
	done
fi

handleParams $*

exit $?

