#!/bin/sh
# $1 is the day of the week [1..7]

. /var/run/lrrsystem ""

# default for unknown gateways to support temporary old mechanismm
BACKUPFS=/home
if [ "$FIRMWARE" = "keros" ]; then
	if [ "$SYSTEM" = "wirmav2" ]; then
		BACKUPFS=/mnt/mmcblk0p1
	else
		BACKUPFS=/user
	fi
fi

. $ROOTACT/lrr/com/system_setting.sh

if [ ! -z "$TRACE_BACKUP_DIR" ]; then
    # contains full path
    BACKUPDIR=$TRACE_BACKUP_DIR
else
    BACKUPDIR=${BACKUPFS}/actility/traces
fi

if      [ $# = "0" ]
then         
	exit 1
fi

cd $ROOTACT/var/log/lrr

if	[ ! -d ${BACKUPFS} ]
then
	rm TRACE_0?.log
	exit 0
fi

if	[ ! -d ${BACKUPDIR} ]
then
	mkdir -p ${BACKUPDIR}
fi

[ -f ifacefailover.log.backup ] && mv ifacefailover.log.backup ${BACKUPDIR}

# do not backup the traces of the day
for f in 1 2 3 4 5 6 7
do
	if	[ $f != "${1}" ]
	then
		tr=TRACE_0${f}.log
		if	[ -f ${tr} ]
		then
			echo "mv $tr ${BACKUPDIR}"
			mv $tr ${BACKUPDIR}
		fi
	fi
done


exit 0
