#!/bin/sh

##
## @file
## @author Actility
## @copyright Actility SA
## @brief getid.sh returns IDs of the gateway
##
## @details
## 2 possible arguments:
## @li -o: returns OUI (manufacturer ID)
## @li -u: returns UUID (gateway unique ID)
## @li -l: returns LRRID (gateway ID computed locally)
##
## If the script is not adapted to the gateway, its default behavior is:
## - OUI extracts from lrr/system/system_definition.sh: MANUFACTURER_OUI
## - LRRID and UUID computed from MAC address of eth0
##
## @note All returned information are in uppercase
##
## @ingroup system
##

# ===================================
#
# Get Cisco lrrID functions
#
#
get_sn() {

    CISCOSN=$(getsn)
    return
}

check_format() {
    # must be LLLDDDDAAAA
    check=$(echo $CISCOSN | grep -E '^[A-Z]{3}[0-9]{4}[A-Z0-9]{4}$')
    if [ "${check}" = "" ]; then
        echo "$CISCOSN is not a valid CISCOSN"
        exit 1
    fi
}

ord() {
  printf '%d' "'$1"
}

get_c() {
    # extract from $1, length $2
    C=${CISCOSN:${1}:${2}}
}

get_ord() {
    get_c $1 1
    C=$(ord $C)
}

get_alnum() {
    get_c $1 1
    if [ "$C" -eq "$C" ] 2>/dev/null
    then
        val=$C
    else
        val=$(ord $C)
        val=$(( $val - $A + 10 ))
    fi
    C=$val
}

csn_code() {
    # keep L % 4
    A=$(ord 'A')
    zero=$(ord '0')

    get_ord 0
    c0=$(( ($C - $A) % 4))
    get_ord 1
    c1=$(( ($C - $A) % 4))
    get_ord 2
    c2=$(( ($C - $A) % 4))
    lll=$(( ($c0 * 16) + ($c1 * 4) + $c2))
    lll=$(( $lll *3 * 26 * 18 * 36 * 36 * 36 ))

    # keep YY %3
    get_c 3 2
    # PT-1243: remove leading zero (interpreted as base 8 otherwise)
    C=$((10#${C}))
    yy=$(( $C % 3 ))
    yy=$(( $yy * 26 * 18 * 36 * 36 * 36 ))

    # keep WW % 26
    get_c 5 2
    # PT-1243: remove leading zero (interpreted as base 8 otherwise)
    C=$((10#${C}))
    ww=$(( ($C - 1) % 26 ))
    ww=$(( $ww * 18 * 36 * 36 * 36 ))


    get_alnum 7
    c7=$C
    v7=$(( ($c7 % 18) * 36 * 36 * 36 ))
    get_alnum 8
    c8=$C
    v8=$(( $c8 * 36 * 36 ))
    get_alnum 9
    c9=$C
    v9=$(( $c9 * 36 ))
    get_alnum 10
    c10=$C
    v10=$c10
    ssss=$(( $v7 + $v8 + $v9 + $v10 ))

    res=$(( $lll + $yy + $ww + $ssss ))
    if [ $LOWER -eq 1 ]; then
        RES=$(printf "%08x\n" "$res")
    else
        RES=$(printf "%08X\n" "$res")
    fi

}

#
# compute ID from MAC address
#
# 1: interface name
#
# return value into "macid"
#
getUidFromMac() {

    macid=$(ifconfig $1 | grep HWaddr | awk '{ print $5 }' | sed 's/://g' | tr '[A-Z]' '[a-z]')
}

#
# MAIN
#


while	[ $# -gt 0 ]
do
	case	$1 in 
		-o)
			shift
			MODE="oui"
		;;
		-u)
			shift
			MODE="uid"
		;;
		-l)
			shift
			MODE="lrrid"
		;;
		*)
			shift
		;;
	esac
done

. $ROOTACT/lrr/com/system_setting.sh


oui='uniden'
uid='unidentified'
lrrid="unknown"

# use defined one, avoid superseding it for gateway using new config mechanism
if [ ! -z "$MANUFACTURER_OUI" ]; then
   oui=$MANUFACTURER_OUI
fi

case	$SYSTEM in
	natrbpi)
	;;
	fcmlb|fcloc|fcpico)
		oui='001558'
		uid=$(nvram get bs_id)
        lrrid=$uid
	;;
	ciscoms)
		LOWER=1
		oui='005f86'
		get_sn
		check_format
		csn_code
		lrrid=$RES
		uid=024b0$lrrid
	;;
	mtac*|mtcap|mtcdt*)
		uid=$(mts-io-sysfs show device-id)
        getUidFromMac eth0
        lrrid=$macid
	;;
	flexpico)
		oui='000900'
        getUidFromMac eth0
        uid=$macid
        lrrid=$macid
        ;;
	oielec)
		oui='d84a87' #waiting for oielec confirmation
        getUidFromMac eth0
        uid=$macid
        lrrid=$macid
	;;
	linux*)
		oui='0016C0'
		uid=$($ROOTACT/lrr/com/lrr.x --stpicoid)
        lrrid=$uid
        ;;
	tek*)
		oui='647FDA'
        getUidFromMac eth0
        uid=$macid
        lrrid=$macid
        ;;
    tracknet*)
        if [ ! -z "$(uname -a | grep -i TabsHub)" ]; then
            oui='58a0cb'
        else
            oui='1c497b'
        fi
        getUidFromMac eth0
        uid=$macid
        lrrid=$macid
        ;;

    *)
        # default is MAC address of eth0: to be made more flexible
        getUidFromMac eth0
        uid=$macid
        lrrid=$macid
        ;;

esac

# New requirement: results must now be in uppercase
oui=$(echo $oui | tr '[a-z]' '[A-Z]')
uid=$(echo $uid | tr '[a-z]' '[A-Z]')
if [ "$SYSTEM" = "ciscoms" ]; then
    # already a 8-char string
    lrrid=$(echo $lrrid | tr '[a-z]' '[A-Z]')
else
    # use a portable way to retrieve last 8 characters from a 12-characters string
    lrrid=$(echo $lrrid | tr '[a-z]' '[A-Z]' | cut -b 5-12)
fi

# Verbose off when used from sysconfiglrr.sh to set LRRUID in _parameters.sh
if [ "$MODE" = "oui" ]
then
	echo "$oui"
elif [ "$MODE" = "uid" ]
then
	echo "$uid"
elif [ "$MODE" = "lrrid" ]
then
    echo "$lrrid"
else
	echo "Vendor oui:'$oui' Gateway uid:'$uid' Gateway lrrid:'$lrrid'"
fi
