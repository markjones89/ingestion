#!/bin/sh
# vim: ft=sh: set et ts=4 sw=4 sts=4:
#

DNSCONF_FILE=/etc/resolv.conf

UBUS_GET_TMP=/tmp/_ubus_get_tmp

# wifi config
DOT11_STATUS_CONN=33

# static config
STATIC_CONFIG_FILE=$ROOTACT/usr/data/lrr/gwmgr/static_config
ETH_STATUE_UP=10

QUAGGA_TIMEZONE_LIST_FILE=/www/view/timezone.json

LOG_FILE=""

LOG_TEMP_FILE=/tmp/mlog

msg_debug () {
    [ ! -z "$DEBUG" ] && echo "$*"
}

#1:error
#2:warn
#3:info
#4:debug
print_log () {
    loglvl=$1
    shift
    case "$loglvl" in
        "1")    loglvl="ERROR"  ;;
        "2")    loglvl="WARN"   ;;
        "3")    loglvl="INFO"   ;;
        "4")    loglvl="DEBUG"  ;;
        *)  loglvl="NONE"   ;;
    esac
    if [ -n "$LOG_FILE" -a -f $LOG_FILE ]; then
        echo "${loglvl} ${*}" >> $LOG_FILE
    else
        echo "${loglvl} ${*}"
    fi
}

# For logging multi lines
print_log_m () {
    if [ ! -z $1 ]; then
        lvl=$1
    else
        lvl=2
    fi
    if [ -f $LOG_TEMP_FILE ]; then
        while read logline; do
            print_log $lvl "$logline"
        done < $LOG_TEMP_FILE
    fi
}

ubus_call_get () {
    object=$1
    basename=$2
    if [ "$basename""x" = "x" ];then
            ubus call $object get {} > $UBUS_GET_TMP
    else
            ubus call $object get '{"base":"'$basename'"}' > $UBUS_GET_TMP
    fi
}

get_netif_current_dns () {
    [ -z "$1" ] && print_log 1 "No interface name passed" && return 1
    if [ $NETIF_ACTIVATION -eq 1 ]; then
        if [ "$1" = "eth0" ]; then
            if [ "$NETIF_TYPE" = "ethernet" ]; then
                NETIF_DNS=$(cat $DNSCONF_FILE  | tr '\n' ' ' | sed 's/nameserver //g' | sed 's/  #/#/g' | tr '#' '\n' | grep Ethernet | sed 's/ For Ethernet//g')
            else
                NETIF_DNS=$(cat $DNSCONF_FILE  | tr '\n' ' ' | sed 's/nameserver //g' | sed 's/  #/#/g' | tr '#' '\n' | grep PPPoE | sed 's/ For PPPoE//g')
            fi
        elif [ "$1" = "cellular0" ]; then
            NETIF_DNS=$(cat $DNSCONF_FILE  | tr '\n' ' ' | sed 's/nameserver //g' | sed 's/  #/#/g' | tr '#' '\n' | grep Cellular | sed 's/ For Cellular//g')
        elif [ "$1" = "wlan0" ]; then
            NETIF_DNS=$(cat $DNSCONF_FILE  | tr '\n' ' ' | sed 's/nameserver //g' | sed 's/  #/#/g' | tr '#' '\n' | grep WLAN | sed 's/ For WLAN//g')
        fi
    fi
}

get_eth_status_by_ubus () {
    ubus_call_get yruo_status yruo_status_network
    NETIF_STATE=$(cat $UBUS_GET_TMP | grep \"status\" | grep -oE  "[0-9]*")
    if [ "$NETIF_STATE" = "$ETH_STATUE_UP" ];then
        NETIF_STATE=1
    else
        NETIF_STATE=0
    fi
    NETIF_DHCP=$(cat $UBUS_GET_TMP | grep \"type\" | grep -oE  "[0-9]*")
    if [ "$NETIF_DHCP" = "0" ];then
        NETIF_DHCP="0"
    elif [ "$NETIF_DHCP" = "2" ];then
        NETIF_TYPE="pppoe"
        NETIF_DHCP="1"
    else
        NETIF_DHCP="1"
    fi
    NETIF_ADDR=$(cat $UBUS_GET_TMP | grep \"ip\" | awk -F\" '{printf $4}')
    NETIF_NETMASK=$(cat $UBUS_GET_TMP | grep \"netmask\" | awk -F\" '{printf $4}')
    NETIF_BROADCAST=$(ifconfig $NETIF_NAME 2> /dev/null | grep "inet addr" | awk -F " " '{print $3}' | cut -d":" -f2)
    NETIF_GATEWAY=$(cat $UBUS_GET_TMP | grep \"gate\" | awk -F\" '{printf $4}')
}

get_netif_eth () {
    NETIF_NAME="$DEFAULT_ETH_NETIF_NAME"
    NETIF_TYPE="ethernet"
    NETIF_ACTIVATION=1
    get_eth_status_by_ubus
    get_netif_current_dns ${NETIF_NAME}
}

get_wifi_status_by_ubus () {
    ubus_call_get yruo_wifi_status
    NETIF_ACTIVATION=$(cat $UBUS_GET_TMP | grep \"enabled\" | grep -oE  "[0-9]*")
    if [ "$NETIF_ACTIVATION" = "1" ]; then
        NETIF_ACTIVATION=$(cat $UBUS_GET_TMP | grep \"mode\" | grep -oE  "[0-9]*")
    fi
    NETIF_STATE=$(cat $UBUS_GET_TMP | grep \"status\": | grep -oE  "[0-9]*")
    if [ "$NETIF_STATE" = "$DOT11_STATUS_CONN" ]; then
        NETIF_STATE=1
    else
        NETIF_STATE=0
    fi
    NETIF_ADDR=$(cat $UBUS_GET_TMP | grep \"ip\" | awk -F\" '{printf $4}')
    NETIF_NETMASK=$(cat $UBUS_GET_TMP | grep \"mask\" | awk -F\" '{printf $4}')
    NETIF_BROADCAST=$(ifconfig $NETIF_NAME 2> /dev/null | grep "inet addr" | awk -F " " '{print $3}' | cut -d":" -f2)
    NETIF_GATEWAY=$(cat $UBUS_GET_TMP | grep \"gate\" | awk -F\" '{printf $4}')
    ubus_call_get yruo_wifi
    NETIF_DHCP=$(cat $UBUS_GET_TMP | grep \"proto_sta\" | grep -oE  "[0-9]*")
    if [ "$NETIF_DHCP" = "1" ]; then
        NETIF_DHCP=0
    else
        NETIF_DHCP=1
    fi
}

get_netif_wlan() {

    NETIF_NAME="$DEFAULT_WLAN_NETIF_NAME"
    NETIF_TYPE="wifi"
    get_wifi_status_by_ubus
    get_netif_current_dns ${NETIF_NAME}
}

get_cellular_status_by_ubus () {
    ubus_call_get yruo_status yruo_celluar
    CELLULAR_MODEM_STATUS=$(cat $UBUS_GET_TMP | grep \"modem_status\" | awk -F\" '{printf $4}')
    if [ "$CELLULAR_MODEM_STATUS" = "Disabled" ] || [ "$CELLULAR_MODEM_STATUS" = "-" ];then
        NETIF_ACTIVATION=0
    else
        NETIF_ACTIVATION=1
    fi
    NETIF_STATE=$(cat $UBUS_GET_TMP | grep \"status\" | awk -F\" '{printf $4}')
    if [ "$NETIF_STATE" = "Connected" ];then
        NETIF_STATE=1
    else
        NETIF_STATE=0
    fi
    NETIF_ADDR=$(cat $UBUS_GET_TMP | grep \"ip\" | awk -F\" '{printf $4}')
    NETIF_NETMASK=$(cat $UBUS_GET_TMP | grep \"netmask\" | awk -F\" '{printf $4}')
    NETIF_BROADCAST=$(ifconfig cellular0 2> /dev/null | grep "inet addr" | awk -F " " '{print $3}' | cut -d":" -f2)
    NETIF_GATEWAY=$(cat $UBUS_GET_TMP | grep \"gate\" | awk -F\" '{printf $4}')
}

get_netif_cellular () {
    NETIF_NAME="$DEFAULT_PPP_NETIF_NAME"
    NETIF_TYPE="cellular"
    get_cellular_status_by_ubus
    NETIF_DHCP=1
    get_netif_current_dns ${NETIF_NAME}
}

ubus_call_apply () {
    ubus call yruo_apply apply '{}'
}

set_netif_eth () {
    # Interface name can't be updated
    if [ "$NETIF_NAME" != "$DEFAULT_ETH_NETIF_NAME" ]; then
        print_log 1 "Wrong interface name: $NETIF_NAME"
        return 1
    fi
    if [ "$NETIF_TYPE" = "pppoe" ]; then
        print_log 2 "LRR no support pppoe"
        return 1
    fi

    #save to set,get now,compare diff
    NETIF_DHCP_SET=$NETIF_DHCP
    NETIF_ADDR_SET=$NETIF_ADDR
    NETIF_NETMASK_SET=$NETIF_NETMASK
    NETIF_BROADCAST_SET=$NETIF_BROADCAST
    NETIF_GATEWAY_SET=$NETIF_GATEWAY
    NETIF_DNS_SET=$NETIF_DNS

    get_netif_eth
    print_log 4 "set_netif_eth:$NETIF_DHCP_SET $NETIF_DHCP $NETIF_ADDR_SET $NETIF_ADDR $NETIF_NETMASK_SET $NETIF_NETMASK $NETIF_BROADCAST_SET $NETIF_BROADCAST $NETIF_GATEWAY_SET $NETIF_GATEWAY $NETIF_DNS_SET $NETIF_DNS"
    cmd_start_line="ubus call yruo_wan set '{\"base\":\"yruo_wan\",\"index\":\"lrrset\",\"value\":{"
    cmd_end_line="}}'"
    cmd="$cmd_start_line"
    if [ $NETIF_DHCP_SET -eq 1 ] && [ $NETIF_DHCP -eq 0 ]; then
        cmd="$cmd""\"protocol\":1,\"port\":\"eth 0\""
    elif [ $NETIF_DHCP_SET -eq 0 ]; then
        # Force return if static configuration is invalid
        if [ -z "${NETIF_ADDR_SET}" ] || [ -z "${NETIF_NETMASK_SET}" ] || [ -z "${NETIF_GATEWAY_SET}" ]; then
            print_log 1 "Invalid static configuration, interface name: $NETIF_NAME"
            return 1
        fi
        cmd="$cmd""\"protocol\":0,\"ip_address\":\"$NETIF_ADDR_SET\",\"netmask\":\"$NETIF_NETMASK_SET\",\"gateway\":\"$NETIF_GATEWAY_SET\""
        # deal DNS
        PRIDNS=$(echo $NETIF_DNS_SET | cut -d' ' -f1)
        SECDNS=$(echo $NETIF_DNS_SET | cut -d' ' -f2)
        cmd="$cmd"",\"pri_dns\":\"$PRIDNS\",\"sec_dns\":\"$SECDNS\",\"port\":\"eth 0\""
    fi
    if [ "$cmd" != "$cmd_start_line" ]; then
        cmd="$cmd""$cmd_end_line"
        print_log 3 "eval $cmd"
        eval $cmd
        ubus_call_apply
    else
        return 1
    fi
    #save static configuration to ${STATIC_CONFIG_FILE}.${NETIF_NAME}
    if [ $NETIF_DHCP_SET -eq 0 ]; then
        cp /dev/null ${STATIC_CONFIG_FILE}.${NETIF_NAME}
        echo "ETHIPADDR=$NETIF_ADDR_SET" >> ${STATIC_CONFIG_FILE}.${NETIF_NAME}
        echo "ETHNETMASK=$NETIF_NETMASK_SET" >> ${STATIC_CONFIG_FILE}.${NETIF_NAME}
        echo "ETHBROADCAST=$NETIF_BROADCAST_SET" >> ${STATIC_CONFIG_FILE}.${NETIF_NAME}
        echo "ETHGATEWAY=$NETIF_GATEWAY_SET" >> ${STATIC_CONFIG_FILE}.${NETIF_NAME}
        TMP_DNS=$(echo $NETIF_DNS_SET | cut -d' ' -f1) && echo "DNSSERVER1=$TMP_DNS" >> ${STATIC_CONFIG_FILE}.${NETIF_NAME}
        TMP_DNS=$(echo $NETIF_DNS_SET | cut -d' ' -f2) && echo "DNSSERVER2=$TMP_DNS" >> ${STATIC_CONFIG_FILE}.${NETIF_NAME}
    fi
}

set_netif_wlan() {
    #save to set,get now,compare diff
    NETIF_ACTIVATION_SET=$NETIF_ACTIVATION
    NETIF_DHCP_SET=$NETIF_DHCP
    NETIF_ADDR_SET=$NETIF_ADDR
    NETIF_NETMASK_SET=$NETIF_NETMASK
    NETIF_BROADCAST_SET=$NETIF_BROADCAST
    NETIF_GATEWAY_SET=$NETIF_GATEWAY
    NETIF_DNS_SET=$NETIF_DNS

    get_netif_wlan

    print_log 4 "set_netif_wlan: $NETIF_DHCP_SET $NETIF_DHCP $NETIF_ADDR_SET $NETIF_ADDR $NETIF_NETMASK_SET $NETIF_NETMASK $NETIF_BROADCAST_SET $NETIF_BROADCAST $NETIF_GATEWAY_SET $NETIF_GATEWAY $NETIF_DNS_SET $NETIF_DNS" 
    cmd_start_line="ubus call yruo_wifi set '{\"base\":\"yruo_wifi\",\"index\":0,\"value\":{\"mode\":1"
    cmd_end_line="}}'"
    cmd="$cmd_start_line"
    if [ "$NETIF_ACTIVATION_SET" -eq 0 ] && [ "$NETIF_ACTIVATION" -eq 1 ]; then
        cmd="$cmd"",\"enabled\":0"
    elif [ "$NETIF_ACTIVATION_SET" -eq 1 ]; then
        cmd="$cmd"",\"enabled\":1"
        if [ $NETIF_DHCP_SET -eq 1 ] && [ $NETIF_DHCP -eq 0 ]; then
            cmd="$cmd"",\"proto_sta\":2"
        elif [ $NETIF_DHCP_SET -eq 0 ]; then
            # Force return if static configuration is invalid
            if [ -z "${NETIF_ADDR_SET}" ] || [ -z "${NETIF_NETMASK_SET}" ] || [ -z "${NETIF_GATEWAY_SET}" ]; then
                print_log 1 "Invalid static configuration, interface name: $NETIF_NAME"
                return 1
            fi
            cmd="$cmd"",\"proto_sta\":1,\"ip_sta\":\"$NETIF_ADDR_SET\",\"mask\":\"$NETIF_NETMASK_SET\",\"gate\":\"$NETIF_GATEWAY_SET\""
            # deal DNS
            PRIDNS=$(echo $NETIF_DNS_SET | cut -d' ' -f1)
            SECDNS=$(echo $NETIF_DNS_SET | cut -d' ' -f2)
            cmd="$cmd"",\"pri_dns\":\"$PRIDNS\",\"sec_dns\":\"$SECDNS\""
        fi
    fi
    if [ "$cmd" != "$cmd_start_line" ]; then
        cmd="$cmd""$cmd_end_line"
        print_log 3 "eval $cmd"
        eval $cmd
        ubus_call_apply
    fi
    #save static configuration to ${STATIC_CONFIG_FILE}.${NETIF_NAME}
    if [ $NETIF_DHCP_SET -eq 0 ]; then
        cp /dev/null ${STATIC_CONFIG_FILE}.${NETIF_NAME}
        echo "ETHIPADDR=$NETIF_ADDR_SET" >> ${STATIC_CONFIG_FILE}.${NETIF_NAME}
        echo "ETHNETMASK=$NETIF_NETMASK_SET" >> ${STATIC_CONFIG_FILE}.${NETIF_NAME}
        echo "ETHBROADCAST=$NETIF_BROADCAST_SET" >> ${STATIC_CONFIG_FILE}.${NETIF_NAME}
        echo "ETHGATEWAY=$NETIF_GATEWAY_SET" >> ${STATIC_CONFIG_FILE}.${NETIF_NAME}
        TMP_DNS=$(echo $NETIF_DNS_SET | cut -d' ' -f1) && echo "DNSSERVER1=$TMP_DNS" >> ${STATIC_CONFIG_FILE}.${NETIF_NAME}
        TMP_DNS=$(echo $NETIF_DNS_SET | cut -d' ' -f2) && echo "DNSSERVER2=$TMP_DNS" >> ${STATIC_CONFIG_FILE}.${NETIF_NAME}
    fi
}

set_netif_cellular () {
    # Interface name can't be updated
    if [ "$NETIF_NAME" != "$DEFAULT_PPP_NETIF_NAME" ]; then
        echo "Wrong interface name: $NETIF_NAME"
        return 1
    fi

    if [ -z "$NETIF_ACTIVATION" ]; then
        print_log 3 "activation no change"
        return
    fi
    # set every times
    cmd="ubus call yruo_cell set '{\"base\":\"yruo_cell\",\"index\":0,\"value\":{\"enable1\":$NETIF_ACTIVATION}}'"
    print_log 3 "eval $cmd"
    eval $cmd
    ubus_call_apply

    [ "$NETIF_DHCP" = "0" ] && print_log 2 "$NETIF_NAME can only use DHCP configuration"
}

reconfig_eth () {
    # user for deal with broadcast when use static ip
    # must wait quagga deal with done
    if [ -n "$NETIF_DHCP_SET" ]; then
        #sleep 2s to wait set
        sleep 2
    fi
    get_netif_eth
    if [ "$NETIF_DHCP" -eq 1 ]; then
        return
    fi
    [ -z "$NETIF_BROADCAST_SET" ] && NETIF_BROADCAST_SET=$(cat ${STATIC_CONFIG_FILE}.${NETIF_NAME} | grep ETHBROADCAST | cut -d"=" -f2)
    if [ "$NETIF_STATE" -eq 1 ]; then
        if [ "$NETIF_BROADCAST_SET" != "$NETIF_BROADCAST" ]; then
            print_log 4 "reconfig_eth:change broadcast add $NETIF_BROADCAST to $NETIF_BROADCAST_SET"
            ifconfig ${NETIF_NAME} broadcast ${NETIF_BROADCAST_SET}
        fi
    fi
}

reconfig_cellular () {
    RECONFIG_CELLULAR=0
    #get cellular status until 50s or up
    if [ $NETIF_ACTIVATION -eq 1 ]; then
        done=0
        count=20
        maxloop=50
        [ -z "$CELLULAR_MODEM_STATUS" ] && get_netif_cellular
        #if cellular no connect,sleep 20s wait quagga deal with cellular up
        if [ $NETIF_STATE -eq 0 ]; then
            if [ "$CELLULAR_MODEM_STATUS" != "No SIM Card" ]; then
                print_log 3 "sleep $count wait quagga deal down"
                sleep $count
            else
                print_log 3 "no sim card,return"
                return
            fi
        else
            count=0
        fi
        while [ "$done" = 0 ]; do
            get_netif_cellular
            if [ $NETIF_STATE -eq 1 ]; then
                done=1
            else
                if [ $count -lt $maxloop ]; then
                    count=$(($count + 2))
                    sleep 2
                else
                    print_log 1 "Error: $NETIF_NAME interface not visible after $maxloop seconds,cellular modem $CELLULAR_MODEM_STATUS"
                    return
                fi
            fi
        done
    fi
}

get_ntp_by_ubus () {
    ubus_call_get yruo_system time
    ntp_type=$(cat $UBUS_GET_TMP | grep \"set_type\" | grep -oE  "[0-9]*")
    if [ "$ntp_type" = "0" ]; then
        NTP_SERVERS=$(cat $UBUS_GET_TMP | grep \"ntp_address\" | awk -F\" '{printf $4}')
    fi
}

get_ntp () {
    NTP_SERVERS=""
    get_ntp_by_ubus
}

set_ntp () {
    NTP_SERVERS=$(echo ${NTP_SERVERS-NoSet})
    if [ "$NTP_SERVERS" = "NoSet" ]; then
        return 1
    fi
    if [ -z "$NTP_SERVERS" ]; then
        print_log 1 "Ntp server can't be empty"
        return 1
    fi
    #Only the first 
    ntp1=$(echo $NTP_SERVERS| awk -F " " '{print $1}')
    cmd="ubus call yruo_system set '{\"base\":\"time\",\"index\":0,\"value\":{\"set_type\":0,\"ntp_enable\":1,\"ntp_address\":\"$ntp1\"}}'"
    print_log 3 "eval $cmd"
    eval $cmd
    ubus_call_apply
}

get_timezone () {
    ubus_call_get yruo_system time
    TIME_GW_TZ=$(cat $UBUS_GET_TMP | grep \"timezone\" | awk -F\" '{printf $4}' | sed 's/\\//g')
    TIME_GW_TZ=$(cat $QUAGGA_TIMEZONE_LIST_FILE | tr '\n' ' ' | tr '{' '\n' | grep "$TIME_GW_TZ" | cut -d'"' -f8)
}

set_timezone () {
    TIME_GW_TZ=$(echo ${TIME_GW_TZ-NoSet})
    if [ "$TIME_GW_TZ" = "NoSet" ]; then
        return 1
    fi
    if [ -z "$TIME_GW_TZ" ]; then
        print_log 1 "Time zone can't be empty"
        return 1
    fi
    TIME_GW_TZ=$(cat $QUAGGA_TIMEZONE_LIST_FILE | tr '\n' ' ' | tr '{' '\n' | grep "$TIME_GW_TZ" | cut -d'"' -f4)
    if [ -z "$TIME_GW_TZ" ]; then
        print_log 1 "Time zone is illegal"
        return 1
    fi
    cmd="ubus call yruo_system set '{\"base\":\"time\",\"index\":0,\"value\":{\"set_type\":0,\"timezone\":\"$TIME_GW_TZ\"}}'"
    print_log 3 "eval $cmd"
    eval $cmd
    ubus_call_apply
}

get_cellular_info_by_ubus () {
    ubus_call_get yruo_cell
    APN_ADDR=$(cat $UBUS_GET_TMP | grep \"apn1\" | awk -F\" '{printf $4}')
    APN_PIN=$(cat $UBUS_GET_TMP | grep \"pin1\" | awk -F\" '{printf $4}')
    APN_USER=$(cat $UBUS_GET_TMP | grep \"user1\" | awk -F\" '{printf $4}')
    APN_PASSWORD=$(cat $UBUS_GET_TMP | grep \"password1\" | awk -F\" '{printf $4}')
}

get_cellular () {
    APN_AUTOCONF=0
    APN_ADDR=""
    APN_USER=""
    APN_PASSWORD=""

    APN_AVAILABLE=1

    get_cellular_info_by_ubus
}

set_cellular () {
    APN_ADDR=$(echo ${APN_ADDR-NoSet})
    if [ "$APN_ADDR" = "NoSet" ]; then
        return 1
    fi
    #save to set,get now,compare diff
    APN_ADDR_SET=$APN_ADDR
    APN_USER_SET=$APN_USER
    APN_PASSWORD_SET=$APN_PASSWORD
    APN_PIN_SET=$APN_PIN

    get_cellular
    cmd_start_line="ubus call yruo_cell set '{\"base\":\"yruo_cell\",\"index\":0,\"value\":{"
    cmd_end_line="}}'"
    cmd="$cmd_start_line"
    if [ "$APN_ADDR_SET" != "$APN_ADDR" ]; then
        print_log 3 "Cellular change apn $APN_ADDR to $APN_ADDR_SET"
        if [ "$cmd" = "$cmd_start_line" ]; then
            cmd="$cmd""\"apn1\":\"$APN_ADDR_SET\""
        else
            cmd="$cmd"",\"apn1\":\"$APN_ADDR_SET\""
        fi
    fi
    if [ "$APN_USER_SET" != "$APN_USER" ]; then
        print_log 3 "Cellular change user $APN_USER to $APN_USER_SET"
        if [ "$cmd" = "$cmd_start_line" ]; then
            cmd="$cmd""\"user1\":\"$APN_USER_SET\""
        else
            cmd="$cmd"",\"user1\":\"$APN_USER_SET\""
        fi
    fi
    if [ "$APN_PASSWORD_SET" != "$APN_PASSWORD" ]; then
        print_log 3 "Cellular change password $APN_PASSWORD to $APN_PASSWORD_SET"
        if [ "$cmd" = "$cmd_start_line" ]; then
            cmd="$cmd""\"password1\":\"$APN_PASSWORD_SET\""
        else
            cmd="$cmd"",\"password1\":\"$APN_PASSWORD_SET\""
        fi
    fi
    if [ "$APN_PIN_SET" != "$APN_PIN" ]; then
        print_log 3 "Cellular change pin $APN_PIN to $APN_PIN_SET"
        if [ "$cmd" = "$cmd_start_line" ]; then
            cmd="$cmd""\"pin1\":\"$APN_PIN_SET\""
        else
            cmd="$cmd"",\"pin1\":\"$APN_PIN_SET\""
        fi
    fi
    if [ "$cmd" != "$cmd_start_line" ]; then
        cmd="$cmd""$cmd_end_line"
        print_log 3 "eval $cmd"
        eval $cmd
        ubus_call_apply
    else
        return 1
    fi
}

get_wifi_info_by_ubus () {
    ubus_call_get yruo_wifi
    WIFI_SSID=$(cat $UBUS_GET_TMP | grep \"ssid_sta\" | awk -F\" '{printf $4}')
    WIFI_SECURITY=$(cat $UBUS_GET_TMP | grep \"encryption\" | grep -oE  "[0-9]*")
    WIFI_KEY=$(cat $UBUS_GET_TMP | grep \"key\" | awk -F\" '{printf $4}')
    if [ "$WIFI_SECURITY" = "0" ]; then
        WIFI_SECURITY="no encryption"
        WIFI_KEY=""
    elif [ "$WIFI_SECURITY" = "1" ] || [ "$WIFI_SECURITY" = "2" ]; then
        WIFI_SECURITY="wep"
        WIFI_KEY=$(cat $UBUS_GET_TMP | grep \"key0\" | awk -F\" '{printf $4}')
    elif [ "$WIFI_SECURITY" = "3" ]; then
        WIFI_SECURITY="wpa"
    elif [ "$WIFI_SECURITY" = "4" ]; then
        WIFI_SECURITY="wpa"
    elif [ "$WIFI_SECURITY" = "5" ]; then
        WIFI_SECURITY="wpa2/wpa"
    else
        WIFI_SECURITY="other"
        WIFI_KEY=""
    fi
}

get_wifi () {
    WIFI_AVAILABLE=1
    get_wifi_info_by_ubus
}

set_wifi() {
    WIFI_SSID=$(echo ${WIFI_SSID-NoSet})
    if [ "$WIFI_SSID" = "NoSet" ]; then
        return 1
    fi
    if [ -z "$WIFI_SSID" ] && [ -z "$WIFI_SECURITY" ]; then
        print_log 1 "No valid parameters to set wifi configuration"
        return 1
    fi
    if [ "$WIFI_SECURITY" = "other" ]; then
        print_log 2 "LRR no support set wifi configuration security is other,only use for display quagga set"
        return 1
    fi
    #save to set,get now,compare diff
    WIFI_SSID_SET=$WIFI_SSID
    WIFI_SECURITY_SET=$WIFI_SECURITY
    WIFI_KEY_SET=$WIFI_KEY

    get_wifi
    cmd_start_line="ubus call yruo_wifi set '{\"base\":\"yruo_wifi\",\"index\":0,\"value\":{\"mode\":1"
    cmd_end_line="}}'"
    cmd="$cmd_start_line"
    if [ "$WIFI_SSID_SET" != "$WIFI_SSID" ]; then
        print_log 3 "Wi-Fi change ssid $WIFI_SSID_SET to $WIFI_SSID"
        cmd="$cmd"",\"bssid_sta\":\"\",\"ssid_sta\":\"$WIFI_SSID_SET\""
    fi
    if [ "$WIFI_SECURITY_SET" != "$WIFI_SECURITY" ]; then
        print_log 3 "Wi-Fi change security $WIFI_SECURITY to $WIFI_SECURITY_SET"
        if [ "$WIFI_SECURITY_SET" = "no encryption" ]; then
            cmd="$cmd"",\"encryption\":0"",\"key\":\"\""
        elif [ "$WIFI_SECURITY_SET" = "wep" ]; then
            cmd="$cmd"",\"encryption\":2"",\"key0\":\"$WIFI_KEY_SET\""
        elif [ "$WIFI_SECURITY_SET" = "wpa" ]; then
            cmd="$cmd"",\"encryption\":3"",\"key\":\"$WIFI_KEY_SET\""
        elif [ "$WIFI_SECURITY_SET" = "wpa2" ]; then
            cmd="$cmd"",\"encryption\":4"",\"key\":\"$WIFI_KEY_SET\""
        elif [ "$WIFI_SECURITY_SET" = "wpa2/wpa" ]; then
            cmd="$cmd"",\"encryption\":5"",\"key\":\"$WIFI_KEY_SET\""
        else
            print_log 2 "LRR no support set wifi configuration security is other,only use for display quagga set"
            return 1
        fi
    elif [ "$WIFI_KEY_SET" != "$WIFI_KEY" ]; then
        print_log 3 "Wi-Fi change key $WIFI_KEY to $WIFI_KEY_SET"
        if [ "$WIFI_SECURITY_SET" = "no encryption" ]; then
            cmd="$cmd"",\"key\":\"\""
        elif [ "$WIFI_SECURITY_SET" = "wep" ]; then
            cmd="$cmd"",\"key0\":\"$WIFI_KEY_SET\""
        else
            cmd="$cmd"",\"key\":\"$WIFI_KEY_SET\""
        fi
    fi
    if [ "$cmd" != "$cmd_start_line" ]; then
        cmd="$cmd""$cmd_end_line"
        print_log 4 "eval $cmd"
        eval $cmd
        ubus_call_apply
    else
        return 1
    fi
}

reconfig_wlan() {
    RECONFIG_WLAN=0
    # user for deal with broadcast when use static ip
    # must wait quagga deal with done
    if [ -n "$NETIF_ACTIVATION_SET" ] && [ "$NETIF_ACTIVATION_SET" -eq 0 ]; then
        return
    fi
    if [ -n "$NETIF_DHCP_SET" ]; then
        #sleep 10s to wait connect
        sleep 10s
    fi
    get_netif_wlan
    if [ "$NETIF_DHCP" -eq 1 ]; then
        return
    fi
    [ -z "$NETIF_BROADCAST_SET" ] && NETIF_BROADCAST_SET=$(cat ${STATIC_CONFIG_FILE}.${NETIF_NAME} | grep ETHBROADCAST | cut -d"=" -f2)
    if [ "$NETIF_STATE" -eq 1 ]; then
        if [ "$NETIF_BROADCAST_SET" != "$NETIF_BROADCAST" ]; then
            print_log 4 "reconfig_wlan:change broadcast $NETIF_BROADCAST to $NETIF_BROADCAST_SET"
            ifconfig ${NETIF_NAME} broadcast ${NETIF_BROADCAST_SET}
        fi
    fi
}

get_conf () {
    reset_netif
    get_netif_eth
    output_netif

    reset_netif
    get_netif_cellular
    output_netif

    reset_netif
    get_netif_wlan
    output_netif

    reset_ntp
    get_ntp
    output_ntp

    reset_timezone
    get_timezone
    output_timezone

    reset_cellular
    get_cellular
    output_cellular

    reset_wifi
    get_wifi
    output_wifi
}

set_netif_generic () {
    [ -z "$1" ] && print_log 1 "No interface number" && return 1
    reset_netif
    wrap_netif_num $1
    case "$NETIF_NAME" in
        "$DEFAULT_ETH_NETIF_NAME")
            set_netif_eth
            reconfig_eth
            ;;
        "$DEFAULT_WLAN_NETIF_NAME")
            set_netif_wlan
            reconfig_wlan
            ;;
        "$DEFAULT_PPP_NETIF_NAME")
            set_netif_cellular
            reconfig_cellular
            ;;
        *)
            print_log 2 "Cannot find interface $NETIF_NAME do not exists"
            ;;
    esac
}

set_conf () {
    reset_all

    if [ -f $SCRIPT_PARAMS_FILE ]; then
        . $SCRIPT_PARAMS_FILE
    else
        print_log 1 "Unable to source $SCRIPT_PARAMS_FILE"
        return 1
    fi
    cat $SCRIPT_PARAMS_FILE > $LOG_TEMP_FILE
    print_log_m 4

    RECONFIG_CELLULAR=0
    set_cellular && RECONFIG_CELLULAR=1
    RECONFIG_WLAN=0
    set_wifi && RECONFIG_WLAN=1

    # PT-1675: the script doesn't receive all the configuration but only
    # changes, so do not recreate network configuration file if no
    # interface definition is received
    if [ ${NETIF_NB_TOTAL} -gt 0 ]
    then
        # Note: set network interface after setting cellular configuration
        print_log 3 "Found ${NETIF_NB_TOTAL} network interface to configure"
        for i in $(seq 0 $(expr ${NETIF_NB_TOTAL} - 1)); do
            set_netif_generic $i
        done
    fi
    # If cellular parameters updated, force cellular reconfiguration
    [ $RECONFIG_CELLULAR -eq 1 ] && get_netif_cellular && reconfig_cellular
    # If WiFi parameters updated, force wlan reconfiguration
    [ $RECONFIG_WLAN -eq 1 ] && get_netif_wlan && reconfig_wlan

    set_timezone
    set_ntp

    if [ $REBOOT_NEEDED -eq 1 ]; then
        print_log 3 "Reboot needed, cause: $REBOOT_CAUSE"
    fi
}


netconfig() {
    [ -z "$ROOTACT" ] && echo "Error: No ROOTACT env var defined"
    . $ROOTACT/lrr/gwmgr/scripts/common.sh > /dev/null 2>&1
    [ $? -ne 0 ] && echo "Error: sourcing common.sh" && exit 1

    [ -z "$SYSTEM" ] && print_log 1 "Error: No SYSTEM env var defined"

    case "$1" in
        "-get" ) get_conf  ;;
        "-set" ) set_conf  ;;
        "*"    ) print_log 1 "ERROR: unknown script argument ($1)" ;;
    esac

    exit 0
}

netconfig $@

exit 0
