##
## @file
## @author Actility
## @copyright Actility SA
## @brief generic function for cellular modem management
##
## @ingroup cellular
##

CELLULAR_INI=$ROOTACT/usr/etc/lrr/cellular.ini

CF=/etc/ppp/chap-secrets
PF=/etc/ppp/pap-secrets

#
# LOCAL FUNCTIONS
# 


##
## @fn celint_get_apn_username_password
## @brief internal function retrieving user and password from authentication files
##
## @retval APN_USER and APN_PASSWORD set with preconfigured value (empty otherwise)
##

celint_get_apn_username_password(){

    # look for non-commented line and extract info
    user_chap=$(cat $CF | grep -v "#" | awk '{print $1}')
    [ "$user_chap" = "*" ] && user_chap=""
    user_pap=$(cat $PF | grep -v "#" | awk '{print $1}')
    [ "$user_pap" = "*" ] && user_pap=""

    password_chap=$(cat $CF | grep -v "#" | awk '{print $3}')
    [ "$password_chap" = "*" ] && password_chap=""
    password_pap=$(cat $PF | grep -v "#" | awk '{print $3}')
    [ "$password_pap" = "*" ] && password_pap=""

    if [ "$user_chap" = "$user_pap" ]; then
        APN_USER=$user_pap
    fi
    if [ "$password_chap" = "$password_pap" ]; then
        APN_PASSWORD=$password_pap
    fi
}



##
## @fn celint_import_config
## @brief internal function creation cellular.ini if it does not exist, by importing current pppd configuration
##
## Uses /etc/ppp/peers/<modem>_chat, /etc/ppp/pap-secrets and /etc/ppp/chap-secrets
##
##

celint_import_config() {

    if [ -f "$CELLULAR_INI" ]; then
        return
    fi

    USE_PPP_TEMPLATE=0
    if [ -f "$ROOTACT/usr/etc/lrr/peers/${CELLULAR}" ] && [ -f "$ROOTACT/usr/etc/lrr/peers/${CELLULAR}_chat" ]; then
        CELLULAR_TEMPLATE="$ROOTACT/usr/etc/lrr/peers/${CELLULAR}"
        CELLULAR_CHAT_TEMPLATE="$ROOTACT/usr/etc/lrr/peers/${CELLULAR}_chat"
        USE_PPP_TEMPLATE=1
    else
        SystemGetFilePath "$ROOTACT/lrr/gwmgr/scripts" "${CELLULAR}" "noroot"
        [ ! -z "$sysfilepath" ] && CELLULAR_TEMPLATE=$sysfilepath
        SystemGetFilePath "$ROOTACT/lrr/gwmgr/scripts" "${CELLULAR}_chat" "noroot"
        [ ! -z "$sysfilepath" ] && CELLULAR_CHAT_TEMPLATE=$sysfilepath
        [ ! -z "$CELLULAR_TEMPLATE" ] && [ ! -z "$CELLULAR_CHAT_TEMPLATE" ] && USE_PPP_TEMPLATE=1
    fi

    if [ "$USE_PPP_TEMPLATE" -eq 1 ]; then
        mkdir -p /etc/ppp/peers
        cp "$CELLULAR_TEMPLATE" /etc/ppp/peers/
        cp "$CELLULAR_CHAT_TEMPLATE" /etc/ppp/peers/
    fi

    if [ "$FIRMWARE" = "mlinux" ]; then
        APN_ADDR=$(cat ${cellular_chat} | grep "^#MT.*CGDCONT=" | cut -d "," -f 3 | tr -d '"' | head -n 1 | sed s/\'//)
    else
        APN_ADDR=$(cat ${cellular_chat} | grep "AT.*CGDCONT=" | cut -d "," -f 3 | tr -d '"' | head -n 1 | sed s/\'//)
    fi

    APN_USER=""
    APN_PASSWORD=""
    celint_get_apn_username_password
    APN_PIN=$(grep "^OK.*CPIN=" ${cellular_chat} | cut -d"'" -f2 | cut -d'=' -f2)

    echo "LTE_APN=${APN_ADDR}" > $CELLULAR_INI
    echo "LTE_USER=${APN_USER}" >> $CELLULAR_INI
    echo "LTE_PASSWORD=${APN_PASSWORD}" >> $CELLULAR_INI
    echo "LTE_PIN=${APN_PIN}" >> $CELLULAR_INI
    chown support:support $CELLULAR_INI
}

#
# GLOBAL FUNCTIONS
#

##
## @fn cellular_load_config
## @brief load cellular.ini variables. Created it from configuration if needed
##
## @param cellular name of cellular modem, used to create conf file names
##
## @retval APN_ADDR, APN_USER, APN_PASSWORD, APN_PIN
##

cellular_load_config() {

    cellular=$1
    cellular_pppd=/etc/ppp/peers/${cellular}
    cellular_chat=/etc/ppp/peers/${cellular}_chat

    if [  -f $CELLULAR_INI ]; then
        APN_ADDR=$(grep LTE_APN $CELLULAR_INI | cut -f2 -d'=')
        APN_USER=$(grep LTE_USER $CELLULAR_INI | cut -f2 -d'=')
        APN_PASSWORD=$(grep LTE_PASSWORD $CELLULAR_INI | cut -f2 -d'=')
        APN_PIN=$(grep LTE_PIN $CELLULAR_INI | cut -f2 -d'=')
    else
        celint_import_config 
    fi
}

##
## @fn cellular_write_config
## @brief write configuration into cellular.ini
##
## @li use APN_ADDR, APN_USER, APN_PASSWORD and APN_PIN set by caller
## @li update cellular.ini
##

cellular_write_config() {

    echo "LTE_APN=${APN_ADDR}" > $ROOTACT/usr/etc/lrr/cellular.ini
    echo "LTE_USER=${APN_USER}" >> $ROOTACT/usr/etc/lrr/cellular.ini
    echo "LTE_PASSWORD=${APN_PASSWORD}" >> $ROOTACT/usr/etc/lrr/cellular.ini
    echo "LTE_PIN=${APN_PIN}" >> $ROOTACT/usr/etc/lrr/cellular.ini
}

##
## @fn cellular_unlock_sim
## @brief Send "unlock SIM" command to cellular modem
##
## @li use APN_PIN as input
## @li requires "[cellular] cellularmgt" for the system to be defined into configuration files
##
## @brief Send "unlock SIM" command to cellular modem
##
## @li use APN_PIN as input
## @li requires "[cellular] cellularmgt" for the system to be defined into configuration files
##
## @warning the script doesn't return any error code: accept OK or ERROR (happens when SIM is already unlocked)
##
##

cellular_unlock_sim() {

    # TODO: make it configurable
    [ -f "$ROOTACT/usr/etc/lrr/peers/ppp_device" ] && cellulardev=$(cat "$ROOTACT/usr/etc/lrr/peers/ppp_device")
    if [ -z "$cellulardev" ]; then
	SystemGetFilePath "$ROOTACT/lrr/gwmgr/scripts" "ppp_device" "noroot"
        if [ ! -z "$sysfilepath" ]; then
            cellulardev=$(cat "$sysfilepath")
        else
            cellulardev=/dev/ttyUSB3
        fi
    fi
    chat -V -s "" "AT+CPIN=$APN_PIN" "O" "" > $cellulardev <$cellulardev
}

##
## @fn cellular_configure_apn
## @brief configure APN carrier into pppd configuration file
##
## @li use APN_ADDR as input
## @li use APN_PDP_CONTEXT as input, set it to 1 if not defined
##
## @param cellular name of cellular modem to be used
##

cellular_configure_apn() {

    cellular_chat=$1

    USE_PPP_TEMPLATE=0
    if [ -f "$ROOTACT/usr/etc/lrr/peers/${CELLULAR}" ] && [ -f "$ROOTACT/usr/etc/lrr/peers/${CELLULAR}_chat" ]; then
        CELLULAR_TEMPLATE="$ROOTACT/usr/etc/lrr/peers/${CELLULAR}"
        CELLULAR_CHAT_TEMPLATE="$ROOTACT/usr/etc/lrr/peers/${CELLULAR}_chat"
        USE_PPP_TEMPLATE=1
    else
        SystemGetFilePath "$ROOTACT/lrr/gwmgr/scripts" "${CELLULAR}" "noroot"
        [ ! -z "$sysfilepath" ] && CELLULAR_TEMPLATE=$sysfilepath
        SystemGetFilePath "$ROOTACT/lrr/gwmgr/scripts" "${CELLULAR}_chat" "noroot"
        [ ! -z "$sysfilepath" ] && CELLULAR_CHAT_TEMPLATE=$sysfilepath
        [ ! -z "$CELLULAR_TEMPLATE" ] && [ ! -z "$CELLULAR_CHAT_TEMPLATE" ] && USE_PPP_TEMPLATE=1
    fi

    if [ "$USE_PPP_TEMPLATE" -eq 1 ]; then
        mkdir -p /etc/ppp/peers
        cp "$CELLULAR_TEMPLATE" /etc/ppp/peers/
        cp "$CELLULAR_CHAT_TEMPLATE" /etc/ppp/peers/
        [ -z "$APN_PDP_CONTEXT" ] && APN_PDP_CONTEXT=1
        sed -i "s/%APN%/${APN_ADDR}/g" /etc/ppp/peers/${CELLULAR}_chat
        sed -i "s/%PDPCONTEXT%/${APN_PDP_CONTEXT}/g" /etc/ppp/peers/${CELLULAR}_chat
    else
        if [ "$FIRMARE" = "mlinux" ]; then
            mlinux-set-apn $APN_ADDR
            return
        fi

        # set APN and CPIN definition
        if [ -z "$APN_PDP_CONTEXT" ]; then
            APN_PDP_CONTEXT=1
        fi
        sed -i "/AT+CGDCONT/ s/^.*/OK 'AT+CGDCONT=${APN_PDP_CONTEXT},\"IP\",\"${APN_ADDR}\"'/"  $cellular_chat
        sed -i "/ATD/ s/^.*/OK 'ATD*99***${APN_PDP_CONTEXT}#'/" $cellular_chat
    fi 
}

##
## @fn cellular_configure_user_password
## @brief configure APN user and password into chap-secrets and pap-secrets
##
## @li use APN_USER and APN_PASSWORD as input
## @li update chap-secrets and pap-secrets
##

cellular_configure_user_password() {

    tmp=/tmp/file.$$

    # chap-secrets: remove existing definition (keep only comments)
    grep "^#" $CF > $tmp
    mv $tmp $CF

    # pap-secrets: remove existing definition (keep only comments)
    grep "^#" $PF > $tmp
    mv $tmp $PF

    if [ ! -z "$APN_USER" ] || [ ! -z "$APN_PASSWORD" ]; then
        user=$APN_USER
        password=$APN_PASSWORD
        if [ -z "$APN_USER" ]; then
            user="*"
        fi
        if [ -z "$APN_PASSWORD" ]; then
            passwd="\"\""
        fi
        echo -e "${user}\t*\t${password}\t*" >> $CF
        echo -e "${user}\t*\t${password}\t*" >> $PF
    fi
}
