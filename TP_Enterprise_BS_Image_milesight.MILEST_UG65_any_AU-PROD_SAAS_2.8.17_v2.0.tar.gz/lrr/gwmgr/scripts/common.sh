#!/bin/sh
# vim: ft=sh: set et ts=4 sw=4 sts=4:
#
# This the common functions and routines used by gateway-dependant API scripts
# Do not modify this file with gateway-specific functions, as it impacts all the gateways
#

. $ROOTACT/lrr/com/_functions.sh

# system binaries
BIN_IP=$(which ip)
BIN_IFCONFIG=$(which ifconfig)
BIN_WPA_PASSPHRASE=$(which wpa_passphrase)
BIN_WPA_SUPPLICANT=$(which wpa_supplicant)
BIN_ROUTE=$(which route)
# system configuration files
RESOLVCONF_FILE=/etc/resolv.conf
NTPCONF_FILE=/etc/ntp.conf
WPA_CONFIG_FILE=/etc/wpa_supplicant.conf
WVDIAL_CONFIG_FILE=/etc/wvdial.conf
TZ_DIR_PATH=/usr/share/zoneinfo
TZ_DIR_PATH_ACTILITY=$ROOTACT/usr/etc/zoneinfo
LOCALTIME_CONFIG_FILE=/etc/localtime
# default interfaces names
DEFAULT_ETH_NETIF_NAME="eth0"
DEFAULT_WLAN_NETIF_NAME="wlan0"
DEFAULT_PPP_NETIF_NAME="cellular0"
# gwmgr's files and common variables
NETIF_ACTIV_STATUS_FILE=$ROOTACT/usr/data/lrr/gwmgr/netif_activ
SCRIPT_PARAMS_FILE=$ROOTACT/usr/data/lrr/gwmgr/script_set_params
MLOG_FILE=/tmp/mlog
REBOOT_NEEDED=0
REBOOT_CAUSE="unknown"

msg_debug () {
    [ ! -z "$DEBUG" ] && echo "$*"
}

msg_log () {
    loglvl=$1
    shift
    echo "MSG_LOG=${loglvl}${*}"
}

# For logging multi lines
msg_log_m () {
    if [ ! -z $1 ]; then
        lvl=$1
    else
        lvl=2
    fi
    if [ -f $MLOG_FILE ]; then
        while read logline; do
            msg_log $lvl "$logline"
        done < $MLOG_FILE
    fi
}

netmask2cidr () {
    msg_log 6 "Convert $1 to cidr prefix"
    [ -z "$1" ] && return 24
    ret=$1
    [ "$ret" = "$1" ] && ret=$(echo "$1" | sed -e 's/128.0.0.0/1/g')
    [ "$ret" = "$1" ] && ret=$(echo "$1" | sed -e 's/192.0.0.0/2/g')
    [ "$ret" = "$1" ] && ret=$(echo "$1" | sed -e 's/224.0.0.0/3/g')
    [ "$ret" = "$1" ] && ret=$(echo "$1" | sed -e 's/240.0.0.0/3/g')
    [ "$ret" = "$1" ] && ret=$(echo "$1" | sed -e 's/248.0.0.0/5/g')
    [ "$ret" = "$1" ] && ret=$(echo "$1" | sed -e 's/252.0.0.0/6/g')
    [ "$ret" = "$1" ] && ret=$(echo "$1" | sed -e 's/254.0.0.0/7/g')
    [ "$ret" = "$1" ] && ret=$(echo "$1" | sed -e 's/255.0.0.0/8/g')

    [ "$ret" = "$1" ] && ret=$(echo "$1" | sed -e 's/255.128.0.0/9/g')
    [ "$ret" = "$1" ] && ret=$(echo "$1" | sed -e 's/255.192.0.0/10/g')
    [ "$ret" = "$1" ] && ret=$(echo "$1" | sed -e 's/255.224.0.0/11/g')
    [ "$ret" = "$1" ] && ret=$(echo "$1" | sed -e 's/255.240.0.0/12/g')
    [ "$ret" = "$1" ] && ret=$(echo "$1" | sed -e 's/255.248.0.0/13/g')
    [ "$ret" = "$1" ] && ret=$(echo "$1" | sed -e 's/255.252.0.0/14/g')
    [ "$ret" = "$1" ] && ret=$(echo "$1" | sed -e 's/255.254.0.0/15/g')
    [ "$ret" = "$1" ] && ret=$(echo "$1" | sed -e 's/255.255.0.0/16/g')

    [ "$ret" = "$1" ] && ret=$(echo "$1" | sed -e 's/255.255.128.0/17/g')
    [ "$ret" = "$1" ] && ret=$(echo "$1" | sed -e 's/255.255.192.0/18/g')
    [ "$ret" = "$1" ] && ret=$(echo "$1" | sed -e 's/255.255.224.0/19/g')
    [ "$ret" = "$1" ] && ret=$(echo "$1" | sed -e 's/255.255.240.0/20/g')
    [ "$ret" = "$1" ] && ret=$(echo "$1" | sed -e 's/255.255.248.0/21/g')
    [ "$ret" = "$1" ] && ret=$(echo "$1" | sed -e 's/255.255.252.0/22/g')
    [ "$ret" = "$1" ] && ret=$(echo "$1" | sed -e 's/255.255.254.0/23/g')
    [ "$ret" = "$1" ] && ret=$(echo "$1" | sed -e 's/255.255.255.0/24/g')

    [ "$ret" = "$1" ] && ret=$(echo "$1" | sed -e 's/255.255.255.128/25/g')
    [ "$ret" = "$1" ] && ret=$(echo "$1" | sed -e 's/255.255.255.192/26/g')
    [ "$ret" = "$1" ] && ret=$(echo "$1" | sed -e 's/255.255.255.224/27/g')
    [ "$ret" = "$1" ] && ret=$(echo "$1" | sed -e 's/255.255.255.240/28/g')
    [ "$ret" = "$1" ] && ret=$(echo "$1" | sed -e 's/255.255.255.248/29/g')
    [ "$ret" = "$1" ] && ret=$(echo "$1" | sed -e 's/255.255.255.252/30/g')
    [ "$ret" = "$1" ] && ret=$(echo "$1" | sed -e 's/255.255.255.254/31/g')
    [ "$ret" = "$1" ] && ret=$(echo "$1" | sed -e 's/255.255.255.255/32/g')
    [ "$ret" = "$1" ] && ret=24
    msg_log 6 "cidr prefix found: $ret"
    return $ret
}

cidr2netmask () {
    CIDR2NETMASK_RESULT=""
    [ -z "$1" ] && return 0
    [ "$1" = "32" ] && CIDR2NETMASK_RESULT="255.255.255.255" && return 0
    [ "$1" = "31" ] && CIDR2NETMASK_RESULT="255.255.255.254" && return 0
    [ "$1" = "30" ] && CIDR2NETMASK_RESULT="255.255.255.252" && return 0
    [ "$1" = "29" ] && CIDR2NETMASK_RESULT="255.255.255.248" && return 0
    [ "$1" = "28" ] && CIDR2NETMASK_RESULT="255.255.255.240" && return 0
    [ "$1" = "27" ] && CIDR2NETMASK_RESULT="255.255.255.224" && return 0
    [ "$1" = "26" ] && CIDR2NETMASK_RESULT="255.255.255.192" && return 0
    [ "$1" = "25" ] && CIDR2NETMASK_RESULT="255.255.255.128" && return 0

    [ "$1" = "24" ] && CIDR2NETMASK_RESULT="255.255.255.0" && return 0
    [ "$1" = "23" ] && CIDR2NETMASK_RESULT="255.255.254.0" && return 0
    [ "$1" = "22" ] && CIDR2NETMASK_RESULT="255.255.252.0" && return 0
    [ "$1" = "21" ] && CIDR2NETMASK_RESULT="255.255.248.0" && return 0
    [ "$1" = "20" ] && CIDR2NETMASK_RESULT="255.255.240.0" && return 0
    [ "$1" = "19" ] && CIDR2NETMASK_RESULT="255.255.224.0" && return 0
    [ "$1" = "18" ] && CIDR2NETMASK_RESULT="255.255.192.0" && return 0
    [ "$1" = "17" ] && CIDR2NETMASK_RESULT="255.255.128.0" && return 0

    [ "$1" = "16" ] && CIDR2NETMASK_RESULT="255.255.0.0" && return 0
    [ "$1" = "15" ] && CIDR2NETMASK_RESULT="255.254.0.0" && return 0
    [ "$1" = "14" ] && CIDR2NETMASK_RESULT="255.252.0.0" && return 0
    [ "$1" = "13" ] && CIDR2NETMASK_RESULT="255.248.0.0" && return 0
    [ "$1" = "12" ] && CIDR2NETMASK_RESULT="255.240.0.0" && return 0
    [ "$1" = "11" ] && CIDR2NETMASK_RESULT="255.224.0.0" && return 0
    [ "$1" = "10" ] && CIDR2NETMASK_RESULT="255.192.0.0" && return 0
    [ "$1" = "9" ]  && CIDR2NETMASK_RESULT="255.128.0.0" && return 0

    [ "$1" = "8" ] && CIDR2NETMASK_RESULT="255.0.0.0" && return 0
    [ "$1" = "7" ] && CIDR2NETMASK_RESULT="254.0.0.0" && return 0
    [ "$1" = "6" ] && CIDR2NETMASK_RESULT="252.0.0.0" && return 0
    [ "$1" = "5" ] && CIDR2NETMASK_RESULT="248.0.0.0" && return 0
    [ "$1" = "4" ] && CIDR2NETMASK_RESULT="240.0.0.0" && return 0
    [ "$1" = "3" ] && CIDR2NETMASK_RESULT="224.0.0.0" && return 0
    [ "$1" = "2" ] && CIDR2NETMASK_RESULT="192.0.0.0" && return 0
    [ "$1" = "1" ] && CIDR2NETMASK_RESULT="128.0.0.0" && return 0
}

set_netif_activ_status () {
    # $1 is the netif name
    # $2 is the value to set (0|1)
    [ -z $1 ] && msg_log 2 "No netif name given" && return
    [ -z $2 ] && msg_log 2 "No activation value given" && return

    if [ ! -f $NETIF_ACTIV_STATUS_FILE ]; then
        echo "$1=$2" > $NETIF_ACTIV_STATUS_FILE
    else
        grep $1 $NETIF_ACTIV_STATUS_FILE > /dev/null 2>&1
        if [ $? -eq 0 ]; then
            sed -i -e "s/$1=[0-9]/$1=$2/g" $NETIF_ACTIV_STATUS_FILE
        else
            echo "$1=$2" >> $NETIF_ACTIV_STATUS_FILE
        fi
    fi

}

get_netif_activ_status () {
    # $1 is the netif name (mandatory)
    # $2 is the default activation value (0 if not given)
    [ -z $1 ] && msg_log 2 "No netif name given" && return 0
    if [ -z $2 ]; then
         ACTIV_STATUS_DEFAULT=0
    else
         ACTIV_STATUS_DEFAULT=$2
    fi

    grep $1 $NETIF_ACTIV_STATUS_FILE > /dev/null 2>&1
    if [ $? -eq 0 ]; then
        st=$(grep $1 $NETIF_ACTIV_STATUS_FILE | awk -F "=" '{print $2}')
        return $st
    else
        set_netif_activ_status $1 $ACTIV_STATUS_DEFAULT
        return $ACTIV_STATUS_DEFAULT
    fi
}

get_netif_current_state () {
    [ -z "$1" ] && msg_log 1 "No interface name passed" && return 1
    CURRIF="$1"
    if [ -e /sys/class/net/${CURRIF} ]; then
        OPERSTATE=$(cat /sys/class/net/${CURRIF}/operstate)
        [ "$OPERSTATE" = "up" ] && return 1
        [ "$OPERSTATE" = "down" ] && return 0
    fi
    if [ ! -z $BIN_IP ]; then
        FLAGS=$(${BIN_IP} link show ${CURRIF} 2>/dev/null | grep ${CURRIF} | awk -F '<' '{print $2}' | awk -F '>' '{print $1}')
    elif [ ! -z $BIN_IFCONFIG ]; then
        FLAGS=$(${BIN_IFCONFIG} ${CURRIF} | grep ${CURRIF} | awk -F '<' '{print $2}' | awk -F '>' '{print $1}')
    else
        msg_log 1 "Unable to find a way to get netif operstate"
        return 1
    fi
    FLAGS_NB=$(echo $FLAGS | awk -F ',' '{print NF}')
    for i in $(seq $FLAGS_NB); do
        CURFLAG=$(echo $FLAGS | awk -v awkvar="$i" -F',' '{print $awkvar}')
        [ "$CURFLAG" = "UP" ] && return 1
        [ "$CURFLAG" = "DOWN" ] && return 0
    done
    msg_log 6 "Unable to get $CURRIF operstate. Default is \"down\""
    return 0
}

get_netif_current_config () {
    [ -z "$1" ] && msg_log 1 "No interface name passed" && return 1
    CURRIF="$1"
    #ifconfig ${CURRIF} 2> /dev/null | grep "inet addr:" > /dev/null 2>&1
    #NETIF_STATE=$((1-$?))
    if [ ! -z $BIN_IP ]; then
        unset INET BRD PEER
        IPSHOW=$(ip -4 -o addr show ${CURRIF} 2>/dev/null | grep -v "secondary" | head -n 1)
        for i in $IPSHOW; do
            if [ "$i" = "inet" ]; then
                curr="inet"
            elif [ "$i" = "brd" ]; then
                curr="brd"
            elif [ "$i" = "peer" ]; then
                curr="peer"
            fi
            if [ "$prev" = "inet" ]; then
                [ -z $INET ] && INET=$i
                unset curr
                unset prev
            elif [ "$prev" = "brd" ]; then
                BRD=$i
                unset curr
                unset prev
            elif [ "$prev" = "peer" ]; then
                PEER="$i"
                unset curr
                unset prev
            fi
            prev=$curr
        done
        [ -z "$INET" ] && return 0
        NETIF_ADDR=$(echo $INET | awk -F"/" '{print $1}')
        echo ${CURRIF} | grep -E "(ppp|wwan|cellular)" > /dev/null 2>&1
        is_ppp=$(expr 1 - $?)
        if [ $is_ppp -eq 0 ]; then
            # Subnetwork case (eth, wlan)
            NETIF_NETMASK_CIDR=$(echo $INET | awk -F"/" '{print $2}')
            [ ! -z "$BRD" ] && NETIF_BROADCAST=$BRD
            NETIF_GATEWAY=$(ip -4 route show to exact default 2>/dev/null | grep ${CURRIF} | sed -e 's/^default via //g' | sed -e 's/^default //g' | sed -e 's/ dev '${CURRIF}'//g' | sed -e 's/ .*//g')
        else
            # Point-to-Point case (ppp)
            if [ ! -z "$PEER" ]; then
                NETIF_GATEWAY=$(echo $PEER | awk -F"/" '{print $1}')
                NETIF_NETMASK_CIDR=$(echo $PEER| awk -F"/" '{print $2}')
            else
                NETIF_GATEWAY=$NETIF_ADDR
                NETIF_NETMASK_CIDR=$(echo $INET | awk -F"/" '{print $2}')
            fi
        fi
        cidr2netmask $NETIF_NETMASK_CIDR
        NETIF_NETMASK=$CIDR2NETMASK_RESULT
        unset IPSHOW
    elif [ ! -z $BIN_IFCONFIG ]; then
        NETIF_ADDR=$(${BIN_IFCONFIG} ${CURRIF} 2> /dev/null | grep "inet addr" | awk -F " " '{print $2}' | cut -d":" -f2)
        NETIF_BROADCAST=$(${BIN_IFCONFIG} ${CURRIF} 2> /dev/null | grep "inet addr" | awk -F " " '{print $3}' | cut -d":" -f2)
        NETIF_NETMASK=$(${BIN_IFCONFIG} ${CURRIF} 2> /dev/null | grep "inet addr" | awk -F " " '{print $4}' | cut -d":" -f2)
        NETIF_GATEWAY=$(${BIN_ROUTE} | grep ${CURRIF} | grep default | awk -F' ' '{print $2}')
    else
        msg_log 1 "Unable to find a way to get ${CURRIF} current config"
    fi
    [ "$NETIF_GATEWAY" = "0.0.0.0" ] && NETIF_GATEWAY=""
    [ "$NETIF_GATEWAY" = "*" ] && NETIF_GATEWAY=""

    if [ -f $RESOLVCONF_FILE ] && [ $NETIF_ACTIVATION -eq 1 ]; then
        NETIF_DNS=$(echo $(cat ${RESOLVCONF_FILE} | grep nameserver | cut -d" " -f2) | sed -e "s/\n//")
    fi
    unset CURRIF
    return 0
}

get_timezone_generic () {
    if [ ! -z $TZ ]; then
        tmp_tz=$(echo $TZ)
    elif [ -L $LOCALTIME_CONFIG_FILE ]; then
        if [ ! -d $(readlink -f $LOCALTIME_CONFIG_FILE) ]; then
            tmp_tz=$(readlink -f $LOCALTIME_CONFIG_FILE | awk -F"zoneinfo/" '{print $2}')
        fi
    fi
    if [ -z "$tmp_tz" ]; then
        tmp_tz="UTC"
    fi
    if [ -z $1 ]; then
        TIME_GW_TZ=$tmp_tz
    else
        TIME_GW_TZ_PREV=$tmp_tz
    fi
}

set_timezone_generic () {
    CHECK_REBOOT=0
    [ -z "$1" ] && msg_log 1 "No timezone passed" && return 1
    tmp_set_tz="$1"
    get_timezone "previous"
    if [ -e "$TZ_DIR_PATH_ACTILITY/$tmp_set_tz" ]; then
        rm $LOCALTIME_CONFIG_FILE > /dev/null 2>&1
        ln -s "$TZ_DIR_PATH_ACTILITY/$tmp_set_tz" $LOCALTIME_CONFIG_FILE
        msg_log 4 "Found timezone $tmp_set_tz in $TZ_DIR_PATH_ACTILITY"
        CHECK_REBOOT=1
    elif [ -e "$TZ_DIR_PATH/$tmp_set_tz" ]; then
        rm $LOCALTIME_CONFIG_FILE > /dev/null 2>&1
        ln -s "$TZ_DIR_PATH/$tmp_set_tz" $LOCALTIME_CONFIG_FILE
        msg_log 4 "Found timezone $tmp_set_tz in $TZ_DIR_PATH"
        CHECK_REBOOT=1
    elif [ "$tmp_set_tz" = "UTC" ] || [ "$tmp_set_tz" = "Universal" ]; then
        rm $LOCALTIME_CONFIG_FILE > /dev/null 2>&1
        msg_log 3 "Not found timezone $tmp_set_tz but delete localtime to set UTC timezone"
        CHECK_REBOOT=1
    else
        msg_log 1 "Unable to set timezone $tmp_set_tz. Leave unchanged ($TIME_GW_TZ_PREV)"
    fi
    if [ -e /etc/timezone ]; then
        rm -f /etc/timezone
    fi
    if [ $CHECK_REBOOT -eq 1 ] && [ "$tmp_set_tz" != "$TIME_GW_TZ_PREV" ]; then
        REBOOT_NEEDED=1
        msg_log 1 "Ask for a reboot"
        REBOOT_CAUSE="timezone change"
    fi
}

wrap_netif_num () {
    # Wrap NETIF_XXX_N to NETIF_XXX, where N is the netif number
    # Don't use bash indirect expansion in case of bash may be not available on some gateways (most have it)
    # Instead, use the eval hack:   NETIF_XXX="$(eval echo \$NETIF_XXX_$1)"
    #
    # Note: to use bash indirect expansion instead
    #       MYVAR=NETIF_NAME_$NETIF_NUM
    #       NETIF_NAME="${!MYVAR}"
    #
    [ -z $1 ] && msg_log 2 "No interface number" && return 1
    NETIF_NAME="$(eval echo \$NETIF_NAME_$1)"
    NETIF_TYPE="$(eval echo \$NETIF_TYPE_$1)"
    NETIF_STATE="$(eval echo \$NETIF_STATE_$1)"
    NETIF_ACTIVATION="$(eval echo \$NETIF_ACTIVATION_$1)"
    NETIF_DHCP="$(eval echo \$NETIF_DHCP_$1)"
    NETIF_DHCP_LEASE_OBTAIN="$(eval echo \$NETIF_DHCP_LEASE_OBTAIN_$1)"
    NETIF_DHCP_LEASE_EXPIRE="$(eval echo \$NETIF_DHCP_LEASE_EXPIRE_$1)"
    NETIF_VLAN="$(eval echo \$NETIF_VLAN_$1)"
    NETIF_ADDR="$(eval echo \$NETIF_ADDR_$1)"
    NETIF_NETMASK="$(eval echo \$NETIF_NETMASK_$1)"
    NETIF_BROADCAST="$(eval echo \$NETIF_BROADCAST_$1)"
    NETIF_GATEWAY="$(eval echo \$NETIF_GATEWAY_$1)"
    NETIF_DNS="$(eval echo \$NETIF_DNS_$1)"
}

output_netif () {
    [ ! -z "$NETIF_NAME" ] && echo "NETIF_NAME=${NETIF_NAME}"
    [ ! -z "$NETIF_TYPE" ] && echo "NETIF_TYPE=${NETIF_TYPE}"
    [ ! -z "$NETIF_STATE" ] && echo "NETIF_STATE=${NETIF_STATE}"
    [ ! -z "$NETIF_ACTIVATION" ] && echo "NETIF_ACTIVATION=${NETIF_ACTIVATION}"
    [ ! -z "$NETIF_DHCP" ] && echo "NETIF_DHCP=${NETIF_DHCP}"
    [ ! -z "$NETIF_DHCP_LEASE_OBTAIN" ] && echo "NETIF_DHCP_LEASE_OBTAIN=${NETIF_DHCP_LEASE_OBTAIN}"
    [ ! -z "$NETIF_DHCP_LEASE_EXPIRE" ] && echo "NETIF_DHCP_LEASE_EXPIRE=${NETIF_DHCP_LEASE_EXPIRE}"
    [ ! -z "$NETIF_VLAN" ] && echo "NETIF_VLAN=${NETIF_VLAN}"
    [ ! -z "$NETIF_ADDR" ] && echo "NETIF_ADDR=${NETIF_ADDR}"
    [ ! -z "$NETIF_NETMASK" ] && echo "NETIF_NETMASK=${NETIF_NETMASK}"
    [ ! -z "$NETIF_BROADCAST" ] && echo "NETIF_BROADCAST=${NETIF_BROADCAST}"
    [ ! -z "$NETIF_GATEWAY" ] && echo "NETIF_GATEWAY=${NETIF_GATEWAY}"
    [ ! -z "$NETIF_DNS" ] && echo "NETIF_DNS=${NETIF_DNS}"
}

output_ntp () {
    [ ! -z "$NTP_SERVERS" ] && echo "NTP_SERVERS=${NTP_SERVERS}"
}

output_cellular () {
    [ ! -z "$APN_AVAILABLE" ] && echo "APN_AVAILABLE=${APN_AVAILABLE}"
    [ ! -z "$APN_AUTOCONF" ] && echo "APN_AUTOCONF=${APN_AUTOCONF}"
    [ ! -z "$APN_AUTH" ] && echo "APN_AUTH=${APN_AUTH}"
    [ ! -z "$APN_ADDR" ] && echo "APN_ADDR=${APN_ADDR}"
    [ ! -z "$APN_PIN" ] && echo "APN_PIN=${APN_PIN}"
    [ ! -z "$APN_USER" ] && echo "APN_USER=${APN_USER}"
    [ ! -z "$APN_PASSWORD" ] && echo "APN_PASSWORD=${APN_PASSWORD}"
}

output_wifi () {
    [ ! -z "$WIFI_AVAILABLE" ] && echo "WIFI_AVAILABLE=${WIFI_AVAILABLE}"
    [ ! -z "$WIFI_SSID" ] && echo "WIFI_SSID=${WIFI_SSID}"
    [ ! -z "$WIFI_SECURITY" ] && echo "WIFI_SECURITY=${WIFI_SECURITY}"
    [ ! -z "$WIFI_KEY" ] && echo "WIFI_KEY=${WIFI_KEY}"
}

output_timezone () {
    [ ! -z "$TIME_GW_TZ" ] && echo "TIME_GW_TZ=${TIME_GW_TZ}"
}

reset_ntp () {
    unset NTP_SERVERS
}

reset_timezone () {
    unset TIME_GW_TZ
}

reset_wifi () {
    unset WIFI_AVAILABLE
    unset WIFI_SSID
    unset WIFI_SECURITY
    unset WIFI_KEY
}

reset_cellular () {
    unset APN_AVAILABLE
    unset APN_AUTH
    unset APN_ADDR
    unset APN_PIN
    unset APN_USER
    unset APN_PASSWORD
}

reset_netif () {
    unset NETIF_NUM
    unset NETIF_NAME
    unset NETIF_TYPE
    unset NETIF_STATE
    unset NETIF_DHCP
    unset NETIF_DHCP_LEASE_OBTAIN
    unset NETIF_DHCP_LEASE_EXPIRE
    unset NETIF_VLAN
    unset NETIF_ADDR
    unset NETIF_NETMASK
    unset NETIF_BROADCAST
    unset NETIF_GATEWAY
    unset NETIF_DNS
}

reset_all () {
    reset_netif
    reset_ntp
    reset_timezone
    reset_cellular
    reset_wifi
}

gen_resolvconf () {
    [ -z "$1" ] && msg_log 1 "No dns set in resolver" && return 1
    echo "# Dynamic resolv.conf(5) file for glibc resolver(3) generated by Actility's gwmgr
#     DO NOT EDIT THIS FILE BY HAND -- YOUR CHANGES WILL BE OVERWRITTEN" > $RESOLVCONF_FILE
    echo "nameserver 192.168.0.1" >> $RESOLVCONF_FILE
    for i in $*; do
        echo "nameserver $i" >> $RESOLVCONF_FILE
    done
}

#
# Determine the default activation state for cellualr interface (1st launch after upgrade for instance)
# cellular iinterface is active
# - if it is the primary interface (principal=<cellular> in ipfailover2)
# - if it is the backup interface (rescue=<cellular> and rescuespv=1 in ipfailover2)
#
#  $1: cellular interface name (default: ppp0)
#
#  returned value (echo)
#  0: not activated
#  1: activated
#

get_default_ppp_activation() {
    itf=$1
    if [ -z "$itf" ]; then
        itf="ppp0"
    fi
    principal=$(getIniConf $ROOTACT/usr/etc/lrr/ipfailover2.ini ipfailover2 principal)
    if [ "$principal" = "$itf" ]; then
        echo "1"
        return
    fi
    rescue=$(getIniConf $ROOTACT/usr/etc/lrr/ipfailover2.ini ipfailover2 rescue)
    rescuesvp=$(getIniConf $ROOTACT/usr/etc/lrr/ipfailover2.ini ipfailover2 rescuesvp)
    if [ "$rescue" = "$itf" -a "$rescuesvp" = "1" ]; then
        echo "1"
        return
    fi
    echo "0"
}
