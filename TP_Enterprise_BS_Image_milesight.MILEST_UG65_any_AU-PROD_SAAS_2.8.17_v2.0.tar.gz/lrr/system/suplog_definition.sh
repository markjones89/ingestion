TERMINFO="export TERMINFO=/etc/terminfo/"
NETSTAT="netstat -an"
CHARON_LOG=/tmp/log/charon.log
VIEW_NTP_CONF="cat /etc/ntp.conf"